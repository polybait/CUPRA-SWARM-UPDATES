
print('''#   Copyright 2023 Pavel Kitov  polybait@gmail.com
#       
#   This program is free software; you can redistribute and/or modify
#   it under the terms of the GNU General Public License as published 
#   by the Free Software Foundation.
#      
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   This version runs on Python 3.6 or newer
#   Python modules required:
#   Numpy, Scipy, Pandas, Matplotlib, and pyperclip.
#   Graphical interface is PyQt5
#   You may obtain all in one package 'Anaconda ver.5.0.0' or newer 
#   from  http://continuum.io/
#   ''')
import os
from ctypes import windll
import time
import sys
from PyQt5.Qt import QApplication, QClipboard
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.uic import loadUiType
import zlib
import sqlite3
import functools
from scipy.signal import savgol_filter as sg
from scipy.signal import resample as rs
import pyperclip
import pandas
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import rc
from datetime import datetime
from math import sqrt
import swarm_modules as swrm
try:
    from StringIO import StringIO  # for Python 2.7
    import cPickle
except ImportError:
    from io import StringIO  # for Python 3.x
    import pickle as cPickle
from pyteomics import mass
if not os.path.exists('results'):
    os.mkdir('results')
if not os.path.exists('DB'):
    os.mkdir('DB')
if not os.path.exists('DB/settings'):
    os.mkdir('DB/settings')

def center_of_gravity(spectrum,min,max,charge):
    """This function calculate centroid of the area in spectrum limited by 'min' and 'max' m/z values
    spectrum is either list, np.ndarray, or pandas.DataFrame 
    min and max are float
    """
    if isinstance(spectrum, np.ndarray):
        spectrum= pandas.DataFrame(spectrum)
        spectrum.columns = ['Mass','Intensity']
    if isinstance(spectrum, str):
        spectrum= pandas.read_table(StringIO(spectrum),delim_whitespace=True,header=None,names=['Mass','Intensity'])
    if isinstance(spectrum, pandas.DataFrame):
        spectrum.columns = ['Mass','Intensity']
    spectrum['Product']=spectrum.Mass*spectrum.Intensity
    spectrum=spectrum[spectrum.Mass>=min]
    spectrum=spectrum[spectrum.Mass<=max]
    a=spectrum.Product.mean()*charge
    b=spectrum.Intensity.mean()
    return a/b
def resample_spectrum(spectrum,low=0,high=10000000,rate=25,padding=1): 
    ''' Function resamples original spectrum to standardized rate.
    Input: numpy array spectrum containing 2 columns, left and right limits
    (low and high) and resumpling rate. Returns Pandas DataFrame new
    '''
    import pandas
    import numpy as np
    from scipy import interpolate
    # try:
    spectrum=pandas.DataFrame(spectrum)
    spectrum.columns = ['Mass','Intensity']

    if low<spectrum['Mass'].min():
        low=spectrum['Mass'].min()
    if low>=spectrum['Mass'].max():
        low=spectrum['Mass'].min()
    if high>spectrum['Mass'].max():
        high=spectrum['Mass'].max()
    if high<=spectrum['Mass'].min():
        high=spectrum['Mass'].max()
    if high<=low:
        low=spectrum['Mass'].min()
        high=spectrum['Mass'].max()
    smpl=int((high-low)*rate)
    spectrum=(spectrum[(spectrum['Mass'].values>= low-padding)])
    spectrum=(spectrum[(spectrum['Mass'].values <= high+padding)])
    flinear=interpolate.interp1d(spectrum['Mass'].values,spectrum['Intensity'].values)
    x=np.linspace(low,high,smpl+1,endpoint=True)
    y=flinear(x)
    new=pandas.DataFrame()
    new['Mass']=x
    new['Intensity']=y
    # print(new)
    return new
def combine_formulas(a,b):
    '''Function takes two chemical formulas and combines them elementwise: 'C2H4'+'HCl'='C2H5Cl'. 
    Returns string'''
    result={}
    S=''
    A=mass.Composition(formula=a)
    B=mass.Composition(formula=b)
    keys=set(list(A.keys())+list(B.keys()))
    for key in keys:
        if key in A:
            aa=A[key]
        else:
            aa=0
        if key in B:
            bb=B[key]
        else:
            bb=0
            
        result[key]=aa+bb
        S=S+key+str(result[key])
    return S
def sum_formulas(lst):
    '''Takes list of chemical formulas.
    Returns combined formula (as a string).'''
    A='H0'
    for f in range(len(lst)):
        A=combine_formulas(A,lst[f])
    return A
def substract_formulas(a,b):
    '''Function takes two chemical formulas and substracts them elementwise: 'C2H4'-'H4C'='C'. 
    Returns string'''
    result={}
    S=''
    A=mass.Composition(formula=a)
    B=mass.Composition(formula=b)
    keys=set(list(A.keys())+list(B.keys()))
    for key in keys:
        if key in A:
            aa=A[key]
        else:
            aa=0
        if key in B:
            bb=B[key]
        else:
            bb=0
            
        result[key]=aa-bb
        S=S+key+str(result[key])
    return S     
def averagine(spectrum,low,high,rate,padding,averagine_charge):
    import math
    if float(low)<float(high):
        df=swrm.resample_spectrum(spectrum,low,high,rate,padding)
        COG = swrm.center_of_gravity(df, low, high)
    else:
        COG=float(low)
    try:
        A=COG*abs(averagine_charge)-averagine_charge*1.007
        B=A/111.1254
        C=B*4.9384
        H=round(B*7.7583)
        N=B*1.3577
        O=B*1.4773
        S=B*0.0417
        h=(C-math.floor(C))*12+(N-math.floor(N))*14+(O-math.floor(O))*16+(S-math.floor(S))*32
        H=H+round(h)
        res='C'+str(math.floor(C))+'N'+str(math.floor(N))+'O'+str(math.floor(O))+'S'+str(math.floor(S))+'H'+str(math.floor(H))
        return res
    except:
        return('Spectrum cannot be found or limits set outside the spectrum range')
def spectrum_outline(spectrum,sm,asym):
    outline=-1*swrm.baseline(-1*spectrum, sm, asym, 10)
    return outline
def DF2str(df):
    '''function replacing buld-in pandas function to_string(), which corrupts float'''
    import pandas
    try:
        from StringIO import StringIO  # for Python 2.7
    except ImportError:
        from io import StringIO  # for Python 3.x
    buffer = StringIO()
    df.to_csv(buffer, sep='\t', header=False, index=False)
    s = buffer.getvalue()
    buffer.close()
    return s
    
formula_iterator=1

Ui_MainWindow, QMainWindow = loadUiType('swarm_modules/SWARM.ui')

class Main(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle('SWARM')
        
        
        self.ui.pushButton_simulate_positive_fragments.clicked.connect(self._simulate_positive_fragments)
        self.ui.pushButton_combine_monosaccharides.clicked.connect(self._combine_monosaccharides)
        self.ui.pushButton__load_TEMPLATES.clicked.connect(self._load_TEMPLATES)
        self.ui.pushButton__load_TEMPLATES_2.clicked.connect(self._load_TEMPLATES)
        self.ui.pushButton_standardize.clicked.connect(self._standardize)
        self.ui.pushButton_simulateGauss.clicked.connect(self._simulateGauss)
        # self.ui.pushButton_get_rates.clicked.connect(self._get_rates)
        # self.ui.pushButton_fit_LB.clicked.connect(self._LB_plot)
        # self.ui.pushButton_None_linear_fit.clicked.connect(self._None_linear_fit)
        self.ui.pushButton_ttest.clicked.connect(self._ttest)
        self.ui.pushButton_ttest_2.clicked.connect(self._ttest_col)
        self.ui.pushButton_hist.clicked.connect(self._hist)
        self.ui.pushButton_calc_QQ.clicked.connect(self._QQplot)
        self.ui.pushButton_paste_obs.clicked.connect(self._paste_observations)
        self.ui.pushButton_paste_obs_2.clicked.connect(self._paste_observations_2)
        self.ui.pushButton_transpose.clicked.connect(self._transpose)
        self.ui.pushButton_calc_mass.clicked.connect(self._sequence2mass)
        self.ui.pushButton_calc_add.clicked.connect(self._plus)
        self.ui.pushButton_calc_sub.clicked.connect(self._minus)
        self.ui.pushButton_quick_clear.clicked.connect(self._quick_clear)
        self.ui.pushButton_paste_plotspectrum.clicked.connect(self._paste_plotspectrum)
        self.ui.pushButton_paste_plotspectrum_2.clicked.connect(self._paste_plotspectrum_2)
        self.ui.pushButton_paste_plotspectrum_3.clicked.connect(self._paste_plotspectrum_3)
        self.ui.pushButton_paste_plotspectrum_4.clicked.connect(self._paste_plotspectrum_4)
        self.ui.pushButton_paste_plotspectrum_5.clicked.connect(self._paste_plotspectrum_5)
        self.ui.pushButton_paste_plotspectrum_6.clicked.connect(self._paste_plotspectrum_6)
        self.ui.pushButton_plot_figure.clicked.connect(self._plot_figure)
        self.ui.pushButton_averagine.clicked.connect(self._calc_averagine)
        self.ui.pushButton_enter_kinetics_ML.clicked.connect(self._enter_kinetics_ML)
        self.ui.pushButton_enter_kinetics_X.clicked.connect(self._enter_kinetics_X)
        self.ui.pushButton_get_bruker_spectra.clicked.connect(self._get_bruker_spectra)
        self.ui.pushButton_input_bruker_spectra.clicked.connect(self._input_bruker_spectra)
        self.ui.pushButton_get_cursor.clicked.connect(self._get_cursor)
        self.ui.pushButton_clear_SWARM_form.clicked.connect(self._clear_SWARM_form)
        self.ui.pushButton_interface_font.clicked.connect(self._interface_font)
        self.ui.pushButton_paste_original_spectrum.clicked.connect(self._paste_original_spectrum)
        self.ui.pushButton_copy_final_spectrum.clicked.connect(self._copy_final_spectrum)
        self.ui.pushButton_paste_annotations.clicked.connect(self._paste_annotations)
        self.ui.pushButton_copy_found_peaks.clicked.connect(self._copy_found_peaks)
        self.ui.pushButton_adducts_buster_2.clicked.connect(self._SWARM2)
        self.ui.pushButton_plot.clicked.connect(self._plot)
        self.ui.pushButton_plot_2.clicked.connect(self._plot)
        self.ui.pushButton_plot_4.clicked.connect(self._replot_Gaussian_from_parameters)
        
        self.ui.pushButton_save_1.clicked.connect(self._save_par)
        self.ui.pushButton_load_1.clicked.connect(self._load_par)
        self.ui.pushButton_save_2.clicked.connect(self._save_par)
        self.ui.pushButton_load_2.clicked.connect(self._load_par)
        self.ui.pushButton_save_3.clicked.connect(self._save_par)
        self.ui.pushButton_load_3.clicked.connect(self._load_par)
        self.ui.pushButton_save_4.clicked.connect(self._save_par)
        self.ui.pushButton_load_4.clicked.connect(self._load_par)
        self.ui.pushButton_save_5.clicked.connect(self._save_par)
        self.ui.pushButton_load_5.clicked.connect(self._load_par)
        self.ui.pushButton_save_6.clicked.connect(self._save_par)
        self.ui.pushButton_load_6.clicked.connect(self._load_par)
        
        self.ui.pushButton_showDB.clicked.connect(self._show_DB)
        self.ui.pushButton_showDB_2.clicked.connect(self._show_DB)
        self.ui.pushButton_showDB_3.clicked.connect(self._show_DB)
        self.ui.pushButton_newDB.clicked.connect(self._create_newDB)
        self.ui.pushButton_newDB_2.clicked.connect(self._create_newDB)
        self.ui.pushButton_newDB_3.clicked.connect(self._create_newDB)
        self.ui.pushButton_input.clicked.connect(self._input)
        self.ui.pushButton_input_2.clicked.connect(self._fast_input)
        self.ui.pushButton_input_3.clicked.connect(self._input_2)
        self.ui.pushButton_input_4.clicked.connect(self._input_3)
        self.ui.pushButton_update.clicked.connect(self._update_without_settings)
        self.ui.pushButton_update_2.clicked.connect(self._update_with_settings)
        self.ui.pushButton_update_3.clicked.connect(self._update_2)
        self.ui.pushButton_update_4.clicked.connect(self._update_3)
        self.ui.pushButton_delete_entry.clicked.connect(self._delete_entry)
        self.ui.pushButton_delete_entry_2.clicked.connect(self._delete_entry_2)
        self.ui.pushButton_delete_entry_3.clicked.connect(self._delete_entry_3)
        self.ui.pushButton_show_entry.clicked.connect(self._show_entry)
        self.ui.pushButton_show_entry_2.clicked.connect(self._show_entry_and_settings)
        self.ui.pushButton_show_entry_3.clicked.connect(self._show_entry_2)
        self.ui.pushButton_show_entry_4.clicked.connect(self._show_entry_3)
        self.ui.pushButton_search_DB.clicked.connect(self._search_DB)
        self.ui.pushButton_search_DB_3.clicked.connect(self._search_DB_2)
        self.ui.pushButton_search_DB_4.clicked.connect(self._search_DB_3)
        self.ui.pushButton_search_DB_2.clicked.connect(self._search_ALL_DBs)
        self.ui.pushButton_paste.clicked.connect(self._paste)
        self.ui.pushButton_copy_original.clicked.connect(self._copy_original)
        self.ui.pushButton_copy_original_2.clicked.connect(self._copy_original_2)
        self.ui.pushButton_copy_original_3.clicked.connect(self._copy_original_3)
        self.ui.pushButton_copy_ratios.clicked.connect(self._copy_ratios)
        self.ui.pushButton_copy_info.clicked.connect(self._copy_info)
        self.ui.pushButton_annotate.clicked.connect(self._annotate)
        self.ui.pushButton_calculate_ratios_formula.clicked.connect(self._calculate_ratios_from_formula)
        self.ui.pushButton_transferDB.clicked.connect(self._transferDB)
        self.ui.pushButton_modify_field.clicked.connect(self._modify_field)
        self.ui.pushButton_recal_form.clicked.connect(self._recalculate_formulas)
        self.ui.pushButton_centroid.clicked.connect(self._centroids)
        # self.ui.pushButton_area.clicked.connect(self._areas)
        self.ui.pushButton_report.clicked.connect(self._report)
        self.ui.pushButton_report_2.clicked.connect(self._report_2)
        self.ui.pushButton_show_plot.clicked.connect(self._plot_DB_spectrum)
        self.ui.pushButton_show_plot_2.clicked.connect(self._plot_DB_spectrum_2)
        self.ui.pushButton_show_plot_3.clicked.connect(self._plot_DB_spectrum_3)
        self.ui.pushButton_autoSWARM.clicked.connect(self._autoSWARM)
        self.ui.pushButton_delete_list.clicked.connect(self._delete_list)
        self.ui.pushButton_calc_Kd.clicked.connect(self._calc_Kd)
        self.ui.pushButton_calc_Kd_CUPRA.clicked.connect(self._calc_Kd_CUPRA)
        self.ui.pushButton_paste_LO_2.clicked.connect(self._paste_LO_2)
        self.ui.pushButton_paste_RO_2.clicked.connect(self._paste_RO_2)
        self.ui.pushButton_paste_LO.clicked.connect(self._paste_LO)
        self.ui.pushButton_paste_RO.clicked.connect(self._paste_RO)
        self.ui.pushButton_paste_R.clicked.connect(self._paste_R)
        self.ui.pushButton_plot_difference.clicked.connect(self._plot_difference)
        self.ui.pushButton_enumerate_adducts.clicked.connect(self._enumerate_adducts)
        self.ui.pushButton_copy2ann_1.clicked.connect(self._cp_specific)
        self.ui.pushButton_copy2ann_2.clicked.connect(self._cp_ref)
        # self.ui.pushButton_copy2ann_3.clicked.connect(self._cp_mix)
        self.ui.pushButton_copy2ann_5.clicked.connect(self._cp_lowMW)
        self.ui.pushButton_copy2ann_4.clicked.connect(self._cp_ALL)
        # self.ui.pushButton_copy2form_1.clicked.connect(self._cp_refform)
        self.ui.pushButton_sort_mass.clicked.connect(self._sort_annotations_by_mass)
        self.ui.pushButton_correct_mass.clicked.connect(self._correct_mass)
        # self.ui.pushButton_adduct_correction.clicked.connect(self._adduct_correction)
        self.ui.pushButton_integrate.clicked.connect(self._integrate)
        self.ui.pushButton_paste_difspectrum_1.clicked.connect(self._paste_dif1)
        self.ui.pushButton_paste_difspectrum_2.clicked.connect(self._paste_dif2)
        self.ui.pushButton_copy_difspectrum_3.clicked.connect(self._copy_dif)
        self.ui.pushButton_copy_difspectrum_4.clicked.connect(self._copy_dif2)
        self.ui.pushButton_propagate_limits.clicked.connect(self._propagate_limits)

        # self.ui.pushButton_paste_curve.clicked.connect(self._paste_curve)
        # self.ui.pushButton_copy_X.clicked.connect(self._copy_X)
        # self.ui.pushButton_copy_Y.clicked.connect(self._copy_Y)
        # self.ui.pushButton_plot_curve.clicked.connect(self._plot_curve)
        
        self.ui.pushButton_paste_curve_3.clicked.connect(self._paste_curve_3)
        self.ui.pushButton_paste_2.clicked.connect(self._paste_2)
        self.ui.pushButton_paste_3.clicked.connect(self._paste_3)
        self.ui.pushButton_fitGauss.clicked.connect(self._fitGauss)
        self.ui.pushButton_apply_fitted_params.clicked.connect(self._apply_fitted_params)
        self.ui.pushButton_equal_intervals.clicked.connect(self._equal_intervals)
        self.ui.pushButton_deleteFigs.clicked.connect(self._deleteFigs)
        self.ui.pushButton_propagate_limits_2.clicked.connect(self._propagate_limits_2)
        self.ui.pushButton_fitAllGauss.clicked.connect(self._fitAllGauss)
        self.ui.pushButton_report_3.clicked.connect(self._report_3)
        self.ui.pushButton_paste_curve_4.clicked.connect(self._paste_curve_4)
        self.ui.pushButton_calc_RF.clicked.connect(self._calc_RF)
        self.ui.pushButton_applyFilters.clicked.connect(self._applyFilters)

        self.w = QWidget()
        
        self.pars1 = ['lineEdit_type','lineEdit_suffix', 'lineEdit_Nnum_2', 'lineEdit_Nnum', 'lineEdit_decimals', 'lineEdit_low', 'lineEdit_high', 'lineEdit_rate', 'lineEdit_sgwindow', 'lineEdit_sgorder', 'lineEdit_lambda', 'lineEdit_p', 'lineEdit_lambda_2', 'lineEdit_p_2','lineEdit_lambda_3', 'lineEdit_p_3', 'lineEdit_lambda_4', 'lineEdit_p_4', 'lineEdit_iter', 'chromatogram','lynx','SWARMcoords','delay','numscans','numdata','Xcoords','SWARMcoords2','X_spectrum_coords','start_data_collection','kinetics_period_2','numdata_2','delay_2','lineEdit_left','lineEdit_right','lineEdit_linewidth_2','lineEdit_fontsize_2','lineEdit_offset_2','lineEdit_resamplerate','figwidth','fighight','majorticks','minorticks','lineEdit_linewidth_3','lineEdit_font','lineEdit_linecolor','lineEdit_y_starts_at','lineEdit_DB_donor', 'lineEdit_DB_recipient', 'lineEdit_suffix', 'lineEdit_PR', 'lineEdit_TO', 'lineEdit_ref_ID', 'lineEdit_target_ID', 'lineEdit_ref_mz_2', 'lineEdit_low_2', 'lineEdit_high_2', 'lineEdit_rate_2', 'lineEdit_sgwindow_2', 'lineEdit_sgorder_2', 'lineEdit_test', 'lineEdit_linewidth', 'lineEdit_fontsize', 'lineEdit_offset', 'lineEdit_accuracy','lineEdit_accuracy_2', 'lineEdit_global_font', 'lineEdit_rate_3','lineEdit_target_ID','lineEdit_ref_ID',
        
        'fragment_1','fragment_2','fragment_3','fragment_4','fragment_5','fragment_6','fragment_7','fragment_8','fragment_9','fragment_10','form_1','form_2','form_3','form_4','form_5','form_6','form_7','form_8','form_9','form_10','min1','min2','min3','min4','min5','min6','min7','min8','min9','min10','max1','max2','max3','max4','max5','max6','max7','max8','max9','max10','aglycone','targetmasslow','targetmasshigh','targetmasslow','targetmasshigh',
        
        'kinetics_file','X_spectrum_coords','Xcoords','SWARMcoords2','kinetics_period_2','numdata_2','start_data_collection',
        'chromatogram','lynx','SWARMcoords','numscans','numdata','delay',
        'low_lim','upper_lim','delay_fid','delay_saving'
                      ]
        self.pars2 = ['plainTextEdit_found_parameters','plainTextEdit_add_PEAKS_0', 'plainTextEdit_TMPL', 'plainTextEdit_LO', 'plainTextEdit_proteins','plainTextEdit_Ref', 'plainTextEdit_specific_ligands', 'plainTextEdit_nonspecific_ligands', 'plainTextEdit_ions']
        self.pars3 = ['checkBox_make_outline','checkBox_polarity', 'checkBox_autoS', 'checkBox_autoR',  'checkBox_autoLOW',
        'checkBox_use_database', 'checkBox_use_database_ann', 'checkBox_oneREF', 'checkBox_resample',
        'checkBox_Savitzky', 'checkBox_asym_bground_Before', 'checkBox_runSWARM', 'checkBox_asym_bground_every',
        'checkBox_asym_bground_after','legend','box','y_ax','x_ticks_labels','checkBox_y_starts_at','clear_figs',
        'plot_entries','checkBox_show_original', 'checkBox_SG_spectrum', 'checkBox_baseline_before_SWARM', 'checkBox_show_background', 'checkBox_show_legend', 'checkBox_Final', 'checkBox_Savitzky_2', 'checkBox_correct', 'checkBox_plot_TL', 'checkBox_cancel_messages', 'checkBox_replace', 'checkBox_vertical', 'checkBox_annotate', 'checkBox_windows']
        self.SWARM_DF = pandas.DataFrame()
        self.TEMPLATES = pandas.DataFrame()
 
################ SLOMO #################################################
    def _search_DB_3(self):  # database search engine
        fname = str(self.ui.lineEdit_DB_file_3.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            return
        self.ui.lineEdit_DB_donor.clear()
        self.ui.lineEdit_DB_donor.setText(fname.upper())
        n1 = 'filename'
        n2 = ''
        b1 = ''
        b12 = ''
        show1 = 'filename'
        show2 = 'filename'
        orderby = str(self.ui.comboBox_orderby_3.currentText())
        asdes = str(self.ui.comboBox_asdes_3.currentText())
        dt = ''
        if n1 == 'comment':
            m1 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n1 == 'annotations':
            m1 = str(self.ui.plainTextEdit_annotations_3.toPlainText())
        else:
            m1 = eval('''str(self.ui.lineEdit_{}_3.text()).strip()'''.format(n1))
        if n2 == 'comment':
            m2 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n2 == 'annotations':
            m2 = str(self.ui.plainTextEdit_annotations_3.toPlainText())
        elif n2 == '':
            m2 = ''
        else:
            m2 = eval('''str(self.ui.lineEdit_{}_3.text()).strip()'''.format(n2))
        s = ''
        id = ''
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            # try:
            if not n2 == '':
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} {} {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, b1, n2, b12, m2, dt, orderby, asdes))
            else:
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, dt, orderby, asdes))

            c.execute(sql)
            ls = c.fetchall()
            for f in ls:
                c.execute(
                    """SELECT {} FROM spectra WHERE ID = {}""".format(n1, f[0]))
                fn1 = c.fetchone()[0]
                if not n2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(n2, f[0]))
                    fn2 = c.fetchone()[0]
                sh1 = ''
                sh2 = ''
                if not show1 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show1, f[0]))
                    sh1 = c.fetchone()[0]
                if not show2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show2, f[0]))
                    sh2 = c.fetchone()[0]
                id = id+str(f[0])+','
                s = s+str(f[0])+'\t'+'\t'+str(sh1)+'\t'+str(sh2)+'\n'

            self.ui.plainTextEdit_search_result_3.clear()
            self.ui.plainTextEdit_search_result_3.insertPlainText(s)
            self.ui.plainTextEdit_search_result_ID_3.clear()
            self.ui.plainTextEdit_search_result_ID_3.insertPlainText(id[:-1])
            self.ui.plainTextEdit_search_result_ID_4.clear()
            self.ui.plainTextEdit_search_result_ID_4.insertPlainText(id[:-1])
            self.ui.plainTextEdit_search_result_ID.clear()
            self.ui.plainTextEdit_search_result_ID.insertPlainText(id[:-1])
        except Exception as e:
            print(e)
        finally:
            conn.close()
    def _show_entry_3(self):  # load entry from current database
        ID = str(self.ui.lineEdit_ID_3.text())
        fname = str(self.ui.lineEdit_DB_file_3.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            else:
                print("Database {} doesn't exist".format(fname.upper()))
            return
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            IDD = ls[0][0]
            self.ui.lineEdit_dirty_ID.clear()
            self.ui.lineEdit_dirty_ID.setText(str(IDD).strip())
            filename = ls[0][1]
            self.ui.lineEdit_filename_3.clear()
            self.ui.lineEdit_filename_3.setText(str(filename).strip())
            project = ls[0][2]
            self.ui.lineEdit_project.clear()
            self.ui.lineEdit_project.setText(str(project))
            operator = ls[0][3]
            self.ui.lineEdit_operator.clear()
            self.ui.lineEdit_operator.setText(str(operator))
            created_date = ls[0][4]
            self.ui.lineEdit_created_date.clear()
            self.ui.lineEdit_created_date.setText(str(created_date))
            type = ls[0][5]
            self.ui.lineEdit_type.clear()
            self.ui.lineEdit_type.setText(str(type))
            polarity = ls[0][6]
            if str(polarity) == 'Positive':
                self.ui.radioButton_plus.setChecked(True)
                self.ui.radioButton_minus.setChecked(False)
            else:
                self.ui.radioButton_plus.setChecked(False)
                self.ui.radioButton_minus.setChecked(True)

            formulas = ls[0][7]
            self.ui.plainTextEdit_formula.clear()
            self.ui.plainTextEdit_formula.insertPlainText(str(formulas))
            self.ui.plainTextEdit_formula_2.clear()
            self.ui.plainTextEdit_formula_2.insertPlainText(str(formulas))
            trap = ls[0][8]
            self.ui.lineEdit_trap.clear()
            self.ui.lineEdit_trap.setText(str(trap))
            trans = ls[0][9]
            self.ui.lineEdit_trans.clear()
            self.ui.lineEdit_trans.setText(str(trans))
            conditions = ls[0][10]
            self.ui.lineEdit_conditions.clear()
            self.ui.lineEdit_conditions.setText(str(conditions))
            peaks = ls[0][11]
            # self.ui.plainTextEdit_annotations.clear()
            # self.ui.plainTextEdit_annotations.insertPlainText(str(peaks))
            # self.ui.plainTextEdit_annotations_4.clear()
            # self.ui.plainTextEdit_annotations_4.insertPlainText(str(peaks))
            lig_name = ls[0][12]
            self.ui.lineEdit_lig_name.clear()
            self.ui.lineEdit_lig_name.setText(str(lig_name))
            comment = ls[0][14]
            self.ui.plainTextEdit_comment.clear()
            self.ui.plainTextEdit_comment.insertPlainText(comment)
            spectrum = ls[0][15]
            spectrum = cPickle.loads(zlib.decompress(spectrum))
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(spectrum)
            self.ui.plainTextEdit_spectrum_2.clear()
            self.ui.plainTextEdit_spectrum_2.insertPlainText(spectrum)
            self.ui.plainTextEdit_spectrum_3.clear()
            self.ui.plainTextEdit_spectrum_3.insertPlainText(spectrum)
            ratios = ls[0][16]
            ratios = cPickle.loads(zlib.decompress(ratios))

            self.ui.plainTextEdit_ratios.clear()
            self.ui.plainTextEdit_ratios.insertPlainText(str(ratios))
            self.ui.plainTextEdit_ratios_3.clear()
            self.ui.plainTextEdit_ratios_3.insertPlainText(str(ratios))
            annotations = ls[0][17]
            self.ui.plainTextEdit_annotations_4.clear()
            self.ui.plainTextEdit_annotations_4.insertPlainText(str(annotations))

        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Enry {} doesn't exist in the database {}".format(ID, fname.upper()))
            else:
                print("Enry {} doesn't exist in the database {}".format(
                    ID, fname.upper()))
            return
        finally:
            conn.close()
    def _input_3(self):  # create new entry in current database
        fname = str(self.ui.lineEdit_DB_file_3.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename_3.text()).strip()

        spectrum = str(self.ui.plainTextEdit_spectrum_3.toPlainText())
        ratios = str(self.ui.plainTextEdit_ratios_3.toPlainText())
        # Compress:
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        annotations = str(self.ui.plainTextEdit_annotations_4.toPlainText())
        project = ''
        operator = ''
        formulas = ''
        type = ''
        polarity = ''
        trap = ''
        trans = ''
        conditions = ''
        peaks = ''
        lig_name = ''
        lig_mass = ''
        comment = ''
        from datetime import datetime
        created_date = str(datetime.now())
        self.ui.lineEdit_created_date.setText(created_date)
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        with conn:
            c.execute('SELECT max(rowid) FROM spectra')
            try:
                ID = c.fetchone()[0]+1
            except:
                ID = 1
            self.ui.lineEdit_ID_2.setText(str(ID))
            c.execute("SELECT * FROM spectra WHERE filename=:filename",
                      {'filename': filename})
            try:
                fn = c.fetchone()[1]
                QMessageBox.about(
                    self, "warning", "Item with file name {} already exists in the database. \nUse UPDATE to change it. ".format(fn))
            except:
                c.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                          'ID': ID, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum, 'ratios': ratios, 'annotations': annotations})
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "Message", "Entry added to database")
                else:
                    return
    def _update_3(self):  # update entry in current database
        ID = str(self.ui.lineEdit_ID_3.text())
        fname = str(self.ui.lineEdit_DB_file_3.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename_3.text()).strip()
        project = ''
        operator = ''
        type = ''
        polarity = ''
        trap = ''
        trans = ''
        conditions = ''
        lig_name = ''
        lig_mass = ''
        peaks = ''
        comment = ''
        formulas = ''
        spectrum = str(self.ui.plainTextEdit_spectrum_3.toPlainText())
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        annotations = str(self.ui.plainTextEdit_annotations_4.toPlainText())
        ratios = str(self.ui.plainTextEdit_ratios_3.toPlainText())
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        created_date = str(datetime.now())
        self.ui.lineEdit_created_date.setText(created_date)
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            date = ls[0][4]
            command = """UPDATE spectra SET filename='{}',project='{}',operator='{}',created_date='{}',type='{}',polarity='{}',formulas='{}',trap='{}',trans='{}',conditions='{}',peaks='{}',lig_name='{}',lig_mass='{}',comment='{}',annotations='{}'""".format(
                filename, project, operator, created_date, type, polarity, formulas, trap, trans, conditions, peaks, lig_name, lig_mass, comment, annotations)
            command = command+""" WHERE ID = '%s'""" % ID
            with conn:
                c.execute(command)
                c.execute(
                    """UPDATE spectra SET spectrum=?,ratios=? WHERE ID=?""", (spectrum, ratios, ID))

            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "message", "Entry #{} updated".format(ID))
            else:
                print("Entry #{} updated".format(ID))
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            else:
                print(
                    "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            return
        finally:
            conn.close()
    def _delete_entry_3(self):  # delete entry in current database
        fname = str(self.ui.lineEdit_DB_file_3.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return

        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        ID = str(self.ui.lineEdit_ID_3.text())
        if not self.ui.checkBox_cancel_messages.isChecked():
            question = QMessageBox.question(self, 'Message', "Are you sure you want to delete entry # {}?".format(
                ID), QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        else:
            question = 16384
        if question == 16384:
            with conn:
                c.execute("DELETE from spectra WHERE ID=:ID", {'ID': ID})
    def _paste_3(self):  # paste clipboard to plainTextEdit_spectrum
        data = pyperclip.paste()
        self.ui.plainTextEdit_spectrum_3.clear()
        self.ui.plainTextEdit_spectrum_3.insertPlainText(data)
    def _copy_original_3(self):  # copy original spectrum from database to clipboard
        s = str(self.ui.plainTextEdit_spectrum_3.toPlainText())
        pyperclip.copy(s)
    def _plot_DB_spectrum_3(self):  # plot spectrum from plainTextEdit_spectrum field
        import matplotlib.pyplot as plt
        Spectrum = StringIO(str(self.ui.plainTextEdit_spectrum_3.toPlainText()))
        df = pandas.read_csv(Spectrum, delim_whitespace=True, names=[
                               'Mass', 'Intensity'])
        linewidth = 1.0
        fontsize = 12.0
        offset = [0,0.5]
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels


        fig = plt.figure()
        ax = fig.add_subplot(111)

        plt.plot(df.Mass, df.Intensity, color='blue',
                 linewidth=linewidth, label='spectrum')

        plt.xlabel('m/z')
        plt.ylabel('Intensity')
        plt.show()
    def _deleteFigs(self):  #delete all figures
        plt.close('all')
        
    def _equal_intervals(self):
        try:
            spectrum = str(self.ui.plainTextEdit_spectrum_3.toPlainText())# spectrum is loaded as str
            spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=['mass','intensity'])
            # print(spectrum.mass)
            n = int(self.ui.lineEdit_n.text())
            sigma = float(self.ui.lineEdit_sigma.text())
            limit1=min(spectrum.mass)
            limit2=max(spectrum.mass)
            d=(limit2-limit1)/n
            S=''
            point=0
            for f in range(n):
                limit1=round(limit1+d)
                S=S+str(limit1)+'\t'+str(sigma)+'\n'
            self.ui.plainTextEdit_annotations_4.clear()
            self.ui.plainTextEdit_annotations_4.insertPlainText(S)
        except:
            QMessageBox.about(self, "warning", "Cannot generate list. Check if spectrum exists.")
    def _apply_fitted_params(self):
        A=str( self.ui.plainTextEdit_ratios_3.toPlainText())
        params = pandas.read_csv(StringIO(A), delim_whitespace=True, names=['L','Amp','S','A','M'])
        print(params[['L','S']])
        params=params[['L','S']].to_string(header=False, index=False)
        self.ui.plainTextEdit_annotations_4.clear()
        self.ui.plainTextEdit_annotations_4.insertPlainText(str(params))
    def _fitGauss(self, noshow=False):
        from scipy.optimize import curve_fit
        start = time.time()

        try:
            spectrum = str(self.ui.plainTextEdit_spectrum_3.toPlainText())# spectrum is loaded as str
            spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=['mass','intensity'])
            spectrum.dropna(inplace=True)
            if self.ui.checkBox_Savitzky_3.isChecked():
                sgwin=int(self.ui.lineEdit_sgwindow_3.text())
                sgorder=int(self.ui.lineEdit_sgorder_3.text())
                if not sgwin % 2 == 0:
                    sgwin=sgwin+1
                if not sgwin < sgorder:
                    spectrum['SG'] = sg(spectrum['intensity'].values,
                                  sgwin, sgorder)
                    spectrum['intensity'] = spectrum['SG'].values
                else:
                    if not self.ui.checkBox_cancel_messages.isChecked():
                        QMessageBox.about(self, "warning", "Savitzky-Golay order must not be greater than window length")
                    else:
                        print("Savitzky-Golay order must not be greater than window length")

            
            MAX=max(spectrum.intensity)
            if  self.ui.checkBox_Normalize_height.isChecked():
                spectrum.intensity=spectrum.intensity/MAX
                MAX=1.0 
            x=spectrum.mass
            y=spectrum.intensity
        except:
            print('Spectrum not found')
        try:
            df = pandas.read_csv(StringIO(str(self.ui.plainTextEdit_annotations_4.toPlainText())), delim_whitespace=True,names=['L', 'W'],header=None)

            L=list(df.L)
            W=list(df.W)
            D=float(self.ui.lineEdit_locRange.text())
            # print(D)
        except:
            print('Input parameters are missing')
        M=''
        P='('
        param='('
        B1='('
        B2='('
        for f in range(len(L)):
            M=M+"+a{}*np.exp(-(x-x{})**2/(2*sigma{}**2))".format(f,f,f)
            P=P+"a{},".format(f)
            param=param+"1*{},".format(MAX)
            B1=B1+"0,"
            B2=B2+"1*{},".format(MAX)
        for f in range(len(L)):
            P=P+"x{},".format(f)
            param=param+str(L[f])+','
            B1=B1+str(L[f]-L[f]*D/100)+','
            B2=B2+str(L[f]+L[f]*D/100)+','
        for f in range(len(L)):
            P=P+"sigma{},".format(f)
            param=param+str(W[f])+','
            B1=B1+"0,"
            B2=B2+str(W[f])+','
        P=P[:-1]+")"
        M=M[1:]
        param=param[:-1]+")"
        B='['+B1[:-1]+'),'+B2[:-1]+')]'

        def gaus(x,*param):
            exec(P+'=param')
            return eval(M)
        def ga(x,a,x0,sigma):
            return a*np.exp(-(x-x0)**2/(2*sigma**2))

        popt,pcov = curve_fit(gaus,x,y,p0=eval(param), bounds=eval(B))
        
        popt=tuple(popt)
        S=''        
        for f in range(len(L)):
            a=popt[f]
            b=popt[f+len(L)]
            c=popt[f+len(L)*2]
            S=S+'{}\t{}\t{}\t{}\t{}\n'.format(round(b,2),round(a,5),round(c,2),round(a*c*np.sqrt(2*np.pi),2),round(MAX,2))
        self.ui.plainTextEdit_ratios_3.clear()
        self.ui.plainTextEdit_ratios_3.insertPlainText(S)
        end = time.time()
        print("processing time {} seconds".format(round(end - start,2)))
        x=spectrum.mass
        y=spectrum.intensity
        spectrum['fit']=gaus(x,*popt)
        rmse=((spectrum.fit - spectrum.intensity) ** 2).mean() ** .5
        if not noshow==True:
            fig = plt.figure()
            plt.plot(x,y,'b+:',label='data')
            plt.plot(x,gaus(x,*popt),'ro:',label='fit')

            for f in range(len(L)):
                a=popt[f]
                b=popt[f+len(L)]
                c=popt[f+len(L)*2]              
                plt.plot(x,ga(x,a,b,c),label='fit {}'.format(f+1))

            plt.legend()
            plt.title(f'Fig. Gaussian fit  RMSE={round(rmse,8)}')
            plt.xlabel('m/z ')
            plt.ylabel('abundance')
            plt.show()
    def _propagate_limits_2(self):  # update entry in current database
        try:
            NEW_CONTENT = str(self.ui.plainTextEdit_annotations_4.toPlainText())
            IDs = str(self.ui.plainTextEdit_search_result_ID_4.toPlainText()).split(',')
            field = 'annotations'
            fname = str(self.ui.lineEdit_DB_file_3.text()).upper()
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            for ID in IDs:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                command = """UPDATE spectra SET {} ='{}'  WHERE ID = '{}'""".format(
                    field, NEW_CONTENT, ID)
                with conn:
                    c.execute(command)
        except:
            QMessageBox.about(
                self, "warning", "Operation failed. Check database.")
    def _fitAllGauss(self):
        self.ui.checkBox_cancel_messages.setChecked(True)
        START = time.time()

        try:
            IDs = str(self.ui.plainTextEdit_search_result_ID_4.toPlainText()).split(',')
            for ID in IDs:
                self.ui.lineEdit_ID_3.setText(ID)
                self._show_entry_3()
                self._fitGauss(noshow=True)
                self._update_3()      
            END = time.time()
            print("total processing time {} seconds".format(round(END - START,2)))

        except Exception as e:
            QMessageBox.about(self, "warning", "Processing of entry #{} failed. \nCheck if the spectrum exist. \nCheck input parameters.".format(ID))
            return
        QMessageBox.about(self, "warning",  "Finished processing. Last entry #{}.\ntotal processing time {} seconds".format(ID,round(END - START,2)))
    def _report_3(self):  # report for centroids or areas
        IDs = str(self.ui.plainTextEdit_search_result_ID_4.toPlainText()).split(',')
        fname = str(self.ui.lineEdit_DB_file_3.text()).upper()
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        DF = pandas.DataFrame()
        for id in IDs:
            if not id == '':
                with conn:
                    c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': id})
                ls = c.fetchall()
                file=ls[0][1]
                param = cPickle.loads(zlib.decompress(ls[0][16]))
                df = pandas.read_csv(StringIO(param), delim_whitespace=True,names=['L', 'A', 'sigma', 'area','f'],header=None)
                
                P=[file]+['Location']+list(df.L)+['Amplitude']+list(df.A)+['Sigma']+list(df.sigma)+['Area']+list(df.area)
                df = pandas.DataFrame(P)
                DF = pandas.concat([DF, df], axis=1)
        # print(DF.T)
        try:
            DF.T.to_csv('results/report4database_{}.csv'.format(fname.upper()), index=False)
        except:
            fname, ok = QInputDialog.getText(self, 'Input Dialog', 'Cannot save to file report4database_{}.csv. \nCheck if the file is opened in other program. Close it or enter a new file name:'.format(fname.upper()))
    def _paste_curve_3(self):
        '''curves paste initial series'''
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_curves.clear()
        self.ui.plainTextEdit_curves.insertPlainText(data)
    def _paste_curve_4(self):
        '''curves paste initial series'''
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_curves_2.clear()
        self.ui.plainTextEdit_curves_2.insertPlainText(data)
    def _calc_RF(self):
            from scipy.optimize import minimize
            statF=int(self.ui.lineEdit_statF.text())
            data=self.ui.plainTextEdit_curves.toPlainText()
            data= StringIO(data)
            data=pandas.read_csv(data,delim_whitespace=True,header=None,names=['A1','A2'])
            print(data)
            # if self.ui.checkBox_normbysum.isChecked():
                # data['sum']=data['A1']+data['A2']
                # data['A1']=data['A1']/data['sum']
                # data['A2']=data['A2']/data['sum']
            def cost(consts,ARGS):  #consts are the current parameters (rate constants)
                dt=ARGS  # the DataFrame with experimental data points
                #consts=tuple(np.exp(consts))
                a,f=consts
                dt['A3']=a+f*dt['A2']
                dt['res']=(dt['A1']-dt['A3'])**2
                #print(data)
                cost=dt['res'].sum(axis=0)
                #print(a,f,cost)
                return cost
            a_max=data['A1'].max()
            fmax=50
            initial_consts=np.log([a_max,fmax])
            bnds=[(0,np.log(a_max)),(0,np.log(fmax))]
            initial_consts=[a_max,fmax]
            bnds=[(0,a_max),(-fmax,fmax)]
            ARGS=data.copy()
            method='‘L-BFGS-B'
            mxiter=50000
            constants=minimize(cost,initial_consts,args=ARGS, options={'maxiter': mxiter, 'disp': True})

            # minimizer_kwargs = {"method":method, "args" :ARGS, "bounds":bnds}
            # temperature=200 #parameter used in basinhopping
            # stepsize=1 #parameter used in basinhopping
            #constants=minimize(cost,initial_consts,args=ARGS,method =method, options={'maxiter': 1000, 'disp': True})
            #constants=basinhopping(cost,initial_consts,minimizer_kwargs=minimizer_kwargs,niter=mxiter,disp=True,T=temperature,stepsize=stepsize)
            #constants=differential_evolution(cost, bnds, args=ARGS, strategy='best1bin', maxiter=10000, popsize=15, tol=0.01, mutation=(0.5, 1), recombination=0.7, seed=None, callback=None, disp=False, polish=True, init='latinhypercube', atol=0)
            
            f=np.abs(constants.x[1])
            data['A1']=statF*data['A1']
            data['A2']=data['A2']*f
            new=pandas.DataFrame()
            new['series 1']=data['A1']/(data['A1']+data['A2'])
            new['series 2']=data['A2']/(data['A1']+data['A2'])/statF
            
            self.ui.plainTextEdit_R_2.clear()
            self.ui.plainTextEdit_R_2.insertPlainText(new[['series 1','series 2']].to_string(index=None))
            self.ui.lineEdit_RF.clear()
            self.ui.lineEdit_RF.setText(str(round(f,4))) 
            if not self.ui.checkBox_plot_match.isChecked():
                new.plot()
            else:
                data['A1']=data['A1']/statF
                data['A2']=constants.x[0]+constants.x[1]*data['A2']/f
                plt.title('parameters a='+str(round(constants.x[0],4))+',  f='+str(round(constants.x[1],4)))

                data[['A1','A2']].plot()
            plt.title('parameters a='+str(round(constants.x[0],4))+',  f='+str(round(constants.x[1],4)))
            plt.show()
    def _applyFilters(self):
        df = pandas.read_csv(StringIO(str(self.ui.plainTextEdit_curves_2.toPlainText())), delim_whitespace=True,names=['ini'],header=None)
        print(df)
        try:
            if self.ui.radioButton_MA.isChecked():
                period = int(self.ui.lineEdit_periodMA.text())
                df['filt']=df['ini'].rolling(period).mean()       
                T='Data with Moving Average'
            if self.ui.radioButton_EMA.isChecked():
                period = int(self.ui.lineEdit_periodEMA.text())
                df['filt']=df['ini'].ewm(span=period).mean()
                T='Data with Exponential Moving Average'
            if self.ui.radioButton_MedianFilter.isChecked():
                period = int(self.ui.lineEdit_periodMedian.text())
                from scipy import ndimage
                df['filt']=ndimage.median_filter(df['ini'],size=period)
                T='Data with Median Filter'
            if self.ui.radioButton_SG.isChecked():           
                T='Data with Savitzky-Golay Filter'
                sgwin=int(self.ui.lineEdit_periodSG.text())
                period=sgwin
                sgorder=int(self.ui.lineEdit_orderSG.text())
                if not sgwin % 2 == 0:
                    if not sgwin < sgorder:
                        df['filt'] = sg(df['ini'].values,
                                      sgwin, sgorder)
                    else:
                        if not self.ui.checkBox_cancel_messages.isChecked():
                            QMessageBox.about(self, "warning", "Savitzky-Golay order must not be greater than window length")
                        else:
                            print("Savitzky-Golay order must not be greater than window length")
                else:
                    QMessageBox.about(self, "warning", "Savitzky-Golay window must be odd number")
        except:
            QMessageBox.about(self, "warning", "could not convert string to float")
            return

            
        df['std']=df.ini.rolling(period).std()
        print(df)
        S = swrm.nice_table(df, header=False)
        self.ui.plainTextEdit_R_4.clear()
        self.ui.plainTextEdit_R_4.insertPlainText(S)
        if self.ui.checkBox_plotRes.isChecked():
            df.dropna(inplace=True)

            fig = plt.figure()
            plt.plot(df.index,df.ini,'b+:',label='original')
            plt.plot(df.index,df.filt,'r+:',label='filtered')
            plt.plot(df.index,df.filt+df['std'],'y+:',label='filtered+std')
            plt.plot(df.index,df.filt-df['std'],'y+:',label='filtered-std')

            plt.legend()
            plt.title(T)
            plt.xlabel('index')
            plt.ylabel('data')
            plt.show()

################ KINETICS #################################################

    def _paste_curve(self):
        '''curves paste initial series'''
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_ini_curve.clear()
        self.ui.plainTextEdit_ini_curve.insertPlainText(data)
    def _copy_X(self):
        '''curvescopy newX'''
        pyperclip.copy(str(self.ui.plainTextEdit_newX.toPlainText()))
    def _copy_Y(self):
        '''curves copy newY'''
        pyperclip.copy(str(self.ui.plainTextEdit_newY.toPlainText()))
    def _plot_curve(self):
        '''plot curves'''
        rate=1.0/int(self.ui.lineEdit_rate_5.text())
        s=float(self.ui.lineEdit_smoothing.text())
        try:
            DATA=self.ui.plainTextEdit_ini_curve.toPlainText()
            DATA= StringIO(DATA)
            DATA=pandas.read_csv(DATA,delim_whitespace=True,header=None,names=['X','Y'])
            
            from scipy.interpolate import splev, splrep
            if not self.ui.checkBox_extrapolate.isChecked():
                xnew = np.arange(DATA.X.min(), DATA.X.max()+1, rate)

            else:
                xnew = np.arange(0, DATA.X.max()+1, rate)
        except:
            QMessageBox.about(
                self, "warning", "Can not process the data. Check that the data contain only numeric values.")
            return
        A=''
        for f in xnew:
            A=A+str(f)+'\n'
        spl = splrep(DATA.X, DATA.Y,s=s)
        ynew = splev(xnew, spl)
        B=''
        for f in ynew:
            B=B+str(f)+'\n'

        if not self.ui.checkBox_reciprocal.isChecked():
            if not self.ui.checkBox_gradient.isChecked():
                fig = plt.figure()
                ax = fig.add_subplot(111) 
                if not self.ui.checkBox_include_orig_series.isChecked():
                    ax.plot(xnew,ynew, color='red')
                else:
                    ax.scatter(DATA.X, DATA.Y, color='blue')
                    ax.plot(xnew,ynew,  color='red')
                
                plt.show()
            else:
                B=''
                for f in np.gradient(ynew)/rate:
                    B=B+str(f)+'\n'
            
                fig = plt.figure()
                ax = fig.add_subplot(111)            
                plt.plot(xnew,np.gradient(ynew)/rate, '-')
                plt.show()
        else:
            N=int(self.ui.lineEdit_n.text())
            A=''
            for f in 1/(1-ynew):
                A=A+str(f)+'\n'
            B=''
            for f in rate/np.gradient(ynew):
                B=B+str(f)+'\n'
            from scipy import stats
            slope, intercept, r_value, p_value, std_err = stats.linregress(1/(1-ynew), rate/np.gradient(ynew))
            self.ui.lineEdit_R2_2.clear()
            self.ui.lineEdit_R2_2.setText(str(round(r_value**2,6)))
            slope, intercept, r_value, p_value, std_err = stats.linregress(1/(1-ynew[:N]), rate/np.gradient(ynew[:N]))
            self.ui.lineEdit_KMvVmax.clear()
            self.ui.lineEdit_KMvVmax.setText(str(round(slope,5)))
            self.ui.lineEdit_KM.clear()
            self.ui.lineEdit_KM.setText(str(round(slope/intercept,5)))
            self.ui.lineEdit_Vmax.clear()
            self.ui.lineEdit_Vmax.setText(str(round(1/intercept,5)))
            self.ui.lineEdit_R2_3.clear()
            self.ui.lineEdit_R2_3.setText(str(round(r_value**2,6)))

            fig = plt.figure()
            ax = fig.add_subplot(111)            
            plt.scatter(1/(1-ynew),rate/np.gradient(ynew), color='blue')
            plt.show()

            
           
        self.ui.plainTextEdit_newX.clear()
        self.ui.plainTextEdit_newX.insertPlainText(A)
        self.ui.plainTextEdit_newY.clear()
        self.ui.plainTextEdit_newY.insertPlainText(B)
    def _get_rates(self):
        '''obtain rates from progress curves'''
        try:
            decimals=int(self.ui.lineEdit_decimals_3.text())
        except:
            QMessageBox.about(self, "warning", "integer expected as a number of decimal places")
            return
        DATA=self.ui.plainTextEdit_data_2.toPlainText()
        DATA= StringIO(DATA)
        DATA=pandas.read_csv(DATA,delim_whitespace=True,header=None)
        cols=list(DATA)
        DATA = DATA.rename(columns={cols[0]: 'time'})
        S=''
        if not self.ui.checkBox_single_curve.isChecked():
        
            LEN=len(list(DATA))-1
            for f in range(LEN):
                col=(list(DATA)[f+1])
                NF=np.polyfit(DATA.time,DATA[col],1)
                S=S+str(DATA[col].values[0])+'\t'+str(-NF[0])+'\n'

        else:
            try:
                N=int(self.ui.lineEdit_curveN.text())
            except:
                QMessageBox.about(self, "warning", "integer expected as a curve number")
                return
            if N+1>len(list(DATA)):
                QMessageBox.about(self, "warning", "invalid curve number")
                return
            print(cols)
            dif=(eval('DATA[{}]'.format(str(cols[N]))))
            slope = -pandas.Series(np.gradient(dif), DATA.time, name='slope')
            DATA['slope']=slope
            SL=pandas.DataFrame({'conc':dif,'slope':DATA.slope})
            S = swrm.nice_table(SL, header=False)
        self.ui.plainTextEdit_LBdata.clear()
        self.ui.plainTextEdit_LBdata.insertPlainText(S)
    def _None_linear_fit(self):
        '''non-linear fit to MM formula: rate=Vmax*S/(KM+S) '''
        from scipy.optimize import curve_fit
        try:
            decimals=int(self.ui.lineEdit_decimals_3.text())
        except:
            QMessageBox.about(self, "warning", "integer expected as a number of decimal places")
            return
        DATA=self.ui.plainTextEdit_LBdata.toPlainText()
        DATA= StringIO(DATA)
        DATA=pandas.read_csv(DATA,delim_whitespace=True,header=None)
        DATA.columns=['C', 'R']
        DATA.dropna(inplace=True)
        neg=sum(n < 0 for n in DATA.values.flatten())
        if neg>0:
            QMessageBox.about(self, "warning", "rates cannot be negative")
            return

        def func(S, Vm, KM):
            return Vm*S/(KM+S)
       
        popt, pcov = curve_fit(func, DATA.C, DATA.R)
        try:
            Vm=popt[0]
            Vmsd=round(sqrt(pcov[0][0]),decimals)
            KM=popt[1]
            KMsd=round(sqrt(pcov[1][1]),decimals)
            VmKM=round(Vm/KM,decimals)
            VmKMsd=abs(VmKM)*sqrt(pcov[0][0]/Vm/Vm+pcov[1][1]/KM/KM-pcov[0][1]/KM/Vm)
            VmKMsd=round(VmKMsd,decimals)
        except:
            QMessageBox.about(self, "warning", "some variances are negative")
            return
                
        self.ui.lineEdit_calKM_3.clear()
        self.ui.lineEdit_calKM_4.clear()
        self.ui.lineEdit_calVm_3.clear()
        self.ui.lineEdit_calVm_4.clear()
        self.ui.lineEdit_calVmKM.clear()
        self.ui.lineEdit_calVmKM_2.clear()
        try:
            self.ui.lineEdit_calVm_3.setText(str(round(Vm,decimals))) 
            self.ui.lineEdit_calVm_4.setText(str(round(Vmsd,decimals)))
            self.ui.lineEdit_calKM_3.setText(str(round(KM,decimals)))
            self.ui.lineEdit_calKM_4.setText(str(round(KMsd,decimals)))
            self.ui.lineEdit_calVmKM.setText(str(round(VmKM,decimals)))
            self.ui.lineEdit_calVmKM_2.setText(str(round(VmKMsd,decimals)))
        except:
            return
        #Plot results
        if self.ui.checkBox_replace.isChecked():
            plt.close('all')
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.set_xlabel('[S]o')
        ax.set_ylabel('rate')
        x= np.linspace(0,DATA.C.values.max(),num=200)
        y=Vm*x/(KM+x)
        fitDF=pandas.DataFrame({'x':x,'y':y})
        plt.plot(x,y, c='red')
        plt.scatter(DATA.C,DATA.R,)
        s='KM={},Vmax={},Vmax/KM={}'.format(round(KM),round(Vm,decimals),round(Vm/KM,decimals))
        plt.title('Non-linear fitting\n'+s)
        try:
            fitDF.to_csv('results/kinetics_results_fit.tsv',sep='\t',index=False)
            DATA.to_csv('results/kinetics_results_velosities.tsv',sep='\t',index=False)
        except:
            QMessageBox.about(self, "warning", "files results/kinetics_results_fit.tsv or/and results/kinetics_results_velosities.tsv might be opened")
            return
        plt.show()

        return
    def _LB_plot(self):
        '''Lineweaver–Burk plot'''
        decimals=int(self.ui.lineEdit_decimals.text())
        DATA=self.ui.plainTextEdit_LBdata.toPlainText()
        DATA= StringIO(DATA)
        DATA=pandas.read_csv(DATA,delim_whitespace=True,header=None)
        DATA.columns=['C', 'R']
        DATA['rC']=1/DATA.C
        DATA['rR']=1/DATA.R
        DATA.dropna(inplace=True)
        neg=sum(n < 0 for n in DATA.values.flatten())
        if neg>0:
            QMessageBox.about(self, "warning", "rates cannot ne negative")
            return
        try:
            NF=np.polyfit(DATA.rC,DATA.rR,1,cov=True)
            a=NF[0][0]
            b=NF[0][1]
            KM=a/b
            Vm=1/b
            vara=NF[1][0][0]
            varb=NF[1][1][1]
            covar=NF[1][0][1]
            Vmsd=sqrt(varb)*(Vm**2)
            KMsd=(a/b)*sqrt(vara**2/(a**2)+varb**2/(b**2)-2*covar/a/b)

        except:
            NF=np.polyfit(DATA.rC,DATA.rR,1)
            KM=NF[0]/NF[1]
            Vm=1/NF[1]  
        self.ui.lineEdit_calKM_3.clear()
        self.ui.lineEdit_calKM_4.clear()
        self.ui.lineEdit_calVm_3.clear()
        self.ui.lineEdit_calVm_4.clear()
        self.ui.lineEdit_calKM_3.setText(str(round(KM,decimals)))
        self.ui.lineEdit_calVm_3.setText(str(round(Vm,decimals)))
        try:
            self.ui.lineEdit_calVm_4.setText(str(round(Vmsd,decimals)))
            self.ui.lineEdit_calKM_4.setText(str(round(KMsd,decimals)))
        except:
            return
        #Plot results
        if self.ui.checkBox_replace.isChecked():
            plt.close('all')
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.set_xlabel('1/[S]o')
        ax.set_ylabel('1/rate')
        plt.plot([-b/a,DATA.rC.values.max()],[0,DATA.rC.values.max()*a+b], c='red')
        plt.scatter(DATA.rC,DATA.rR,)
        # plt.legend()
        plt.show()
        s='KM={},Vmax={},Vmax/KM={}'.format(round(KM),round(Vm,decimals),round(Vm/KM,decimals))
        plt.title('Lineweaver–Burk plot\n'+s)
        plt.show()

############################################################################
    def _sequence2mass(self):
        seq=str(self.ui.lineEdit_seq.text()).strip().replace(' ','').upper()
        res=''
        a=mass.most_probable_isotopic_composition(sequence=seq)
        M=mass.calculate_mass(composition=a[0])
        c=mass.Composition(sequence=seq)
        form=''
        for key in c:
            form=form+str(key)+str(c[key])
        form=form+'\t'+str(round(M,5))+'\n'
        self.ui.plainTextEdit_averagine_results.insertPlainText(form)
    def _plus(self):
        F1=str(self.ui.lineEdit_form_1.text()).strip()
        F2=str(self.ui.lineEdit_form_2.text()).strip()
        F3=combine_formulas(F1,F2)

        a=mass.most_probable_isotopic_composition(F3)
        mostprob=mass.calculate_mass(composition=a[0])
        monoisotopic=mass.calculate_mass(formula=F3)
        if self.ui.radioButton_monomass.isChecked():
            M=monoisotopic
        else:
            M=mostprob
        F4=F3+'\t'+str(round(M,5))
        self.ui.lineEdit_form_3.clear()
        self.ui.lineEdit_form_3.setText(F4) 
    def _minus(self):
        F1=str(self.ui.lineEdit_form_1.text()).strip()
        F2=str(self.ui.lineEdit_form_2.text()).strip()
        F3=substract_formulas(F1,F2)
        self.ui.lineEdit_form_3.clear()
        self.ui.lineEdit_form_3.setText(F3)
        a=mass.most_probable_isotopic_composition(F3)
        mostprob=mass.calculate_mass(composition=a[0])
        monoisotopic=mass.calculate_mass(formula=F3)
        # mass=formula2mass(F3)
        if self.ui.radioButton_monomass.isChecked():
            M=monoisotopic
        else:
            M=mostprob
        F4=F3+'\t'+str(round(M,5))
        self.ui.lineEdit_form_3.clear()
        self.ui.lineEdit_form_3.setText(F4)
    def _calc_averagine(self):  
        from pyteomics import mass    
        try:
            low = float(self.ui.lowMZ_2.text())
            high = float(self.ui.highMZ_2.text())
            spectrum = StringIO(str(self.ui.plainTextEdit_spectrum.toPlainText()))
            spectrum = pandas.read_csv(spectrum,delim_whitespace=True,header=None, names=['Mass', 'Intensity'])
            averagine_charge=float(self.ui.lineEdit_averagine_charge.text())   
            rate = float(self.ui.lineEdit_rate_4.text())
            padding= int(self.ui.lineEdit_padding.text())
            if self.ui.radioButton_from_range.isChecked():
                formula=averagine(spectrum,low,high,rate,padding,averagine_charge)
            else:
                formula=averagine(spectrum,low,low,rate,padding,averagine_charge)
            a=mass.most_probable_isotopic_composition(formula)
            M=mass.calculate_mass(composition=a[0])
            formula=formula+'\t'+str(round(M,5))+'\n'
            # self.ui.plainTextEdit_averagine_results.clear()
            self.ui.plainTextEdit_averagine_results.insertPlainText(formula)
        except:
            self.ui.plainTextEdit_averagine_results.insertPlainText('The spectrum might be missing.\n')

#########################COMMON###########################################

    def _show_entry_2(self):  # load entry from current database
        ID = str(self.ui.lineEdit_ID_2.text())
        fname = str(self.ui.lineEdit_DB_file_2.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            else:
                print("Database {} doesn't exist".format(fname.upper()))
            return
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            IDD = ls[0][0]
            self.ui.lineEdit_dirty_ID.clear()
            self.ui.lineEdit_dirty_ID.setText(str(IDD).strip())
            filename = ls[0][1]
            self.ui.lineEdit_filename_2.clear()
            self.ui.lineEdit_filename_2.setText(str(filename).strip())
            project = ls[0][2]
            self.ui.lineEdit_project.clear()
            self.ui.lineEdit_project.setText(str(project))
            operator = ls[0][3]
            self.ui.lineEdit_operator.clear()
            self.ui.lineEdit_operator.setText(str(operator))
            created_date = ls[0][4]
            self.ui.lineEdit_created_date.clear()
            self.ui.lineEdit_created_date.setText(str(created_date))
            type = ls[0][5]
            self.ui.lineEdit_type.clear()
            self.ui.lineEdit_type.setText(str(type))
            polarity = ls[0][6]
            if str(polarity) == 'Positive':
                self.ui.radioButton_plus.setChecked(True)
                self.ui.radioButton_minus.setChecked(False)
            else:
                self.ui.radioButton_plus.setChecked(False)
                self.ui.radioButton_minus.setChecked(True)

            formulas = ls[0][7]
            self.ui.plainTextEdit_formula.clear()
            self.ui.plainTextEdit_formula.insertPlainText(str(formulas))
            self.ui.plainTextEdit_formula_2.clear()
            self.ui.plainTextEdit_formula_2.insertPlainText(str(formulas))
            trap = ls[0][8]
            self.ui.lineEdit_trap.clear()
            self.ui.lineEdit_trap.setText(str(trap))
            trans = ls[0][9]
            self.ui.lineEdit_trans.clear()
            self.ui.lineEdit_trans.setText(str(trans))
            conditions = ls[0][10]
            self.ui.lineEdit_conditions.clear()
            self.ui.lineEdit_conditions.setText(str(conditions))
            peaks = ls[0][11]
            self.ui.plainTextEdit_annotations.clear()
            self.ui.plainTextEdit_annotations.insertPlainText(str(peaks))
            self.ui.plainTextEdit_annotations_3.clear()
            self.ui.plainTextEdit_annotations_3.insertPlainText(str(peaks))
            lig_name = ls[0][12]
            self.ui.lineEdit_lig_name.clear()
            self.ui.lineEdit_lig_name.setText(str(lig_name))
            comment = ls[0][14]
            self.ui.plainTextEdit_comment.clear()
            self.ui.plainTextEdit_comment.insertPlainText(comment)
            spectrum = ls[0][15]
            spectrum = cPickle.loads(zlib.decompress(spectrum))
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(spectrum)
            self.ui.plainTextEdit_spectrum_2.clear()
            self.ui.plainTextEdit_spectrum_2.insertPlainText(spectrum)
            ratios = ls[0][16]
            ratios = cPickle.loads(zlib.decompress(ratios))

            self.ui.plainTextEdit_ratios.clear()
            self.ui.plainTextEdit_ratios.insertPlainText(str(ratios))
            self.ui.plainTextEdit_ratios_2.clear()
            self.ui.plainTextEdit_ratios_2.insertPlainText(str(ratios))
            annotations = ls[0][17]
            self.ui.plainTextEdit_annotations_2.clear()
            self.ui.plainTextEdit_annotations_2.insertPlainText(str(annotations))

        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Enry {} doesn't exist in the database {}".format(ID, fname.upper()))
            else:
                print("Enry {} doesn't exist in the database {}".format(
                    ID, fname.upper()))
            return
        finally:
            conn.close()
    def _input_2(self):  # create new entry in current database
        fname = str(self.ui.lineEdit_DB_file_2.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename_2.text()).strip()
        spectrum = str(self.ui.plainTextEdit_spectrum_2.toPlainText())
        ratios = str(self.ui.plainTextEdit_ratios_2.toPlainText())
        # Compress:
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        annotations = str(self.ui.plainTextEdit_annotations_3.toPlainText())
        formulas = str(self.ui.plainTextEdit_formula_2.toPlainText())
        project = ''
        operator = ''
        type = ''
        polarity = ''
        trap = ''
        trans = ''
        conditions = ''
        peaks = ''
        lig_name = ''
        lig_mass = ''
        comment = ''
        from datetime import datetime
        created_date = str(datetime.now())
        self.ui.lineEdit_created_date.setText(created_date)
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        with conn:
            c.execute('SELECT max(rowid) FROM spectra')
            try:
                ID = c.fetchone()[0]+1
            except:
                ID = 1
            self.ui.lineEdit_ID_2.setText(str(ID))
            c.execute("SELECT * FROM spectra WHERE filename=:filename",
                      {'filename': filename})
            try:
                fn = c.fetchone()[1]
                QMessageBox.about(
                    self, "warning", "Item with file name {} already exists in the database. \nUse UPDATE to change it. ".format(fn))
            except:
                c.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                          'ID': ID, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum, 'ratios': ratios, 'annotations': annotations})
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "Message", "Entry added to database")
                else:
                    return
    def _update_2(self):  # update entry in current database
        ID = str(self.ui.lineEdit_ID_2.text())
        fname = str(self.ui.lineEdit_DB_file_2.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename_2.text()).strip()
        project = ''
        operator = ''
        type = ''
        polarity = ''
        trap = ''
        trans = ''
        conditions = ''
        lig_name = ''
        lig_mass = ''
        comment = ''
        peaks = ''
        
        spectrum = str(self.ui.plainTextEdit_spectrum_2.toPlainText())
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = str(self.ui.plainTextEdit_ratios_2.toPlainText())
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        annotations = str(self.ui.plainTextEdit_annotations_3.toPlainText())
        formulas = str(self.ui.plainTextEdit_formula_2.toPlainText())
        created_date = str(datetime.now())
        self.ui.lineEdit_created_date.setText(created_date)
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            date = ls[0][4]
            command = """UPDATE spectra SET filename='{}',project='{}',operator='{}',created_date='{}',type='{}',polarity='{}',formulas='{}',trap='{}',trans='{}',conditions='{}',peaks='{}',lig_name='{}',lig_mass='{}',comment='{}',annotations='{}'""".format(
                filename, project, operator, created_date, type, polarity, formulas, trap, trans, conditions, peaks, lig_name, lig_mass, comment, annotations)
            command = command+""" WHERE ID = '%s'""" % ID
            with conn:
                c.execute(command)
                c.execute(
                    """UPDATE spectra SET spectrum=?,ratios=? WHERE ID=?""", (spectrum, ratios, ID))

            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "message", "Entry updated")
            else:
                print("Entry updated")
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            else:
                print(
                    "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            return
        finally:
            conn.close()
    def _delete_entry_2(self):  # delete entry in current database
        fname = str(self.ui.lineEdit_DB_file_2.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return

        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        ID = str(self.ui.lineEdit_ID_2.text())
        if not self.ui.checkBox_cancel_messages.isChecked():
            question = QMessageBox.question(self, 'Message', "Are you sure you want to delete entry # {}?".format(
                ID), QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        else:
            question = 16384
        if question == 16384:
            with conn:
                c.execute("DELETE from spectra WHERE ID=:ID", {'ID': ID})
    def _paste_2(self):  # paste clipboard to plainTextEdit_spectrum
        data = pyperclip.paste()
        self.ui.plainTextEdit_spectrum_2.clear()
        self.ui.plainTextEdit_spectrum_2.insertPlainText(data)
    def _copy_original_2(self):  # copy original spectrum from database to clipboard
        s = str(self.ui.plainTextEdit_spectrum_2.toPlainText())
        pyperclip.copy(s)
    def _plot_DB_spectrum_2(self):  # plot spectrum from plainTextEdit_spectrum field
        import matplotlib.pyplot as plt
        Spectrum = StringIO(str(self.ui.plainTextEdit_spectrum_2.toPlainText()))
        df = pandas.read_csv(Spectrum, delim_whitespace=True, names=[
                               'Mass', 'Intensity'])
        linewidth = 1.0
        fontsize = 12.0
        offset = [0,0.5]
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels


        fig = plt.figure()
        ax = fig.add_subplot(111)

        plt.plot(df.Mass, df.Intensity, color='blue',
                 linewidth=linewidth, label='spectrum')

        plt.xlabel('m/z')
        plt.ylabel('Intensity')
        plt.show()
    def _propagate_limits(self):  # update entry in current database
        try:
            NEW_CONTENT = str(self.ui.plainTextEdit_annotations_3.toPlainText())
            IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
            field = 'peaks'
            fname = str(self.ui.lineEdit_DB_file_2.text()).upper()
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            for ID in IDs:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                command = """UPDATE spectra SET {} ='{}'  WHERE ID = '{}'""".format(
                    field, NEW_CONTENT, ID)
                with conn:
                    c.execute(command)
        except:
            QMessageBox.about(
                self, "warning", "Operation failed. Check database.")
    def _integrate(self):
    
        spectrum = str(self.ui.plainTextEdit_spectrum_2.toPlainText())# spectrum is loaded as str
        spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=[
                                     'Mass', 'Intensity'])  # spectrum is Pandas pandas.DataFrame
        limits = str(self.ui.plainTextEdit_annotations_3.toPlainText()).split('\n')
        rate = int(self.ui.lineEdit_rate_3.text())
        padding= int(self.ui.lineEdit_padding.text())
        
        centroid = ''
        area = ''
        Prod=0
        AR=0

        try:
            for f in enumerate(limits):
                if not len(f[1].split())==3:
                
                    print('f fail',f)
                    continue
                left = float(f[1].split()[1])
                right = float(f[1].split()[2])
                if self.ui.checkBox_chargeNormalize.isChecked():
                    ch=int(f[1].split()[0])
                else:
                    ch=1
                print(f)
                if self.ui.radioButton_resample.isChecked():
                    new = resample_spectrum(spectrum, left, right, rate,padding)

                else:
                    new = spectrum.copy()
                A=new.Intensity.sum()/ch
                area = area+str(round(A))+'\n'
                AR=AR+A
                COG = center_of_gravity(new, left, right,ch)
                Prod=Prod+COG*A
                
                COG = round(COG, 2)
                centroid = centroid+str(round(COG, 2))+'\n'
            cAVE=round(Prod/AR,2)
            if not self.ui.checkBox_average.isChecked():
                cAVE=''
            self.ui.plainTextEdit_ratios_2.clear()
            self.ui.plainTextEdit_ratios_2.insertPlainText(centroid+'\n'+str(cAVE))
            self.ui.plainTextEdit_formula_2.clear()
            self.ui.plainTextEdit_formula_2.insertPlainText(area)
        except Exception as e:
            QMessageBox.about(self, "warning", "Check if the spectrum exist. If you process high resolution spectrum increase sampling rate and padding ~10 fold. Check list of windows. Must contain 3 numbers")
            return
    def _centroids(self):
        self.ui.checkBox_cancel_messages.setChecked(True)
        try:
            IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
            for ID in IDs:
                self.ui.lineEdit_ID_2.setText(ID)
                self._show_entry_2()
                spectrum = str(self.ui.plainTextEdit_spectrum_2.toPlainText())# spectrum is loaded as str
                self._integrate()
                
                self._update_2()      
        except Exception as e:
            QMessageBox.about(self, "warning", "Check ID entries in Manage Database tab. Check if the spectrum exist.Check ID entries in Manage Database tab. If you process high resolution spectrum increase sampling rate and padding ~10 fold (padding may require more than 10).")
            return
    def _search_DB_2(self):  # database search engine
        fname = str(self.ui.lineEdit_DB_file_2.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            return
        self.ui.lineEdit_DB_donor.clear()
        self.ui.lineEdit_DB_donor.setText(fname.upper())
        n1 = 'filename'
        n2 = ''
        b1 = ''
        b12 = ''
        show1 = 'filename'
        show2 = 'filename'
        orderby = str(self.ui.comboBox_orderby_2.currentText())
        asdes = str(self.ui.comboBox_asdes_2.currentText())
        dt = ''
        if n1 == 'comment':
            m1 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n1 == 'annotations':
            m1 = str(self.ui.plainTextEdit_annotations_3.toPlainText())
        else:
            m1 = eval('''str(self.ui.lineEdit_{}_2.text()).strip()'''.format(n1))
        if n2 == 'comment':
            m2 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n2 == 'annotations':
            m2 = str(self.ui.plainTextEdit_annotations_3.toPlainText())
        elif n2 == '':
            m2 = ''
        else:
            m2 = eval('''str(self.ui.lineEdit_{}_2.text()).strip()'''.format(n2))
        s = ''
        id = ''
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            # try:
            if not n2 == '':
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} {} {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, b1, n2, b12, m2, dt, orderby, asdes))
            else:
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, dt, orderby, asdes))

            c.execute(sql)
            ls = c.fetchall()
            for f in ls:
                c.execute(
                    """SELECT {} FROM spectra WHERE ID = {}""".format(n1, f[0]))
                fn1 = c.fetchone()[0]
                if not n2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(n2, f[0]))
                    fn2 = c.fetchone()[0]
                sh1 = ''
                sh2 = ''
                if not show1 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show1, f[0]))
                    sh1 = c.fetchone()[0]
                if not show2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show2, f[0]))
                    sh2 = c.fetchone()[0]
                id = id+str(f[0])+','
                s = s+str(f[0])+'\t'+'\t'+str(sh1)+'\t'+str(sh2)+'\n'

            self.ui.plainTextEdit_search_result_2.clear()
            self.ui.plainTextEdit_search_result_2.insertPlainText(s)
            self.ui.plainTextEdit_search_result_ID_3.clear()
            self.ui.plainTextEdit_search_result_ID_3.insertPlainText(id[:-1])
            self.ui.plainTextEdit_search_result_ID.clear()
            self.ui.plainTextEdit_search_result_ID.insertPlainText(id[:-1])
        except Exception as e:
            print(e)
        finally:
            conn.close()
    def _report_2(self):  # report for centroids or areas
        IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
        fname = str(self.ui.lineEdit_DB_file_2.text()).upper()
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        DF1 = pandas.read_csv(StringIO(''), delim_whitespace=True,names=['file name'])
        DF2 = pandas.read_csv(StringIO(''), delim_whitespace=True,names=['file name'])
        for id in IDs:
            if not id == '':
                with conn:
                    c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': id})
                ls = c.fetchall()
                file = ls[0][1]
                com = ls[0][16]
                area = ls[0][7]
                M=len(area.split())
                com = cPickle.loads(zlib.decompress(com))
                N=len(com.split())
                line1 = com
                line2 = area
                df1 = pandas.read_csv(StringIO(line1),delim_whitespace=True, names=[file])
                DF1 = pandas.concat([DF1, df1], axis=1)
                df2 = pandas.read_csv(StringIO(line2),delim_whitespace=True, names=[file])
                DF2 = pandas.concat([DF2, df2], axis=1)
        cols=[]
        for f in range(N):
            cols.append('CoM'+str(f+1))
        DF1=DF1.T
        DF1.columns = cols
        cols=[]
        DF1=DF1.T
        for f in range(M):
            cols.append('area'+str(f+1))
        DF2=DF2.T
        DF2.columns = cols
        DF2=DF2.T
        DF3=pandas.concat([DF1, DF2], axis=0)
        try:
            DF3.T.to_csv('results/report4database_{}.csv'.format(fname.upper()), index=True)
        except:
            fname, ok = QInputDialog.getText(self, 'Input Dialog', 'Cannot save to file report4database_{}.csv. \nCheck if the file is opened in other program. Close it or enter a new file name:'.format(fname.upper()))
            DF3.T.to_csv('results/{}.csv'.format(fname.upper()), index=False)

############### AUTOMATION INPUT################################################
    def _enter_kinetics_X(self): #Process X-calibur chromatogram
        import time
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \npip install pyautogui")    
        from ctypes import windll
        if windll.user32.OpenClipboard(None):
            windll.user32.EmptyClipboard()
            windll.user32.CloseClipboard()
        # pyperclip.copy('')
        try:
            fi=str(self.ui.kinetics_file.text()).strip()
            self.ui.checkBox_cancel_messages.setChecked(True)
            pyautogui.PAUSE = 1
            pyautogui.FAILSAFE = True
            period=float(self.ui.kinetics_period_2.text()) 
            numdata_2=int(self.ui.numdata_2.text()) 
            start_collection=float(self.ui.start_data_collection.text())
            delay=int(self.ui.delay_2.text()) 
            X_spectrum_coords=str(self.ui.X_spectrum_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
            Xcoords=str(self.ui.Xcoords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
            SWARMcoords=str(self.ui.SWARMcoords2.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
            S=''
            SS=''
            for f in range(numdata_2):
                self.ui.plainTextEdit_spectrum.clear()
                start=start_collection+f*period
                self.ui.lineEdit_filename.setText(fi+str(start))
                pyautogui.click(int(Xcoords[0]),int(Xcoords[1]), button='left')
                pyautogui.hotkey('alt', 'D')
                pyautogui.hotkey('R')
                pyautogui.hotkey('alt', 'T')
                pyautogui.typewrite('{}-{}'.format(str(start),str(start+period)))
                pyautogui.press('enter')
                # time.sleep(delay)
                pyautogui.click(int(X_spectrum_coords[0]),int(X_spectrum_coords[1]), button='left')
                pyautogui.click(int(X_spectrum_coords[0]),int(X_spectrum_coords[1]), button='right')
                pyautogui.hotkey('E')
                pyautogui.press('enter')
                # clip=QApplication.clipboard().text()
                time.sleep(delay)
                windll.user32.CloseClipboard()
                clip = pyperclip.paste()
                S=S+clip.split('\n')[4].split(':')[1]+'\n'
                SS=SS+clip.split('\n')[3].split(':')[1]+'\n'
                print(S,SS)
                # time.sleep(1)
                pyautogui.click(int(SWARMcoords[0]),int(SWARMcoords[1]), button='left')
                clip = '\n'.join(clip.split('\n')[10:])
                self.ui.plainTextEdit_spectrum.insertPlainText(clip)
                # time.sleep(1)
                self._input()
                # time.sleep(1)

        except Exception as e:
            QMessageBox.about(self, "warning",str(e))    
            print(str(e))
            return
        with open('results/kinetics_samples_minutes.txt','w') as q:
            q.write(S)
        with open('results/kinetics_samples_scans.txt','w') as q:
            q.write(SS)

    def _enter_kinetics_ML(self): #Process WATERS MassLynx chromatogram
        import time
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \npip install pyautogui")    
        try:
            fi=str(self.ui.kinetics_file.text()).strip()
            self.ui.checkBox_cancel_messages.setChecked(True)
            pyautogui.PAUSE = 1
            pyautogui.FAILSAFE = True
            numscans=int(self.ui.numscans.text())
            # period=int(self.ui.kinetics_period.text()) 
            numdata=int(self.ui.numdata.text()) 
            delay=int(self.ui.delay.text()) 
            chromatogram=str(self.ui.chromatogram.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
            lynx=str(self.ui.lynx.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
            SWARMcoords=str(self.ui.SWARMcoords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
            start=1        
            for f in range(numdata):
                # start=f*period*30
                self.ui.plainTextEdit_spectrum.clear()

                self.ui.lineEdit_filename.setText(fi.strip()+str(start))
                pyautogui.click(int(chromatogram[0]),int(chromatogram[1]), button='left')
                pyautogui.hotkey('alt', 'p','c')
                # if start==0:
                    # pyautogui.typewrite('{}:{}'.format(str(start+1),str(start+numscans)))
                # else:
                pyautogui.typewrite('{}:{}'.format(str(start),str(start-1+numscans)))
                pyautogui.press('enter')
                time.sleep(delay)
                pyautogui.hotkey('alt', 'e','l')
                time.sleep(1)
                clip=QApplication.clipboard().text()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f','x')
                pyautogui.click(int(SWARMcoords[0]),int(SWARMcoords[1]), button='left')
                self.ui.plainTextEdit_spectrum.insertPlainText(clip)
                time.sleep(1)
                self._input()
                time.sleep(1)
                start=start+numscans
        except Exception as e:
            QMessageBox.about(self, "warning",str(e))    
            print(str(e))

    def _input_bruker_spectra(self):  # create new entry in current database from bruker_spectra
        original_path="C:\\Users\\pk\\Desktop\\CoM"
        original_path=str(self.ui.original_path.text())

        fid = os.listdir(original_path+'\\bruker_spectra')
        low=float(self.ui.low_lim.text())
        high=float(self.ui.upper_lim.text())
        print(fid)
        for fi in fid:
            fname = str(self.ui.lineEdit_DB_file.text()).upper()
            DBs = self._show_DB(noshow=True)
            if not fname in DBs:
                print("Database {} doesn't exist".format(fname.upper()))
                return
            filename = fi#str(self.ui.lineEdit_filename.text()).strip()
            project = str(self.ui.lineEdit_project.text())
            operator = str(self.ui.lineEdit_operator.text())
            type = str(self.ui.lineEdit_type.text())
            if self.ui.radioButton_plus.isChecked() == True:
                polarity = 'Positive'
            else:
                polarity = 'Negative'
            formulas = str(self.ui.plainTextEdit_formula.toPlainText())
            trap = str(self.ui.lineEdit_trap.text())
            trans = str(self.ui.lineEdit_trans.text())
            conditions = str(self.ui.lineEdit_conditions.text())
            peaks = str(self.ui.plainTextEdit_annotations.toPlainText())
            lig_name = ''
            lig_mass = ''
            
            
            
            spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
            spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, 
                names=['Mass', 'Intensity'])  # now spectrum is a pandas.DataFrame
            spectrum.sort_values(by='Mass', inplace=True)
            spectrum =spectrum.to_string(header=False, index=False)
            # print(spectrum)  
            
            f=original_path+'\\bruker_spectra'+'\\'+fi
            print(f)
            spectrum=pandas.read_csv(f,delim_whitespace=True, names=['Mass', 'Label'])
            spectrum=spectrum[spectrum.Mass>=low]
            spectrum=spectrum[spectrum.Mass<=high]
            spectrum =spectrum.to_string(header=False, index=False)

            print(spectrum)
            
            ratios = str(self.ui.plainTextEdit_ratios.toPlainText())
            # Compress:
            spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
            ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
            annotations = str(self.ui.plainTextEdit_annotations_2.toPlainText())
            from datetime import datetime
            created_date = str(datetime.now())
            self.ui.lineEdit_created_date.setText(created_date)
            comment = str(self.ui.plainTextEdit_comment.toPlainText())
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute('SELECT max(rowid) FROM spectra')
                try:
                    ID = c.fetchone()[0]+1
                except:
                    ID = 1
                self.ui.lineEdit_ID.setText(str(ID))
                c.execute("SELECT * FROM spectra WHERE filename=:filename",
                          {'filename': filename})
                try:
                    fn = c.fetchone()[1]
                    QMessageBox.about(
                        self, "warning", "Item with file name {} already exists in the database. \nUse UPDATE to change it. ".format(fn))
                except:
                    c.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                              'ID': ID, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum, 'ratios': ratios, 'annotations': annotations})
                    if not self.ui.checkBox_cancel_messages.isChecked():
                        QMessageBox.about(
                            self, "Message", "Entry added to database")
                    # else:
                        # return

    def _get_bruker_spectra(self):     
        import time
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \npip install pyautogui")    
        try:
            original_path=str(self.ui.original_path.text())
            bs=original_path+'\\bruker_spectra'
            if not os.path.exists(bs):
                os.mkdir(bs)
            self.ui.checkBox_cancel_messages.setChecked(True)
            pyautogui.PAUSE = 1
            pyautogui.FAILSAFE = True
            #get files list
            fid = os.listdir(original_path)
            pyautogui.hotkey('alt', 'tab')
            for fi in fid:
                if fi[-2:]=='.d':
                    f=original_path+'\\'+fi
                    pyautogui.hotkey('alt', 'f','o')
                    pyautogui.hotkey('alt', 'f')
                    pyautogui.typewrite(f)
                    pyautogui.press('enter')
                    time.sleep(int(self.ui.delay_fid.text()))
                    pyautogui.hotkey('alt', 'f','e','s')
                    print(bs+'\\'+fi[:-2])
                    pyautogui.typewrite(bs+'\\'+fi[:-2])
                    pyautogui.hotkey('alt', 't')
                    pyautogui.typewrite('s')
                    pyautogui.press('enter')
                    # pyautogui.press(['enter','enter'])
                    time.sleep(int(self.ui.delay_saving.text()))
                    pyautogui.hotkey('alt', 'f','c')
           
        except Exception as e:
            QMessageBox.about(self, "warning",str(e))    
            print(str(e))
    def _get_cursor(self): # obtain cursor position and show it in screen window
        import pyautogui
        x,y=pyautogui.position()
        self.ui.cursor.setText(str(x)+','+str(y))
        width, height = pyautogui.size()
        self.ui.screen.setText('{}x{}'.format(width, height))
        
        s = str(x)+','+str(y)
        pyperclip.copy(s)

################Adduct enumeration block###############################################################

    def _import_settings(self):
        ID = str(self.ui.lineEdit_ID.text())
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        with conn:
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            settings = ls[0][12].split('\n')
        for line in settings:
            # print(line)
            p = line.split('@')
            if p[0] in self.pars1:
                S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:]))
                a = eval(S)
            if p[0] in self.pars2:
                S = "self.ui.%s.clear()" % (p[0])
                a = eval(S)
                SS = "self.ui.%s.insertPlainText('%s')" % (
                    p[0], str(p[1][:]).replace('$', '\\n'))
                b = eval(SS)
            if p[0] in self.pars3:
                if eval(str(p[1][:])) == True:
                    S = "self.ui.%s.setChecked(True)" % (p[0])
                    a = eval(S)
                else:
                    S = "self.ui.%s.setChecked(False)" % (p[0])
                    a = eval(S)
    # def _report(self):  # report for centroids or areas
        # IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
        # fname = str(self.ui.lineEdit_DB_file.text()).upper()
        # conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        # c = conn.cursor()
        # DF = pandas.read_csv(StringIO(''), delim_whitespace=True,names=['file name'])
        # for id in IDs:
            # if not id == '':
                # with conn:
                    # c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': id})
                # ls = c.fetchall()
                # file = ls[0][1]
                # ratios = ls[0][16]
                # conditions = ls[0][10]
                # ratios = cPickle.loads(zlib.decompress(ratios))
                # line = ratios
                # df = pandas.read_csv(StringIO(line),delim_whitespace=True, names=[file])
                # DF = pandas.concat([DF, df], axis=1)
        # try:
            # DF.T.to_csv('results/report4database_{}.csv'.format(fname.upper()), index=False)
        # except:
            # fname, ok = QInputDialog.getText(self, 'Input Dialog', 'Cannot save to file report4database_{}.csv. \nCheck if the file is opened in other program. Close it or enter a new file name:'.format(fname.upper()))
            # DF.T.to_csv('results/{}.csv'.format(fname.upper()), index=False)
    def _correct_mass(self):
        self._enumerate_adducts()
        time.sleep(0.1)
        self._cp_ref()
        time.sleep(0.1)
        self._cp_specific()
        time.sleep(0.1)
        self._annotate()
        time.sleep(0.1)
        # reference protein binds every ligand non-specifically
        Ref = str(self.ui.plainTextEdit_Ref.toPlainText()).strip()
        # receptor protein binds some ligands specifically and non-specifically
        P = str(self.ui.plainTextEdit_proteins.toPlainText()).strip()
        # receptor protein binds some ligands specifically and non-specifically
        AN = str(self.ui.plainTextEdit_annotations.toPlainText()).strip()
        try:
            P = pandas.read_csv(
                StringIO(P), delim_whitespace=True, header=None)
            Ref = pandas.read_csv(
                StringIO(Ref), delim_whitespace=True, header=None)
            AN = pandas.read_csv(
                StringIO(AN), delim_whitespace=True, header=None)
            P.columns = ['label', 'mass', 'minimum', 'maximum']
            Ref.columns = ['label', 'mass', 'minimum', 'maximum']
            AN.columns = ['mass', 'intensity', 'delta', 'label']
        except:
            QMessageBox.about(
                self, "warning", "Some data are missing in Peak peaking,Receptor or Reference lists.")
            return
        try:
            NewMasses = []
            for p in P['label'].values:
                ANN = (AN[AN.label.str.contains(p+'_')])
                M = []
                for line in ANN.to_string(header=None, index=None).split('\n'):
                    intensity = line.split()[0]
                    ch = line.split()[3].split('_')[1][:-1]
                    sign = line.split()[3].split('_')[1][-1]
                    mass = eval(
                        '{}*{}{}{}*(-1)'.format(intensity, ch, sign, ch))
                    M.append(mass)
                NewMasses.append(round(np.mean(M), 2))
            P['mass'] = NewMasses
            newreceptor = swrm.nice_table(P, header=False)
            self.ui.plainTextEdit_proteins.clear()
            self.ui.plainTextEdit_proteins.insertPlainText(newreceptor)
        except:
            QMessageBox.about(self, "warning", "Receptor protein is missing.")
            return
        try:
            NewMasses = []
            for p in Ref['label'].values:
                ANN = (AN[AN.label.str.contains(p+'_')])
                M = []
                for line in ANN.to_string(header=None, index=None).split('\n'):
                    intensity = line.split()[0]
                    ch = line.split()[3].split('_')[1][:-1]
                    sign = line.split()[3].split('_')[1][-1]
                    mass = eval(
                        '{}*{}{}{}*(-1)'.format(intensity, ch, sign, ch))
                    M.append(mass)
                NewMasses.append(round(np.mean(M), 2))
            Ref['mass'] = NewMasses
            newref = swrm.nice_table(Ref, header=False)
            self.ui.plainTextEdit_Ref.clear()
            self.ui.plainTextEdit_Ref.insertPlainText(newref)
        except:
            QMessageBox.about(self, "warning", "Reference protein is missing.")
            return
        self._enumerate_adducts()

        return
    def _enumerate_adducts(self):
        if self.ui.checkBox_use_database_settings_2.isChecked():
            ID = str(self.ui.lineEdit_ID.text())
            fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                ls = c.fetchall()
                settings = ls[0][12].split('\n')
            for line in settings:
                # print(line)
                p = line.split('@')
                if p[0] in self.pars1:
                    S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:]))
                    a = eval(S)
                if p[0] in self.pars2:
                    S = "self.ui.%s.clear()" % (p[0])
                    a = eval(S)
                    SS = "self.ui.%s.insertPlainText('%s')" % (
                        p[0], str(p[1][:]).replace('$', '\\n'))
                    b = eval(SS)
                if p[0] in self.pars3:
                    if eval(str(p[1][:])) == True:
                        S = "self.ui.%s.setChecked(True)" % (p[0])
                        a = eval(S)
                    else:
                        S = "self.ui.%s.setChecked(False)" % (p[0])
                        a = eval(S)

        # Ref (reference protein) binds every ligand non-specifically
        Ref = StringIO(str(self.ui.plainTextEdit_Ref.toPlainText()).strip())
        # P (receptor protein) binds some ligands specifically and non-specifically
        P = StringIO(str(self.ui.plainTextEdit_proteins.toPlainText()).strip())
        # L binds receptor and reference both specifically and non-specifically
        L = StringIO(
            str(self.ui.plainTextEdit_specific_ligands.toPlainText()).strip())
        # N binds proteins non-specifically
        N = StringIO(
            str(self.ui.plainTextEdit_nonspecific_ligands.toPlainText()).strip())
        # binds proteins non-specifically
        IONS = StringIO(str(self.ui.plainTextEdit_ions.toPlainText()).strip())
        try:
            Ref = pandas.read_csv(Ref, delim_whitespace=True, header=None)
        except:
            QMessageBox.about(self, "warning", "Reference protein is missing.")
            Ref = pandas.DataFrame(columns=['label', 'mass'])
            return
        try:
            P = pandas.read_csv(P, delim_whitespace=True, header=None)
        except:
            QMessageBox.about(self, "warning", "Receptor protein is missing.")
            P = pandas.DataFrame(columns=['label', 'mass'])
            return
        try:
            L = pandas.read_csv(L, delim_whitespace=True, header=None)
        except:
            # QMessageBox.about(self, "warning", "Specific ligands are missing.")
            L = pandas.DataFrame(columns=['label', 'mass'])
            # return
        try:
            N = pandas.read_csv(N, delim_whitespace=True, header=None)
            N.columns = ['label', 'mass']

        except:
            N = pandas.DataFrame(columns=['label', 'mass'])
            # return
        try:
            IONS = pandas.read_csv(IONS, delim_whitespace=True, header=None)
            IONS.columns = ['label', 'mass']
        except:
            # QMessageBox.about(self, "warning","Length mismatch. Check imput format for correct number of columns for ions.")
            IONS = pandas.DataFrame(columns=['label', 'mass'])
            # return
        if self.ui.checkBox_polarity.isChecked():
            charge = 1
            sign = '+'
        else:
            charge = -1
            sign = '-'
        # Lnum=int(self.ui.lineEdit_Lnum.text())
        try:
            Nnum = int(self.ui.lineEdit_Nnum.text())
        except:
            QMessageBox.about(self, "warning","Integer is expected for the number of nonspecific ligands.")
            return
        Nnum2 = int(self.ui.lineEdit_Nnum_2.text())
        decimals = int(self.ui.lineEdit_decimals.text())
        try:
            P.columns = ['label', 'mass', 'minimum', 'maximum']
            Ref.columns = ['label', 'mass', 'minimum', 'maximum']
            L.columns = ['label', 'mass']
        except:
            QMessageBox.about(
                self, "warning", "Length mismatch. Check imput format for correct number of columns.")
            return
        lb = []
        for f in L.label:
            lb.append(f.upper())
        L.label = lb
        lb = []
        for f in N.label:
            lb.append(f.lower())
        N.label = lb
        # combine specific and non-specific ligands
        Lk = []
        for lb in L.label:
            Lk.append(lb.lower())
        LL = pandas.DataFrame(columns=['label', 'mass'])
        LL.label = Lk
        LL.mass = L.mass
        NL = pandas.concat([LL, N])

        # generate df with specific complexes
        PL = swrm.enumerate_DETACHED(L, Nnum2)  # enumerate detached adducts
        PP = swrm.addDetached(P, PL)
        PP = pandas.concat([P, PP])

        # Combine specific complexes with DETACHED
        PN = swrm.enumerate_DETACHED(NL, Nnum)  # enumerate detached adducts
        # non-specific complexes with P and PL complexes
        PPN = swrm.addDetached(PP, PN)

        # Combine Ref with DETACHED
        RefN0 = swrm.addDetached(Ref, PN)  # non-specific complexes with Ref
        RefN = pandas.concat([Ref, RefN0])

        # create formulas
        denom = '('
        set_ref = list(set(RefN.label.values))
        set_ref.sort()

        for f in set_ref:
            denom = denom+f+'+'
        denom = denom[:-1]+')'

        # generate df with low MW compounds
        L = pandas.concat([L, N])
        low = [1]*len(L)
        high = [3]*len(L)
        L['minimum'] = low
        L['maximum'] = high
        try:
            LL = swrm.addDetached(L, IONS)
        except:
            pass
        L = pandas.concat([L, LL])
        form = ''
        F = ''
        form1 = ''
        F1 = ''
        # create formulas
        # if self.ui.radioButton_fractions.isChecked() == True:
        set_ref = RefN.label.values
        for f in set_ref:
            form = form+f+'/'+denom+',\n'
            F = F+'F({})\n'.format(f)
        form = form[:-2]
        # elif self.ui.radioButton_Rvalues.isChecked() == True:
        set_ref = RefN.label.values
        for f in set_ref:
            form = form+f+'/Ref,'+'\n'
            F = F+'R({})\n'.format(f)
        for p in P.label:
            form = form[:-1]
            PP = pandas.concat([PP, PPN])
            RP = (PP[PP.label.str.contains(p)])
            set_ref = RP.label.values
            for f in set_ref:
                form1 = form1+'{}/{},\n'.format(f, p)
                F1 = F1+'R({})\n'.format(f)
            form = form+'\n'+form1
            F = F+F1
            form1 = ''
            F1 = ''
        form = form[:-2]
        # elif self.ui.radioButton_intensities.isChecked() == True:
        RefN1 = pandas.concat([RefN, PP, PPN])
        set_ref = RefN1.label.values
        set_mass = RefN1.mass.values
        form = ''
        molmass = ''
        F = ''
        for f in set_ref:
            form = form+f+',\n'
            F = F+'ab({})\n'.format(f)
        form = form[:-2]
        for f in set_mass:
            molmass = str(molmass)+str(f)+'\n'
        molmass = molmass[:-2]

        ##########
        try:
            lowMW = (swrm.apply_charge_distribution(L, sign, decimals))
            lowMW = swrm.nice_table(lowMW, header=False)
            self.ui.plainTextEdit_lowMW.clear()
            self.ui.plainTextEdit_lowMW.insertPlainText(lowMW)
        except:
            pass
        try:
            specific = (swrm.apply_charge_distribution(PP, sign, decimals))
            specific = swrm.nice_table(specific, header=False)
            self.ui.plainTextEdit_enumerated_specific.clear()
            self.ui.plainTextEdit_enumerated_specific.insertPlainText(specific)
        except:
            pass
        try:
            nonspecific = (swrm.apply_charge_distribution(PPN, sign, decimals))
            nonspecific = swrm.nice_table(nonspecific, header=False)
            # self.ui.plainTextEdit_enumerated_nonspecific.clear()
            # self.ui.plainTextEdit_enumerated_nonspecific.insertPlainText(nonspecific)
        except:
            pass
        try:
            reference = (swrm.apply_charge_distribution(RefN, sign, decimals))
            reference = swrm.nice_table(reference, header=False)
            self.ui.plainTextEdit_enumerated_reference.clear()
            self.ui.plainTextEdit_enumerated_reference.insertPlainText(reference)
        except:
            pass
    def _cp_specific(self):
        s = str(self.ui.plainTextEdit_enumerated_specific.toPlainText())
        try:
            pyperclip.copy(s)
            data = pyperclip.paste()
            self.ui.plainTextEdit_annotations_2.insertPlainText(data)
        except:
            QMessageBox.about(
                self, "warning", "Could not copy clipboard data.")
            return
    def _cp_ref(self):
        s = str(self.ui.plainTextEdit_enumerated_reference.toPlainText())
        try:
            pyperclip.copy(s)
            data = pyperclip.paste()
            self.ui.plainTextEdit_annotations_2.insertPlainText(data)
        except:
            QMessageBox.about(
                self, "warning", "Could not copy clipboard data.")
            return
    def _cp_lowMW(self):
        s = str(self.ui.plainTextEdit_lowMW.toPlainText())
        try:
            pyperclip.copy(s)
            data = pyperclip.paste()
            self.ui.plainTextEdit_annotations_2.insertPlainText(data)
        except:
            QMessageBox.about(
                self, "warning", "Could not copy clipboard data.")
            return
    def _cp_refform(self):
        s = str(self.ui.plainTextEdit_adducts_distribution.toPlainText())
        try:
            pyperclip.copy(s)
            data = pyperclip.paste()
            self.ui.plainTextEdit_formula.insertPlainText(data)
        except:
            QMessageBox.about(
                self, "warning", "Could not copy clipboard data.")
            return
    def _cp_ALL(self):
        self.ui.plainTextEdit_annotations_2.clear()
        self.ui.plainTextEdit_formula.clear()
        if self.ui.checkBox_autoS.isChecked():
            self._cp_specific()
            time.sleep(0.1)
        if self.ui.checkBox_autoR.isChecked():
            self._cp_ref()
            time.sleep(0.1)
        # if self.ui.checkBox_autoN.isChecked():
            # self._cp_mix()
            # time.sleep(0.1)
        if self.ui.checkBox_autoLOW.isChecked():
            self._cp_lowMW()
            time.sleep(0.1)
        # if self.ui.checkBox_autoF.isChecked():
            # self._cp_refform()

        return
    def _sort_annotations_by_mass(self):
        # binds proteins non-specifically
        AN = StringIO(
            str(self.ui.plainTextEdit_annotations.toPlainText()).strip())
        try:
            ANN = pandas.read_csv(AN, delim_whitespace=True, header=None)
            ANN.sort_values(by=[0], inplace=True)
            S = swrm.nice_table(ANN,header=False)
            self.ui.plainTextEdit_annotations.clear()
            self.ui.plainTextEdit_annotations.insertPlainText(S)

        except:
            QMessageBox.about(self, "warning", "Cannot sort. Peak picking list is empty.")
            return
    def _adduct_correction(self):
        accuracy = 1
        refcode = str(self.ui.lineEdit_refcode.text()).strip()
        Pcode = str(self.ui.lineEdit_Pcode.text()).strip().upper()
        # self.ui.radioButton_fractions.setChecked(False)
        # self.ui.radioButton_Rvalues.setChecked(False)
        # self.ui.radioButton_intensities.setChecked(True)
        self._enumerate_adducts()
        spec_form = StringIO(
            str(self.ui.plainTextEdit_adducts_distribution_2.toPlainText()).strip())
        self._cp_ALL()
        self._annotate()
        self._calculate_ratios_from_formula()
        code = str(self.ui.plainTextEdit_adducts_distribution_2.toPlainText()).strip(',').split(',')
        mass = str(self.ui.plainTextEdit_molmass_2.toPlainText()).strip().split()
        intensity = str(self.ui.plainTextEdit_ratios.toPlainText()).strip()
        self.ui.plainTextEdit_ratios_2.clear()
        self.ui.plainTextEdit_ratios_2.insertPlainText(intensity)
        intensity = intensity.split()
        uppercode = []
        for f in code:
            uppercode.append(f.strip())
        D = {}
        D['code'] = uppercode
        D['mass'] = mass
        D['intensity'] = intensity
        df = pandas.DataFrame(D)
        df.mass = df.mass.astype(dtype='float').round(accuracy)
        df.intensity = df.intensity.astype(dtype='float')
        df.drop_duplicates(['mass'], inplace=True)
        df.sort_values(by=['mass'], inplace=True)
        df = df.reset_index(drop=True)
        Refdistribution = df[df.code.str.contains(refcode)].copy()
        Corrected = df[df.code.str.contains(refcode) == False].copy()
        deconvoluted = swrm.nice_table(Corrected)
        self.ui.plainTextEdit_deconvoluted_spectrum.clear()
        self.ui.plainTextEdit_deconvoluted_spectrum.insertPlainText(deconvoluted)

        c = Refdistribution.mass.values[0]
        Refdistribution['dif'] = Refdistribution.mass-c
        specific = []
        for f in uppercode:
            if f.isupper():
                specific.append(f)
        for complex in specific:
            a = Refdistribution.intensity[0]
            b = Corrected.intensity[Corrected.code ==
                                    complex.strip()].values[0]
            c = Corrected.mass[Corrected.code == complex.strip()].values[0]
            F = a/b
            Refdistribution.intensity = Refdistribution.intensity/F
            Corrected['dif'] = Corrected.mass-c
            MASS = []
            for m in range(len(Refdistribution.dif)):
                CODE, INT, MASS, DIF = Refdistribution.values[m]
                for index, row in Corrected.iterrows():
                    if abs(row['dif']-DIF) < 0.1:
                        new_int = row['intensity']-INT
                        ind = index
                        if not row['code'] == complex:
                            Corrected.at[ind, 'intensity'] = new_int
        Corrected = Corrected.drop(['dif'], axis=1).round(1)
        corr = swrm.nice_table(Corrected).strip()
        sp = ''
        for line in corr.split('\n'):
            for f in specific:
                if line.split()[0] == f:
                    sp = sp+line

        self.ui.plainTextEdit_deconvoluted_spectrum_2.clear()
        self.ui.plainTextEdit_deconvoluted_spectrum_2.insertPlainText(corr)
        self.ui.plainTextEdit_specific.clear()
        self.ui.plainTextEdit_specific.insertPlainText(sp)

    ########## BINDING block###################
    
    def _interface_font(self):
        with open('swarm_module/SWARM.ui', 'r') as q:
            lines = q.read()
            lineEdit_fontsize = str(
                self.ui.lineEdit_global_font.text()).strip()
            for f in range(1, 20):
                oldfont = '<pointsize>{}<'.format(str(f))
                newfont = '<pointsize>{}<'.format(lineEdit_fontsize)
                lines = lines.replace(oldfont, newfont)
        with open('swarm_module/SWARM.ui', 'w') as q:
            q.write(lines)

    def _calc_Kd(self):
        pandas.set_option("display.precision", 10)
        pandas.set_option('display.float_format', '{:.3E}'.format)
        try:
            L = StringIO(str(self.ui.plainTextEdit_LO.toPlainText()).strip())
            P = float(self.ui.lineEdit_PR.text())
            R = StringIO(str(self.ui.plainTextEdit_RO.toPlainText()).strip())
            R = pandas.read_csv(R,delim_whitespace=True, header=None)
            L = pandas.read_csv(L,delim_whitespace=True, header=None)
            sumR = R.sum()
            KA = []
            for x, r in enumerate(R.values):
                RR = r[0]
                LL = L.values[x][0]
                ka = RR/(LL-(P*RR)/(1+sumR))
                ka = round(ka.values[0], 2)
                KA.append(ka)
            self.ui.plainTextEdit_KdProxy.clear()
            R['KA'] = KA
            R['KD'] = 1/R.KA

            KA = R.KA.to_string(header=False, index=False)
            KD = R.KD.to_string(header=False, index=False)
            if self.ui.radioButton_Kd.isChecked() == True:
                self.ui.plainTextEdit_KdProxy.insertPlainText(KD)
            else:
                self.ui.plainTextEdit_KdProxy.insertPlainText(KA)
        except:
            QMessageBox.about(
                self, "warning", "The concentrations must have numeric values.")
            return

    def _calc_Kd_CUPRA(self):  # maybe remove in released copy
        pandas.set_option("display.precision", 10)
        pandas.set_option('display.float_format', '{:.3E}'.format)
        try:
            LO = str(self.ui.plainTextEdit_LO_2.toPlainText()).strip().split()
            RO = str(self.ui.plainTextEdit_RO_2.toPlainText()).strip().split()
            R = str(self.ui.plainTextEdit_R.toPlainText()).strip().split()
            PRO = str(self.ui.lineEdit_PR_2.text()).strip()
            TO = str(self.ui.lineEdit_TO.text()).strip()
            if PRO == '':
                QMessageBox.about(
                    self, "warning", "The concentrations of proxy protein is missing. Cannot continue.")
            else:
                PRO = float(PRO)
            if TO == '':
                TO = 1
                self.ui.lineEdit_TO.setText('1')
            else:
                TO = float(TO)
            df = pandas.DataFrame()

            df['LO'] = LO
            df['RO'] = RO
            df['R'] = R
            for col in df.columns:
                df[col] = df[col].astype(float)
            COR = 1

            df['PrLi'] = df['RO']*PRO/(1+df['RO'].sum())
            df['Li'] = df['LO'].values-df['PrLi'].values
            df['KPr'] = df['PrLi']/(df['Li'])/(PRO/(1+df['RO'].sum()))
            if self.ui.checkBox_correct.isChecked():
                COR = df['RO'].values[0]/df['R'].values[0]

            df['R1'] = COR*df['R']
            PR = PRO/(1+df['R1'].sum())
            df['PrLi2'] = df['R1']*PR
            df['Li2'] = df['R1']/df['KPr']
            df['TLi'] = df['LO']-df['PrLi2']-df['Li2']
            df['TLiPr'] = df['TLi']*PR*df['KPr']
            T1 = TO-df['TLi'].sum()-df['TLiPr'].sum()
            if self.ui.checkBox_plot_TL.isChecked():
                x = np.arange(len(df['TLi']))
                tick_label = []
                for f in range(len(df['TLi'])):
                    tick_label.append('L'+str(f))
                plt.bar(x, df['TLi']+df['TLiPr'], tick_label=tick_label)
                plt.title(
                    '''Distribution of Complexes with Target\n(sum of binary and ternary complexes for each ligand)''')
            df['TLi'] = df['TLi'][df['TLi'] > 0]
            df['TLiPr'] = df['TLiPr'][df['TLiPr'] > 0]
            T = TO-df['TLi'].sum()-df['TLiPr'].sum()
            if T < 0:
                QMessageBox.about(self, "warning", "Target concentration is negative. Calculation terminated")
                return None
            df['KT'] = df['TLi'].values/df['Li2'].values/T

            test = round(COR, 6)
            if self.ui.radioButton_Kd_2.isChecked() == True:
                df['KPr'] = 1/df.KPr
                df['KT'] = 1/df.KT

            s = df.KPr.to_string(header=False, index=False)
            self.ui.plainTextEdit_KdProxy_2.clear()
            self.ui.plainTextEdit_KdProxy_2.insertPlainText(s)
            s = df.KT.to_string(header=False, index=False)
            self.ui.plainTextEdit_KdTarget.clear()
            self.ui.plainTextEdit_KdTarget.insertPlainText(s)
            self.ui.lineEdit_test.clear()
            self.ui.lineEdit_test.setText(str(test))
            plt.show()
        except:
            QMessageBox.about(self, "warning", "Can not process data. Check the concentrations. All input columns must have the same number of rows.")

    def _paste_LO(self):  # paste clipboard to plainTextEdit_add_PEAKS_0
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_LO.clear()
        self.ui.plainTextEdit_LO.insertPlainText(data)
    def _paste_LO_2(self):  # paste clipboard to plainTextEdit_add_PEAKS_0
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_LO_2.clear()
        self.ui.plainTextEdit_LO_2.insertPlainText(data)

    def _paste_RO(self):  # paste clipboard to plainTextEdit_add_PEAKS_0
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_RO.clear()
        self.ui.plainTextEdit_RO.insertPlainText(data)
    def _paste_RO_2(self):  # paste clipboard to plainTextEdit_add_PEAKS_0
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_RO_2.clear()
        self.ui.plainTextEdit_RO_2.insertPlainText(data)

    def _paste_R(self):  # paste clipboard to plainTextEdit_add_PEAKS_0
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "warning", "Can not paste clipboard data.")

            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_R.clear()
        self.ui.plainTextEdit_R.insertPlainText(data)

    def _paste_dif1(self):
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "warning", "Can not paste clipboard data.")

            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_difspectrum_1.clear()
        self.ui.plainTextEdit_difspectrum_1.insertPlainText(data)

    def _paste_dif2(self):
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_difspectrum_2.clear()
        self.ui.plainTextEdit_difspectrum_2.insertPlainText(data)

    def _copy_dif2(self):
        Spectrum = StringIO(str(self.ui.plainTextEdit_difspectrum_3.toPlainText()))
        Spectrum = pandas.read_csv(Spectrum, delim_whitespace=True, names=['Mass', 'S1','S2','Intensity'])
        Spectrum = Spectrum.drop(['S1','S2'], axis=1)
        s=swrm.nice_table(Spectrum,header=False)
        try:
            pyperclip.copy(s)
        except:
            QMessageBox.about(
                self, "warning", "Can not copy data to clipboard.")
            return
    def _copy_dif(self):
        s = str(self.ui.plainTextEdit_difspectrum_3.toPlainText())
        try:
            pyperclip.copy(s)
        except:
            QMessageBox.about(
                self, "warning", "Can not copy data to clipboard.")
            return

    # create figure for difference spectrum using current database entries
    def _plot_difference(self, none=None):
        try:
            sgwin = int(self.ui.lineEdit_sgwindow_2.text())
        except:
            sgwin = 1
        try:
            sgorder = int(self.ui.lineEdit_sgorder_2.text())
        except:
            sgorder = 2
        try:
            low = float(self.ui.lineEdit_low_2.text())
        except:
            low=0
        try:    
            high = float(self.ui.lineEdit_high_2.text())
        except:
            high=200000000
        try:
            rate = float(self.ui.lineEdit_rate_2.text())
        except:
            rate=100
        fig = plt.figure()
        ax = fig.add_subplot(111)
        fontsize=int(self.ui.lineEdit_fontsize.text())
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels

        if self.ui.checkBox_replace.isChecked():
            plt.close('all')
        linewidth = float(self.ui.lineEdit_linewidth.text())
        try:
            refmz = float(self.ui.lineEdit_ref_mz_2.text())
        except:
            QMessageBox.about(self, "warning", "Reference peak is required")
            return
        dbname = str(self.ui.lineEdit_DB_file.text()).upper()
        conn = sqlite3.connect("DB/{}.db".format(dbname))
        delta = float(self.ui.lineEdit_accuracy.text())
        doSG = 0
        if self.ui.checkBox_Savitzky_2.isChecked():
            doSG = 1
        c = conn.cursor()
        if self.ui.checkBox_use_database_2.isChecked():
            try:
                refID = str(self.ui.lineEdit_ref_ID.text())
                tagID = str(self.ui.lineEdit_target_ID.text())
                with conn:
                    c.execute("SELECT * FROM spectra WHERE ID=:ID",
                              {'ID': refID})
                    ls = c.fetchall()
                    ref_spectrum = ls[0][15]
                    ref_spectrum = cPickle.loads(zlib.decompress(ref_spectrum))
                    ref_spectrum = StringIO(ref_spectrum)
                    ref_spectrum = pandas.read_csv(
                        ref_spectrum, delim_whitespace=True, names=['Mass', 'Intensity'])
                    c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': tagID})
                    ls = c.fetchall()
                    tag_spectrum = ls[0][15]
                    tag_spectrum = cPickle.loads(zlib.decompress(tag_spectrum))
                    tag_spectrum = StringIO(tag_spectrum)
                    tag_spectrum = pandas.read_csv(
                        tag_spectrum, delim_whitespace=True, names=['Mass', 'Intensity'])
            except:
                QMessageBox.about(
                    self, "warning", "One of the Enries not found in the database {}".format(refID, dbname))
                return
        else:
            try:
                ref_spectrum = str(
                    self.ui.plainTextEdit_difspectrum_2.toPlainText())
                ref_spectrum = StringIO(ref_spectrum)
                ref_spectrum = pandas.read_csv(
                    ref_spectrum, delim_whitespace=True, names=['Mass', 'Intensity'])
                tag_spectrum = str(
                    self.ui.plainTextEdit_difspectrum_1.toPlainText())
                tag_spectrum = StringIO(tag_spectrum)
                tag_spectrum = pandas.read_csv(
                    tag_spectrum, delim_whitespace=True, names=['Mass', 'Intensity'])
            except:
                QMessageBox.about(
                    self, "warning", "Input spectrum cannot be found or has wrong format")
                return
        if self.ui.radioButton_scale_by_ref.isChecked():
            scale=0
        else:
            scale=1
        try:
            DF = swrm.difference(ref_spectrum, tag_spectrum, refmz,
                               delta, low, high, rate, sgwin, sgorder, doSG,scale=scale)
        except:
            QMessageBox.about(
                self, "warning", "Cannot subtract. Check the spectra ranges (m/z range in every spectrum must include left and right limits in settings). Each spectrum must contain exactly 2 columns. Only numerical values in spectra are accepted.")
            return

        if self.ui.checkBox_ALT.isChecked():
            if self.ui.radioButton_PLUS.isChecked():
                print("PLUS operator")
                DF['Dif'] = (DF.tag+DF.ref).values
            elif self.ui.radioButton_MULT.isChecked():
                print("MULT operator")
                DF['Dif'] = (DF.tag*DF.ref).values
            elif self.ui.radioButton_DIV.isChecked():
                DF['Dif'] = (DF.tag/DF.ref).values
            elif self.ui.radioButton_LOG.isChecked():
                DF['Dif'] = np.log(DF.tag.values)
            elif self.ui.radioButton_DER.isChecked():
                DF['Dif'] = np.zeros(DF.tag.shape,np.float)
                DF['Dif'][0:-1] = np.diff(DF.tag.values)

        s = DF2str(DF)
        self.ui.plainTextEdit_difspectrum_3.clear()
        self.ui.plainTextEdit_difspectrum_3.insertPlainText(s)

        plt.plot(DF.Mass, DF.ref, color='blue',
                 linewidth=linewidth, label='reference')
        plt.plot(DF.Mass, DF.tag, color='red',
                 linewidth=linewidth, label='target')
        plt.plot(DF.Mass, DF['Dif'], color='green',
                 linewidth=linewidth, label='difference')
        plt.xlabel('m/z')
        plt.legend()
        plt.show()


########## SWARM block###################

    # paste clipboard to plainTextEdit_original_spectrum

    def _paste_original_spectrum(self):
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_original_spectrum.clear()
        self.ui.plainTextEdit_original_spectrum.insertPlainText(data)

    # copy plainTextEdit_final_spectrum to clipboard
    def _copy_final_spectrum(self):
        s = str(self.ui.plainTextEdit_final_spectrum.toPlainText())
        try:
            pyperclip.copy(s)
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Could not copy clipboard data.")
            else:
                print("Could not copy clipboard data.")
            return

    def _paste_annotations(self):  # paste clipboard to plainTextEdit_add_PEAKS_0
        try:
            data = pyperclip.paste()
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Can not paste clipboard data.")
            else:
                print("Can not paste clipboard data.")
            return
        self.ui.plainTextEdit_add_PEAKS_0.clear()
        self.ui.plainTextEdit_add_PEAKS_0.insertPlainText(data)

    def _copy_found_peaks(self):  # copy plainTextEdit_foundPEAKS to clipboard
        s = str(self.ui.plainTextEdit_foundPEAKS.toPlainText())
        try:
            pyperclip.copy(s)
        except:
            QMessageBox.about(self, "warning", "Can not copy clipboard data.")
            return
    # @swrm.ignore_warnings

    def _SWARM(self, noshow=False):  # performs spectrum treatment, baseline corrections and SWARM
        self.SWARM_DF = pandas.DataFrame()
        df = pandas.DataFrame()
        new = pandas.DataFrame()
        if self.ui.checkBox_use_database_settings.isChecked():
            ID = str(self.ui.lineEdit_ID.text())
            fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                ls = c.fetchall()
                settings = ls[0][12].split('\n')
                # print(settings)
            for line in settings:
                # print(line)
                p = line.split('@')
                if p[0] in self.pars1:
                    S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:]))
                    a = eval(S)
                if p[0] in self.pars2:
                    S = "self.ui.%s.clear()" % (p[0])
                    a = eval(S)
                    SS = "self.ui.%s.insertPlainText('%s')" % (
                        p[0], str(p[1][:]).replace('$', '\\n'))
                    b = eval(SS)
                if p[0] in self.pars3:
                    if eval(str(p[1][:])) == True:
                        S = "self.ui.%s.setChecked(True)" % (p[0])
                        a = eval(S)
                    else:
                        S = "self.ui.%s.setChecked(False)" % (p[0])
                        a = eval(S)
        try:
            lamO = float(self.ui.lineEdit_lambda_2.text())
            pO = float(self.ui.lineEdit_p_2.text())
            lamB = float(self.ui.lineEdit_lambda.text())
            pB = float(self.ui.lineEdit_p.text())
            lamE = float(self.ui.lineEdit_lambda_3.text())
            pE = float(self.ui.lineEdit_p_3.text())
            lamA = float(self.ui.lineEdit_lambda_4.text())
            pA = float(self.ui.lineEdit_p_4.text())
            iter = int(self.ui.lineEdit_iter.text())
            accuracy = float(self.ui.lineEdit_accuracy.text())
            sgwin = int(round(float(self.ui.lineEdit_sgwindow.text())))
            lineEdit_sgorder = int(self.ui.lineEdit_sgorder.text())
            each = 0
            if self.ui.checkBox_asym_bground_every.isChecked():
                each = 1
            try:
                low = int(self.ui.lineEdit_low.text())
            except:
                low = 0
            try:
                high = int(self.ui.lineEdit_high.text())
            except:
                high = 10000000
            try:
                rate = int(self.ui.lineEdit_rate.text())
                padding= int(self.ui.lineEdit_padding.text())
            except:
                rate = 25
                padding= 1
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "All parameters must have numeric values. Even if a parameter is not used put a placeholder value.")
            else:
                print(
                    "All parameters must have numeric values. Even if a parameter is not used put a placeholder value.")
            return

        if not self.ui.checkBox_use_database.isChecked():
            spectrum = str(
                self.ui.plainTextEdit_original_spectrum.toPlainText())
            if spectrum == '':
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Spectrum is missing")
                else:
                    print("Spectrum is missing")
                return
        else:
            ID = str(self.ui.lineEdit_dirty_ID.text())
            self.ui.lineEdit_ID.clear()
            self.ui.lineEdit_ID.setText(ID)
            self._show_entry()
            # spectrum is str
            spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
        spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=[
                                     'Mass', 'Intensity'])  # spectrum is Pandas pandas.DataFrame
        # df is main pandas.DataFrame, a container for spectra and intermediate results
        df['Mass'] = spectrum.Mass.values
        df['Original'] = spectrum.Intensity.values
        # assign all columns the same as value as in Original
        df['SG'] = df['Original'].values
        df['Before'] = df['Original'].values
        df['Final'] = df['Original'].values
        df['Base'] = df['Original'].values
        if self.ui.checkBox_resample.isChecked():
            df = pandas.DataFrame()
            new = swrm.resample_spectrum(spectrum, low, high, rate,padding)
            if isinstance(new, pandas.DataFrame):
                df['Mass'] = new.Mass.values
                df['Original'] = new.Intensity.values
                df.dropna(inplace=True)
                df['SG'] = df['Original'].values
                df['Before'] = df['Original'].values
                df['Final'] = df['Original'].values
                df['Base'] = df['Original'].values

        if self.ui.checkBox_Savitzky.isChecked():
            try:

                if not sgwin % 2 == 0:
                    if not sgwin < lineEdit_sgorder:
                        df['SG'] = sg(df['Original'].values,
                                      sgwin, lineEdit_sgorder)
                        df['Before'] = df['SG'].values
                        df['Final'] = df['SG'].values
                    else:
                        if not self.ui.checkBox_cancel_messages.isChecked():
                            QMessageBox.about(self, "warning", "Savitzky-Golay order must not be greater than window length")
                        else:
                            print("Savitzky-Golay order must not be greater than window length")

                else:
                    if not self.ui.checkBox_cancel_messages.isChecked():
                        QMessageBox.about(
                            self, "warning", "Savitzky-Golay window must be an odd number.")
                    else:
                        print("Savitzky-Golay window must be an odd number.")

            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "warning", "Savitzky-Golay failed. Either cannot find the spectrum or parameters are missing.")
                else:
                    print("Savitzky-Golay failed. Cannot find the spectrum.")
                return
        #####CREATE OUTLINE
        if self.ui.checkBox_make_outline.isChecked():
            
            try:
                # df['SG'] = spectrum_outline(df['Original'],lamO,pO)
                outline = -1*swrm.baseline(-1*df['Original'],lamO,pO)
                df['SG'] = outline
                df['Before'] = df['SG'].values
                df['Final'] = df['SG'].values
 
            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Outline cannot be generated. Either cannot find the spectrum.")
                else:
                    print("Outline cannot be generated. Either cannot find the spectrum.")
                return
        if self.ui.checkBox_asym_bground_Before.isChecked():
            try:
                bsl = swrm.baseline(df.Final.values, lam=lamB, p=pB, niter=iter)
                df.Before = df.Final-bsl
                df['Final'] = df['Before']
                df.Base = bsl

            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Baseline calculation BEFORE SWARM failed. This computer may have insufficient memory. Calculation of Asymmetric Least Square baseline requires large amount of RAM. RAM demands scale as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                else:
                    print("Baseline calculation BEFORE failed. This computer may have insufficient memory. Calculation of Asymmetric Least Square baseline requires large amount of RAM. RAM demands scale as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                return
        # print("Step4 baseline df shape \n",df.head())
        if not self.ui.checkBox_use_database_ann.isChecked():
            LB = str(self.ui.plainTextEdit_add_PEAKS_0.toPlainText())
        else:
            self.ui.plainTextEdit_add_PEAKS_0.clear()
            LB = str(self.ui.plainTextEdit_annotations_2.toPlainText())
            self.ui.plainTextEdit_add_PEAKS_0.insertPlainText(LB)


        lbl = pandas.read_csv(
            StringIO(LB), delim_whitespace=True, names=['Mass', 'Label'])
        chr = []
        for line in LB.split('\n'):
            if not line == '':
                chr.append(line.split('_')[1].strip().strip('+').strip('-'))
        blocks = sorted(list(set(chr)))
        lbl['Charge'] = chr
        lbl.sort_values(by='Charge', ascending=True)

        REFMZ = []
        REFC = []
        REFW = []
        TMPL = str(self.ui.plainTextEdit_TMPL.toPlainText()).split('\n')
        for line in TMPL:
            if not line == '':
                REFMZ.append(line.split()[0])
                REFC.append(line.split()[1].split('_')[1][:-1])
                REFW.append(line.split()[2])

        if self.ui.checkBox_runSWARM.isChecked():
            try:
                if not self.ui.checkBox_oneREF.isChecked():
                    for f in range(len(REFMZ)):
                        refmz = float(REFMZ[f])
                        window = float(REFW[f])
                        lbl1 = (lbl[lbl.Charge == REFC[f]])
                        lbl1 = lbl1.drop(['Charge'], axis=1)
                        Spectrum = pandas.DataFrame()
                        Spectrum['Mass'] = df.Mass.values
                        Spectrum['Intensity'] = df.Final.values
                        s = swrm.annotate(Spectrum.values, lbl1, accuracy)
                        Annt = pandas.read_csv(
                            StringIO(s), delim_whitespace=True, names=['Mass', 'Intensity', 'Delta', 'Label'])
                        Annt = Annt.drop(['Label', 'Delta'], axis=1)
                        refmz, x, y = swrm.PeakID(
                            Spectrum, refmz, accuracy)  # update refmz
                        # cut a fragment containing FF linker peak
                        ref = (Spectrum[(refmz <= Spectrum.Mass)
                                        & (Spectrum.Mass <= refmz+window)])
                        PEAKS = Annt.Mass.tolist()
                        W = window
                        refmas = ref['Mass'].min()
                        refhight = ref[ref['Mass'] == refmas].Intensity.values[0]
                        Spectrum = swrm.adducts_removal(
                            Spectrum, PEAKS, ref, refmas, refhight, accuracy, W, each, lamE, pE, iter)
                        df['Final'] = Spectrum.Intensity
                else:
                    chlist = sorted(list(set(lbl.Charge.tolist())),reverse=True)
                    refchar = int(REFC[0])
                    chlist.remove(str(refchar))
                    chlist.append(str(refchar))
                    print(chlist)

                    refmz = float(REFMZ[0])
                    window = float(REFW[0])
                    for f,char in enumerate(chlist):
                        if char == '0':
                            QMessageBox.about(
                                self, "warning", "Charge is 0. Uncheck box <use single reference for all charge states>.")
                            return
                        lbl1 = (lbl[lbl.Charge == char])
                        lbl1 = lbl1.drop(['Charge'], axis=1)
                        Spectrum = pandas.DataFrame()
                        Spectrum['Mass'] = df.Mass.values
                        Spectrum['Intensity'] = df.Final.values
                        s = swrm.annotate(Spectrum.values, lbl1, accuracy)
                        Annt = pandas.read_csv(
                            StringIO(s),delim_whitespace=True, names=['Mass', 'Intensity', 'Delta', 'Label'])
                        Annt = Annt.drop(['Label', 'Delta'], axis=1)
                        refmz, x, y = swrm.PeakID(
                            Spectrum, refmz, accuracy)  # update refmz
                        # cut a fragment containing FF linker peak
                        ref = (Spectrum[(refmz <= Spectrum.Mass)
                                        & (Spectrum.Mass <= refmz+window)])
                        PEAKS = Annt.Mass.tolist()
                        W = window*refchar/int(char)
                        refmas = ref['Mass'].min()
                        refhight = ref[ref['Mass'] == refmas].Intensity.values[0]
                        Spectrum = swrm.adducts_removal(
                            Spectrum, PEAKS, ref, refmas, refhight, accuracy, W, each, lamE, pE, iter)
                        df['Final'] = Spectrum.Intensity

            except Exception as e:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning","SWARM failed. Check parameters and spectrum margins.")
                else:
                    print("SWARM failed. Check parameters and spectrum margins.\n{}".format(e))
                return

        # print("Step6 SWARM df shape \n",df.head())

        if self.ui.checkBox_asym_bground_after.isChecked():
            try:
                bsl = swrm.baseline(df.Final.values, lam=lamB, p=pB, niter=iter)
                df.Final = df.Final-bsl
                df.Base = bsl
            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Baseline calculation BEFORE failed. \
                    This computer may have insufficient memory. Calculation of Asymmetric\
                    Least Square baseline requires large amount of RAM. RAM demands scale \
                    as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                else:
                    print("Baseline calculation BEFORE failed. This computer may have insufficient memory.\
                    Calculation of Asymmetric Least Square baseline requires large amount of RAM. \
                    RAM demands scale as square of the number of data points. \
                    Try to reduce spectrum range and/or reduce sampling rate.")
                return
        an = pandas.DataFrame()
        an['Mass'] = df.Mass
        an['Final'] = df.Final
        lb = ''
        for f in LB:
            lb = lb+f
        lb = StringIO(lb)
        lb = pandas.read_csv(lb, delim_whitespace=True,
                               names=['Mass', 'Label'])
        s = swrm.annotate(an.values, lb, accuracy)
        self.ui.plainTextEdit_foundPEAKS.clear()
        self.ui.plainTextEdit_foundPEAKS.insertPlainText(s)
        self.SWARM_DF = df.copy()
        try:
            self.SWARM_DF.to_csv("results/SWARM_DF.tsv",sep='\t',index=False)
            pickle.dump( self.SWARM_DF, open( "results/SWARM_DF.pickle", "wb" ) )
        except:
            print('Cannot write to file. File SWARM_DF.tsv might be opened in Excel')
            return
        spectrum = pandas.DataFrame()
        spectrum['Mass'] = df.Mass.values
        spectrum['Intensity'] = df.Final.values
        s = DF2str(spectrum)
        self.ui.plainTextEdit_final_spectrum.clear()
        self.ui.plainTextEdit_final_spectrum.insertPlainText(s)
        if noshow == False:
            self._plot(self.SWARM_DF)
        else:
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(s)
        return self.SWARM_DF
    def _SWARM2(self, noshow=False):  # performs spectrum treatment, baseline corrections and SWARM
        #reset  variables-DataFrames
        self.SWARM_DF = pandas.DataFrame()
        self.TEMPLATES = pandas.DataFrame()
        try:    # collect parameters
            lamO = float(self.ui.lineEdit_lambda_2.text())
            pO = float(self.ui.lineEdit_p_2.text())
            lamB = float(self.ui.lineEdit_lambda.text())
            pB = float(self.ui.lineEdit_p.text())
            lamE = float(self.ui.lineEdit_lambda_3.text())
            pE = float(self.ui.lineEdit_p_3.text())
            lamA = float(self.ui.lineEdit_lambda_4.text())
            pA = float(self.ui.lineEdit_p_4.text())
            iter = int(self.ui.lineEdit_iter.text())
            accuracy = float(self.ui.lineEdit_accuracy.text())
            sgwin = int(round(float(self.ui.lineEdit_sgwindow.text())))
            lineEdit_sgorder = int(self.ui.lineEdit_sgorder.text())
            each = 0
            if self.ui.checkBox_asym_bground_every.isChecked():
                each = 1
            try:
                low = int(self.ui.lineEdit_low.text())
            except:
                low = 0
            try:
                high = int(self.ui.lineEdit_high.text())
            except:
                high = 10000000
            try:
                rate = int(self.ui.lineEdit_rate.text())
                padding= int(self.ui.lineEdit_padding.text())
            except:
                rate = 25
                padding= 1
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "All parameters must have numeric values. Even if a parameter is not used put a placeholder value.")
            else:
                print(
                    "All parameters must have numeric values. Even if a parameter is not used put a placeholder value.")
            return

        if self.ui.checkBox_use_database_settings.isChecked():#apply settings from current database entry
            try:
                ID = str(self.ui.lineEdit_ID.text())
                fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
            except:
                QMessageBox.about(self, "warning", "Database and entry must be specified")
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                ls = c.fetchall()
                settings = ls[0][12].split('\n')
            for line in settings: 
                p = line.split('@')
                if p[0] in self.pars1:
                    S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:]))
                    a = eval(S)
                if p[0] in self.pars2:
                    S = "self.ui.%s.clear()" % (p[0])
                    a = eval(S)
                    SS = "self.ui.%s.insertPlainText('%s')" % (
                        p[0], str(p[1][:]).replace('$', '\\n'))
                    b = eval(SS)
                if p[0] in self.pars3:
                    if eval(str(p[1][:])) == True:
                        S = "self.ui.%s.setChecked(True)" % (p[0])
                        a = eval(S)
                    else:
                        S = "self.ui.%s.setChecked(False)" % (p[0])
                        a = eval(S)

        if not self.ui.checkBox_use_database.isChecked():
            spectrum = str(self.ui.plainTextEdit_original_spectrum.toPlainText())
            if spectrum == '':
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Spectrum is missing")
                else:
                    print("Spectrum is missing")
                return
        else:
            ID = str(self.ui.lineEdit_dirty_ID.text())
            self.ui.lineEdit_ID.clear()
            self.ui.lineEdit_ID.setText(ID)
            self._show_entry()
            # spectrum is a str variable
            spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
        spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, 
                    names=['Mass', 'Intensity'])  # now spectrum is a pandas.DataFrame
        # df is the main pandas.DataFrame, a container for original spectrum and all derived results
        df = pandas.DataFrame()
        df['Mass'] = spectrum.Mass.values 
        df['Original'] = spectrum.Intensity.values
        # assign all columns the same as value as in Original
        df['SG'] = df['Original'].values    # a placeholder for outline
        df['Before'] = df['Original'].values # a placeholder
        df['Final'] = df['Original'].values # a placeholder
        df['Base'] = df['Original'].values # a placeholder for baseline
        if self.ui.checkBox_resample.isChecked():
            df = pandas.DataFrame()
            new = swrm.resample_spectrum(spectrum, low, high, rate,padding)
            if isinstance(new, pandas.DataFrame):
                df['Mass'] = new.Mass.values
                df['Original'] = new.Intensity.values
                df.dropna(inplace=True)
                df['SG'] = df['Original'].values
                df['Before'] = df['Original'].values
                df['Final'] = df['Original'].values
                df['Base'] = df['Original'].values

        if self.ui.checkBox_Savitzky.isChecked():
            try:

                if not sgwin % 2 == 0:
                    if not sgwin < lineEdit_sgorder:
                        df['SG'] = sg(df['Original'].values,
                                      sgwin, lineEdit_sgorder)
                        df['Before'] = df['SG'].values
                        df['Final'] = df['SG'].values
                    else:
                        if not self.ui.checkBox_cancel_messages.isChecked():
                            QMessageBox.about(
                                self, "warning", "Savitzky-Golay order must not be greater than window length")
                        else:
                            print(
                                "Savitzky-Golay order must not be greater than window length")

                else:
                    if not self.ui.checkBox_cancel_messages.isChecked():
                        QMessageBox.about(
                            self, "warning", "Savitzky-Golay window must be an odd number.")
                    else:
                        print("Savitzky-Golay window must be an odd number.")

            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "warning", "Savitzky-Golay failed. Either cannot find the spectrum or parameters are missing.")
                else:
                    print("Savitzky-Golay failed. Cannot find the spectrum.")
                return
        #####CREATE OUTLINE
        if self.ui.checkBox_make_outline.isChecked():
            
            try:
                outline = -1*swrm.baseline(-1*df['Original'],lamO,pO)
                df['SG'] = outline
                df['Before'] = df['SG'].values
                df['Final'] = df['SG'].values
 
            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "warning", "Outline cannot be generated. Cannot find the spectrum.")
                else:
                    print("Outline cannot be generated. Cannot find the spectrum.")
                return
        if self.ui.checkBox_asym_bground_Before.isChecked():
            try:
                bsl = swrm.baseline(df.Final.values, lam=lamB, p=pB, niter=iter)
                df.Before = df.Final-bsl
                df['Final'] = df['Before']
                df.Base = bsl

            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Baseline calculation BEFORE SWARM failed. This computer may have insufficient memory. Calculation of Asymmetric Least Square baseline requires large amount of RAM. RAM demands scale as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                else:
                    print("Baseline calculation BEFORE failed. This computer may have insufficient memory. Calculation of Asymmetric Least Square baseline requires large amount of RAM. RAM demands scale as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                return
        # print("Step4 baseline df shape \n",df.head())
        if not self.ui.checkBox_use_database_ann.isChecked():
            try:
                LB = str(self.ui.plainTextEdit_add_PEAKS_0.toPlainText())
            except:
                QMessageBox.about(self, "warning", "Annotations are required")
                return
        else:
            self.ui.plainTextEdit_add_PEAKS_0.clear()
            LB = str(self.ui.plainTextEdit_annotations_2.toPlainText())
            self.ui.plainTextEdit_add_PEAKS_0.insertPlainText(LB)

        lbl = pandas.read_csv(
            StringIO(LB), delim_whitespace=True, names=['Mass', 'Label'])
        chr = []
        try:
            for line in LB.split('\n'):
                if not line == '':
                    chr.append(line.split('_')[1].strip().strip('+').strip('-'))
        except Exception as e:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "warning","SWARM failed. Check parameters and spectrum margins. Check labels format, example: P_11+")
            else:
                print("SWARM failed. Check parameters and spectrum margins.\n{}".format(e))
            return
            
            
            
        blocks = sorted(list(set(chr)))
        lbl['Charge'] = chr
        lbl.sort_values(by='Charge', ascending=True)
        #generate lists of parameters for templates
        REFMZ = []
        REFC = []
        REFW = []
        TMPL = str(self.ui.plainTextEdit_TMPL.toPlainText()).split('\n')
        for line in TMPL:
            if not line == '':
                REFMZ.append(line.split()[0])
                REFC.append(line.split()[1].split('_')[1][:-1])
                REFW.append(line.split()[2])
 ###############SWARM BLOCK
        if self.ui.checkBox_runSWARM.isChecked(): 
            TEMPLATES=pandas.DataFrame()
            try:# collect SWARM parameters and run SWARM
                Spectrum = pandas.DataFrame()
                Spectrum['Mass'] = df.Mass.values
                Spectrum['Intensity'] = df.Final.values
                if not self.ui.checkBox_oneREF.isChecked():
                
                    for f in range(len(REFMZ)):
                        refmz = float(REFMZ[f])
                        window = float(REFW[f])
                        lbl1 = (lbl[lbl.Charge == REFC[f]])
                        lbl1 = lbl1.drop(['Charge'], axis=1)
                        s = swrm.annotate(Spectrum.values, lbl1, accuracy)
                        Annt = pandas.read_csv(StringIO(s), delim_whitespace=True,names=['Mass', 'Intensity', 'Delta', 'Label'])
                        Annt = Annt.drop(['Label', 'Delta'], axis=1)
                        PEAKS = Annt.Mass.tolist()
                        Spectrum,WIND = swrm.adducts_removal2(Spectrum, PEAKS, refmz, accuracy, window, each, lamE, pE, iter)
                        df['Final'] = Spectrum.Intensity
                        self.TEMPLATES= pandas.concat([self.TEMPLATES, WIND], axis=1, ignore_index=True)
                else:
                    chlist = sorted(list(set(lbl.Charge.tolist())),reverse=True)
                    refchar = int(REFC[0])
                    chlist.remove(str(refchar))
                    chlist.append(str(refchar))
                    refmz = float(REFMZ[0])
                    window = float(REFW[0])
                    print()
                    for f,char in enumerate(chlist):
                        if char == '0':
                            QMessageBox.about(self, "warning", "Charge is 0. Uncheck box <use single reference for all charge states>.")
                            return
                        lbl1 = (lbl[lbl.Charge == char])
                        lbl1 = lbl1.drop(['Charge'], axis=1)
                        Spectrum = pandas.DataFrame()
                        Spectrum['Mass'] = df.Mass.values
                        # Spectrum['Intensity'] = df.Final.values-df.Final.values.min()
                        Spectrum['Intensity'] = df.Final.values
                        s = swrm.annotate(Spectrum.values, lbl1, accuracy)
                        Annt = pandas.read_csv(StringIO(s), delim_whitespace=True,names=['Mass', 'Intensity', 'Delta', 'Label'])
                        Annt = Annt.drop(['Label', 'Delta'], axis=1)
                        refmz, x, y = swrm.PeakID(Spectrum, refmz, accuracy)
                        ref = (Spectrum[(refmz <= Spectrum.Mass) & (Spectrum.Mass <= refmz+window)])
                        PEAKS = Annt.Mass.tolist()
                        W = window*refchar/int(char)
                        refmas = ref['Mass'].min()
                        refhight = ref[ref['Mass'] == refmas].Intensity.values[0]
                        Spectrum,WIND = swrm.adducts_removal2(Spectrum, PEAKS, refmz, accuracy, window, each, lamE, pE, iter)
                        df['Final'] = Spectrum.Intensity
                        self.TEMPLATES= pandas.concat([self.TEMPLATES, WIND], axis=1, ignore_index=True)
            except Exception as e:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning","SWARM failed. Check parameters and spectrum margins. Check labels format, example: P_11+")
                else:
                    print("SWARM failed. Check parameters and spectrum margins.\n{}".format(e))
                return

        # print("Step6 SWARM df shape \n",df.head())

        if self.ui.checkBox_asym_bground_after.isChecked():
            try:
                bsl = swrm.baseline(df.Final.values, lam=lamB, p=pB, niter=iter)
                df.Final = df.Final-bsl
                df.Base = bsl
            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Baseline calculation BEFORE failed. \
                    This computer may have insufficient memory. Calculation of Asymmetric\
                    Least Square baseline requires large amount of RAM. RAM demands scale \
                    as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                else:
                    print("Baseline calculation BEFORE failed. This computer may have insufficient memory.\
                    Calculation of Asymmetric Least Square baseline requires large amount of RAM. \
                    RAM demands scale as square of the number of data points. \
                    Try to reduce spectrum range and/or reduce sampling rate.")
                return
        an = pandas.DataFrame()
        an['Mass'] = df.Mass
        an['Final'] = df.Final
        lb = ''
        for f in LB:
            lb = lb+f
        lb = StringIO(lb)
        lb = pandas.read_csv(lb, delim_whitespace=True, names=['Mass', 'Label'])
        s = swrm.annotate(an.values, lb, accuracy)
        self.ui.plainTextEdit_foundPEAKS.clear()
        self.ui.plainTextEdit_foundPEAKS.insertPlainText(s)
        self.SWARM_DF = df.copy()
        try:
            self.SWARM_DF.to_csv("results/SWARM_DF.tsv",sep='\t',index=False)
            cPickle.dump( df, open( "results/SWARM_DF.pickle", "wb" ) )

        except:
            print('Cannot write to file. File SWARM_DF.tsv might be opened in Excel')
            return
        try:
            tmpl=self.TEMPLATES
            self.TEMPLATES.to_csv("results/TEMPLATES.tsv",sep='\t',index=False)
            cPickle.dump( tmpl, open( "results/TEMPLATES.pickle", "wb" ) )

        except:
            print('Cannot write to file. File TEMPLATES.tsv might be opened in Excel')
            return
        spectrum = pandas.DataFrame()
        spectrum['Mass'] = df.Mass.values
        spectrum['Intensity'] = df.Final.values
        s = DF2str(spectrum)
        self.ui.plainTextEdit_final_spectrum.clear()
        self.ui.plainTextEdit_final_spectrum.insertPlainText(s)
        if noshow == False:
            self._plot(self.SWARM_DF)
        else:
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(s)
        return self.SWARM_DF
        
    def _plot(self, df):  # plot SWARM pandas.DataFrame

        linewidth = float(self.ui.lineEdit_linewidth.text())
        fontsize = float(self.ui.lineEdit_fontsize.text())
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels

        offset = str(self.ui.lineEdit_offset.text()).replace(',', ' ').replace('(', ' ').replace(')', ' ').split()
        if self.ui.checkBox_replace.isChecked():
            plt.close('all')

        ######### Plot result#################
        fig = plt.figure()
        ax = fig.add_subplot(111)
        try:
            df = self.SWARM_DF
            if self.ui.checkBox_show_original.isChecked():
                plt.plot(df.Mass, df.Original, color='black',
                         linewidth=linewidth, label='original')
            if self.ui.checkBox_SG_spectrum.isChecked():
                plt.plot(df.Mass, df.SG, color='darkorange',
                         linewidth=linewidth, label='outline')
            if self.ui.checkBox_baseline_before_SWARM.isChecked():
                plt.plot(df.Mass, df.Before, color='m',
                         linewidth=linewidth, label='before SWARM baseline')
            if self.ui.checkBox_Final.isChecked():
                plt.plot(df.Mass, df.Final, color='blue',
                         linewidth=linewidth, label='after final baseline')
            if self.ui.checkBox_show_background.isChecked():
                plt.plot(df.Mass, df.Base, color='green',
                         linewidth=linewidth, label='last baseline')
            
            
            if self.ui.checkBox_show_legend.isChecked():
                plt.legend()
            if self.ui.checkBox_windows.isChecked():
                cols=list(self.TEMPLATES)
                for f in cols:
                    plt.plot(df.Mass, self.TEMPLATES[f], '--', linewidth=1)
            
            

            
            plt.xlabel('m/z')
            plt.ylabel('Intensity')
            if self.ui.checkBox_annotate.isChecked():
                AN = StringIO(str(self.ui.plainTextEdit_foundPEAKS.toPlainText()))
                AN = pandas.read_csv(AN, delim_whitespace=True, names=[
                                       'Mass', 'Intensity', 'delta', 'Label'])
                AN.drop('delta', axis=1, inplace=True)
                AN = AN.set_index('Label')
                if self.ui.checkBox_vertical.isChecked():
                    rotation = 90
                else:
                    rotation = 0
                for k, v in AN.iterrows():
                    ax.annotate(k, v,
                                xytext=(int(offset[0]), int(offset[1])), rotation=rotation, textcoords='offset points',
                                fontsize=fontsize-2, color='black')
            plt.show()
        except:
            QMessageBox.about(self, "warning","SWARM must be run before Replot.")

    def _save_par(self, fname='tmp'):
        if not os.path.exists('DB/settings'):
            os.mkdir('DB/settings')
        try:
            fname, ok = QInputDialog.getText(
                self, 'Input Dialog', 'Enter name for parameter file:')
            if fname == '':
                fname = 'SWARM_config.txt'

            with open("DB/settings/{}".format(fname.upper()), 'w') as q:
                q.write('')
            with open("DB/settings/{}".format(fname.upper()), 'a') as q:
                for par in self.pars1:
                    SAVE = par
                    S = 'str(self.ui.%s.text())' % (par)
                    par = eval(S)
                    SAVE = SAVE+"@"+par+'\n'
                    q.write(SAVE)
                for par in self.pars2:
                    SAVE = par
                    S = "str(self.ui.%s.toPlainText()).replace('\\n','$')" % (par)
                    par = eval(S)
                    SAVE = SAVE+"@"+par+'\n'
                    q.write(SAVE)
                for par in self.pars3:
                    SAVE = par
                    s = 'str(self.ui.%s.isChecked())' % (par)
                    S = eval(s)
                    SAVE = SAVE+"@"+S+'\n'
                    q.write(SAVE)
        except Exception as e:
            print('failed to save settings\n{}'.format(e))
            return

    def _load_par(self):
        fname = QFileDialog.getOpenFileName(self, 'Open file', 'DB/settings')[0]
        print(fname)
        try:
            with open(fname, 'r') as q:
                pars = q.readlines()
                for p in pars:
                    p = p.split('@')
                    if p[0] in self.pars1:
                        S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:-1]))
                        a = eval(S)

                    if p[0] in self.pars2:
                        S = "self.ui.%s.clear()" % (p[0])
                        a = eval(S)
                        SS = "self.ui.%s.insertPlainText('%s')" % (
                            p[0], str(p[1][:-1]).replace('$', '\\n'))
                        b = eval(SS)
                    if p[0] in self.pars3:
                        if eval(str(p[1][:-1])) == True:
                            S = "self.ui.%s.setChecked(True)" % (p[0])
                            a = eval(S)
                        else:
                            S = "self.ui.%s.setChecked(False)" % (p[0])
                            a = eval(S)
        except:
            return
######### DATABASE block###################

    def _paste(self):  # paste clipboard to plainTextEdit_spectrum
        data = pyperclip.paste()
        self.ui.plainTextEdit_spectrum.clear()
        self.ui.plainTextEdit_spectrum.insertPlainText(data)
    def _copy_original(self):  # copy original spectrum from database to clipboard
        s = str(self.ui.plainTextEdit_spectrum.toPlainText())
        pyperclip.copy(s)
    def _copy_ratios(self):  # copy ratios to clipboard
        s = str(self.ui.plainTextEdit_ratios.toPlainText())
        pyperclip.copy(s)

    def _copy_info(self):  # copy info to clipboard
        s = str(self.ui.plainTextEdit_INFO.toPlainText())
        pyperclip.copy(s)

    # list all databases in DB folder in plainTextEdit_search_result window
    def _show_DB(self, noshow=False):
        dir = 'DB'
        fi = os.listdir(dir)
        self.ui.plainTextEdit_search_result.clear()
        self.ui.plainTextEdit_search_result.insertPlainText(
            'Databases in DB folder:\n')
        self.ui.plainTextEdit_search_result_2.clear()
        self.ui.plainTextEdit_search_result_2.insertPlainText(
            'Databases in DB folder:\n')
        self.ui.plainTextEdit_search_result_3.clear()
        self.ui.plainTextEdit_search_result_3.insertPlainText(
            'Databases in DB folder:\n')
        S = ''
        for f in fi:
            if f[-2:] == 'db':
                S = S+f[:-3]+'\t'
        if noshow == False:
            self.ui.plainTextEdit_search_result.insertPlainText(S)
            self.ui.plainTextEdit_search_result_2.insertPlainText(S)
            self.ui.plainTextEdit_search_result_3.insertPlainText(S)
        return S.split()

    def _search_ALL_DBs(self):  # database search engine
        self.ui.plainTextEdit_search_result.clear()
        self.ui.plainTextEdit_INFO.clear()
        DBs = self._show_DB(noshow=True)
        n1 = str(self.ui.comboBox_term_1.currentText())
        n2 = str(self.ui.comboBox_term_2.currentText())
        b1 = str(self.ui.comboBox_bul1.currentText())
        b12 = str(self.ui.comboBox_bul1_2.currentText())
        date = str(self.ui.lineEdit_created_date.text()).strip('-')
        show1 = str(self.ui.comboBox_show_1.currentText()).strip()
        show2 = str(self.ui.comboBox_show_2.currentText()).strip()
        orderby = str(self.ui.comboBox_orderby.currentText())
        asdes = str(self.ui.comboBox_asdes.currentText())

        if n1 == 'comment':
            m1 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n1 == 'annotations':
            m1 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        else:
            m1 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n1))
        if n2 == 'comment':
            m2 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n2 == 'annotations':
            m2 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        elif n2 == '':
            m2 = ''
        else:
            m2 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n2))
        dt = ''
        if not n2 == '':
            sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} {} {} LIKE '%{}%' {} ORDER by {} {}""".format(
                n1, m1, b1, n2, b12, m2, dt, orderby, asdes))
        else:
            sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} ORDER by {} {}""".format(
                n1, m1, dt, orderby, asdes))
        for db in DBs:
            try:
                fname = db
                id = ''
                conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
                c = conn.cursor()
                # try:
                S = ''
                c.execute(sql)
                ls = c.fetchall()
                if len(ls) > 0:
                    s = 'DATABASE '+db+'\n'
                    for f in ls:
                        c.execute(
                            """SELECT {} FROM spectra WHERE ID = {}""".format(n1, f[0]))
                        fn1 = c.fetchone()[0]
                        if not n2 == '':
                            c.execute(
                                """SELECT {} FROM spectra WHERE ID = {}""".format(n2, f[0]))
                            fn2 = c.fetchone()[0]
                        sh1 = ''
                        sh2 = ''
                        if not show1 == '':
                            c.execute(
                                """SELECT {} FROM spectra WHERE ID = {}""".format(show1, f[0]))
                            sh1 = c.fetchone()[0]
                        if not show2 == '':
                            c.execute(
                                """SELECT {} FROM spectra WHERE ID = {}""".format(show2, f[0]))
                            sh2 = c.fetchone()[0]
                        id = id+str(f[0])+','

                        s = s+str(f[0])+'\t'+'\t'+str(sh1)+'\t'+str(sh2)+'\n'
                    S = S+s
                    # print(S)
                self.ui.plainTextEdit_search_result.insertPlainText(S)
                self.ui.plainTextEdit_INFO.insertPlainText(S)
            except Exception as e:
                print(e)
            finally:
                conn.close()

    def _search_DB(self):  # database search engine
        self.ui.plainTextEdit_search_result.clear()
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        # print(fname)
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            else:
                print("Database {} doesn't exist".format(fname.upper()))
            return
        self.ui.lineEdit_DB_donor.clear()
        self.ui.lineEdit_DB_donor.setText(fname.upper())

        n1 = str(self.ui.comboBox_term_1.currentText())
        n2 = str(self.ui.comboBox_term_2.currentText())
        b1 = str(self.ui.comboBox_bul1.currentText())
        b12 = str(self.ui.comboBox_bul1_2.currentText())
        # date_term=str(self.ui.comboBox_term_date.currentText())
        date = str(self.ui.lineEdit_created_date.text()).strip('-')
        show1 = str(self.ui.comboBox_show_1.currentText()).strip()
        show2 = str(self.ui.comboBox_show_2.currentText()).strip()
        orderby = str(self.ui.comboBox_orderby.currentText())
        asdes = str(self.ui.comboBox_asdes.currentText())
        dt = ''
        if n1 == 'comment':
            m1 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n1 == 'annotations':
            m1 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        else:
            m1 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n1))
        if n2 == 'comment':
            m2 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n2 == 'annotations':
            m2 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        elif n2 == '':
            m2 = ''
        else:
            m2 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n2))
        s = ''
        id = ''
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            # try:
            if not n2 == '':
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} {} {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, b1, n2, b12, m2, dt, orderby, asdes))
            else:
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, dt, orderby, asdes))

            # print (sql)
            c.execute(sql)
            ls = c.fetchall()
            for f in ls:
                c.execute(
                    """SELECT {} FROM spectra WHERE ID = {}""".format(n1, f[0]))
                fn1 = c.fetchone()[0]
                if not n2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(n2, f[0]))
                    fn2 = c.fetchone()[0]
                sh1 = ''
                sh2 = ''
                if not show1 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show1, f[0]))
                    sh1 = c.fetchone()[0]
                if not show2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show2, f[0]))
                    sh2 = c.fetchone()[0]
                id = id+str(f[0])+','
                s = s+str(f[0])+'\t'+'\t'+str(sh1)+'\t'+str(sh2)+'\n'

            self.ui.plainTextEdit_search_result.insertPlainText(s)
            self.ui.plainTextEdit_INFO.clear()
            self.ui.plainTextEdit_INFO.insertPlainText(s)
            self.ui.plainTextEdit_search_result_ID.clear()
            self.ui.plainTextEdit_search_result_ID.insertPlainText(id[:-1])
            self.ui.plainTextEdit_search_result_ID_2.clear()
            self.ui.plainTextEdit_search_result_ID_2.insertPlainText(id[:-1])
            self.ui.plainTextEdit_search_result_ID_3.clear()
            self.ui.plainTextEdit_search_result_ID_3.insertPlainText(id[:-1])
            self.ui.plainTextEdit_search_result_ID_4.clear()
            self.ui.plainTextEdit_search_result_ID_4.insertPlainText(id[:-1])
        except Exception as e:
            print(e)
        finally:
            conn.close()
    def _update_without_settings(self):
        self._update(settings=False)
    def _update_with_settings(self):
        self._update(settings=True)
    def _update(self,settings=False,nospectrum=False):  # update entry in current database
        ID = str(self.ui.lineEdit_ID.text())
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename.text()).strip()
        project = str(self.ui.lineEdit_project.text())
        operator = str(self.ui.lineEdit_operator.text())
        type = str(self.ui.lineEdit_type.text())
        if self.ui.radioButton_plus.isChecked() == True:
            polarity = 'Positive'
        else:
            polarity = 'Negative'
        formulas = str(self.ui.plainTextEdit_formula.toPlainText())
        trap = str(self.ui.lineEdit_trap.text())
        trans = str(self.ui.lineEdit_trans.text())
        conditions = str(self.ui.lineEdit_conditions.text())
        peaks = str(self.ui.plainTextEdit_annotations.toPlainText())

        SAVE = ''
        if settings==True:
            for par in self.pars1:
                save = par
                S = 'str(self.ui.%s.text())' % (par)
                par = eval(S)
                save = save+"@"+par+'\n'
                SAVE = SAVE+save
            for par in self.pars2:
                save = par
                S = "str(self.ui.%s.toPlainText()).replace('\\n','$')" % (par)
                par = eval(S)
                save = save+"@"+par+'\n'
                SAVE = SAVE+save
            for par in self.pars3:
                save = par
                s = 'str(self.ui.%s.isChecked())' % (par)
                S = eval(s)
                save = save+"@"+S+'\n'
                SAVE = SAVE+save

        lig_name = SAVE

        lig_mass = ''
        # lig_mass=str(self.ui.lineEdit_ligMass.text())
        if not nospectrum==True:
            spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
            spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, 
                names=['Mass', 'Intensity'])  # now spectrum is a pandas.DataFrame
            spectrum.sort_values(by='Mass', inplace=True)
            spectrum =spectrum.to_string(header=False, index=False)
            # print(spectrum)  
            # Compress:
            spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = str(self.ui.plainTextEdit_ratios.toPlainText())
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        annotations = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        created_date = str(datetime.now())
        self.ui.lineEdit_created_date.setText(created_date)
        comment = str(self.ui.plainTextEdit_comment.toPlainText())
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            date = ls[0][4]
            command = """UPDATE spectra SET filename='{}',project='{}',operator='{}',created_date='{}',type='{}',polarity='{}',formulas='{}',trap='{}',trans='{}',conditions='{}',peaks='{}',lig_name='{}',lig_mass='{}',comment='{}',annotations='{}'""".format(
                filename, project, operator, created_date, type, polarity, formulas, trap, trans, conditions, peaks, lig_name, lig_mass, comment, annotations)
            command = command+""" WHERE ID = '%s'""" % ID
            with conn:
                c.execute(command)
                if not nospectrum==True:
                    c.execute(
                        """UPDATE spectra SET spectrum=?,ratios=? WHERE ID=?""", (spectrum, ratios, ID))
                else:
                    c.execute(
                        """UPDATE spectra SET ratios=? WHERE ID=?""", (ratios, ID))

            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(self, "message", "Entry updated")
            else:
                print("Entry updated")
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            else:
                print(
                    "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            return
        finally:
            conn.close()
    def _show_entry_and_settings(self):
        self._show_entry()
        ID = str(self.ui.lineEdit_ID.text())
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        with conn:
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            settings = ls[0][12].split('\n')
        for line in settings:
            p = line.split('@')
            if p[0] in self.pars1:
                S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:]))
                a = eval(S)
            if p[0] in self.pars2:
                S = "self.ui.%s.clear()" % (p[0])
                a = eval(S)
                SS = "self.ui.%s.insertPlainText('%s')" % (
                    p[0], str(p[1][:]).replace('$', '\\n'))
                b = eval(SS)
            if p[0] in self.pars3:
                if eval(str(p[1][:])) == True:
                    S = "self.ui.%s.setChecked(True)" % (p[0])
                    a = eval(S)
                else:
                    S = "self.ui.%s.setChecked(False)" % (p[0])
                    a = eval(S)
    def _show_entry(self):  # load entry from current database
        ID = str(self.ui.lineEdit_ID.text())
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            else:
                print("Database {} doesn't exist".format(fname.upper()))
            return
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            IDD = ls[0][0]
            self.ui.lineEdit_dirty_ID.clear()
            self.ui.lineEdit_dirty_ID.setText(str(IDD).strip())
            filename = ls[0][1]
            self.ui.lineEdit_filename.clear()
            self.ui.lineEdit_filename.setText(str(filename).strip())
            project = ls[0][2]
            self.ui.lineEdit_project.clear()
            self.ui.lineEdit_project.setText(str(project))
            operator = ls[0][3]
            self.ui.lineEdit_operator.clear()
            self.ui.lineEdit_operator.setText(str(operator))
            created_date = ls[0][4]
            self.ui.lineEdit_created_date.clear()
            self.ui.lineEdit_created_date.setText(str(created_date))
            type = ls[0][5]
            self.ui.lineEdit_type.clear()
            self.ui.lineEdit_type.setText(str(type))
            polarity = ls[0][6]
            if str(polarity) == 'Positive':
                self.ui.radioButton_plus.setChecked(True)
                self.ui.radioButton_minus.setChecked(False)
            else:
                self.ui.radioButton_plus.setChecked(False)
                self.ui.radioButton_minus.setChecked(True)

            formulas = ls[0][7]
            self.ui.plainTextEdit_formula.clear()
            self.ui.plainTextEdit_formula.insertPlainText(str(formulas))
            trap = ls[0][8]
            self.ui.lineEdit_trap.clear()
            self.ui.lineEdit_trap.setText(str(trap))
            trans = ls[0][9]
            self.ui.lineEdit_trans.clear()
            self.ui.lineEdit_trans.setText(str(trans))
            conditions = ls[0][10]
            self.ui.lineEdit_conditions.clear()
            self.ui.lineEdit_conditions.setText(str(conditions))
            peaks = ls[0][11]
            self.ui.plainTextEdit_annotations.clear()
            self.ui.plainTextEdit_annotations.insertPlainText(str(peaks))
            lig_name = ls[0][12]
            self.ui.lineEdit_lig_name.clear()
            self.ui.lineEdit_lig_name.setText(str(lig_name))
            comment = ls[0][14]
            self.ui.plainTextEdit_comment.clear()
            self.ui.plainTextEdit_comment.insertPlainText(comment)
            spectrum = ls[0][15]
            spectrum = cPickle.loads(zlib.decompress(spectrum))
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(spectrum)
            ratios = ls[0][16]
            ratios = cPickle.loads(zlib.decompress(ratios))

            self.ui.plainTextEdit_ratios.clear()
            self.ui.plainTextEdit_ratios.insertPlainText(str(ratios))
            annotations = ls[0][17]
            self.ui.plainTextEdit_annotations_2.clear()
            self.ui.plainTextEdit_annotations_2.insertPlainText(
                str(annotations))

        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Enry {} doesn't exist in the database {}".format(ID, fname.upper()))
            else:
                print("Enry {} doesn't exist in the database {}".format(
                    ID, fname.upper()))
            return
        finally:
            conn.close()
    def _input(self):  # create new entry in current database
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename.text()).strip()
        project = str(self.ui.lineEdit_project.text())
        operator = str(self.ui.lineEdit_operator.text())
        type = str(self.ui.lineEdit_type.text())
        if self.ui.radioButton_plus.isChecked() == True:
            polarity = 'Positive'
        else:
            polarity = 'Negative'
        formulas = str(self.ui.plainTextEdit_formula.toPlainText())
        trap = str(self.ui.lineEdit_trap.text())
        trans = str(self.ui.lineEdit_trans.text())
        conditions = str(self.ui.lineEdit_conditions.text())
        peaks = str(self.ui.plainTextEdit_annotations.toPlainText())
        lig_name = ''
        lig_mass = ''
        spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
        spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, 
            names=['Mass', 'Intensity'])  # now spectrum is a pandas.DataFrame
        spectrum.sort_values(by='Mass', inplace=True)
        spectrum =spectrum.to_string(header=False, index=False)
        # print(spectrum)  

        
        ratios = str(self.ui.plainTextEdit_ratios.toPlainText())
        # Compress:
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        annotations = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        from datetime import datetime
        created_date = str(datetime.now())
        self.ui.lineEdit_created_date.setText(created_date)
        comment = str(self.ui.plainTextEdit_comment.toPlainText())
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        with conn:
            c.execute('SELECT max(rowid) FROM spectra')
            try:
                ID = c.fetchone()[0]+1
            except:
                ID = 1
            self.ui.lineEdit_ID.setText(str(ID))
            c.execute("SELECT * FROM spectra WHERE filename=:filename",
                      {'filename': filename})
            try:
                fn = c.fetchone()[1]
                QMessageBox.about(
                    self, "warning", "Item with file name {} already exists in the database. \nUse UPDATE to change it. ".format(fn))
            except:
                c.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                          'ID': ID, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum, 'ratios': ratios, 'annotations': annotations})
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "Message", "Entry added to database")
                else:
                    return
    def _fast_input(self):  # composite command for fast input
        try:
            self._paste()
            time.sleep(1)
            self._annotate()
            time.sleep(1)
            self._calculate_ratios_from_formula()
            time.sleep(1)
            self._input()
            time.sleep(1)
            self._show_entry()
            time.sleep(1)
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "Is there a spectrum to annotate? Did you provide suggestions for annotations?")
            else:
                print(
                    "Operation failed.Is there a spectrum to annotate? Did you provide suggestions for annotations?")
            return
        # QMessageBox.about(self, "timing","Execution of this function took {} s".format(time.time()-t0))
    def _delete_entry(self):  # delete entry in current database
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return

        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        ID = str(self.ui.lineEdit_ID.text())
        if not self.ui.checkBox_cancel_messages.isChecked():
            question = QMessageBox.question(self, 'Message', "Are you sure you want to delete entry # {}?".format(
                ID), QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        else:
            question = 16384
        if question == 16384:
            with conn:
                c.execute("DELETE from spectra WHERE ID=:ID", {'ID': ID})
    def _delete_list(self):  # delete entry in current database
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        IDs = str(self.ui.plainTextEdit_search_result_ID.toPlainText()).split(',')
        question = QMessageBox.question(
            self, 'Warning', "Are you sure you want to delete the whole list of entries?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if question == 16384:
            for ID in IDs:
                with conn:
                    c.execute("DELETE from spectra WHERE ID=:ID", {'ID': ID})
    def _create_newDB(self, fname='new'):  # create new database
        try:
            fname, ok = QInputDialog.getText(
                self, 'Input Dialog', 'Enter new database name:')
            if not os.path.exists('DB'):
                os.mkdir('DB')
            if not os.path.exists('DB/settings'):
                os.mkdir('DB/settings')
        except:
            pass
        self._newDB(fname=fname)
    def _newDB(self, fname='new'):  # create new database
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute("""CREATE TABLE spectra (ID INTEGER PRIMARY KEY,filename TEXT,project TEXT,operator TEXT,created_date TEXT,type TEXT,polarity TEXT,formulas TEXT,trap TEXT,trans TEXT,conditions TEXT,peaks TEXT,lig_name TEXT,lig_mass TEXT, comment TEXT, spectrum BLOB,ratios BLOB,annotations TEXT)""")
        except:
            QMessageBox.about(
                self, "confirm", "database DB/{}.db already exists".format(fname.upper()))
            return
        finally:
            conn.close()
    def _annotate(self):  # annotate spectrum
        Spectrum = StringIO(str(self.ui.plainTextEdit_spectrum.toPlainText()))
        Spectrum = pandas.read_csv(Spectrum, delim_whitespace=True, names=['Mass', 'Intensity'])
        self.ui.plainTextEdit_annotations.clear()
        accuracy = float(self.ui.lineEdit_accuracy.text())
        labels = StringIO(str(self.ui.plainTextEdit_annotations_2.toPlainText()))
        labels = pandas.read_csv(labels, delim_whitespace=True, names=['Mass', 'Label'])
        if str(self.ui.lineEdit_type.text()) == 'list':
            S = swrm.annotate(Spectrum, labels, accuracy)
        else:
            # S=annotateALL(Spectrum,labels,accuracy)
            S = swrm.annotate(Spectrum, labels, accuracy)
        self.ui.plainTextEdit_annotations.insertPlainText(S)
    def _calculate_ratios_from_formula(self):
        formulas = self.ui.plainTextEdit_formula.toPlainText().split(',')
        self.ui.plainTextEdit_ratios.clear()
        peaks = StringIO(str(self.ui.plainTextEdit_annotations.toPlainText()))
        peaks = pandas.read_csv(peaks, delim_whitespace=True, names=['Mass',
                                                                       'Intensity', 'delta', 'Label'])
        TP=[]
        CH=[]
        INT=[]
        for f in range(len(peaks.Label)):
            TP.append(peaks.Label[f].split('_')[0])
            CH.append(peaks.Label[f].split('_')[1].replace('+', ' ').replace('-', ' '))
            INT.append(float(peaks.Intensity[f])/int(peaks.Label[f].split('_')[1].replace('+', ' ').replace('-', ' ')))
        peaks['TP']=TP
        peaks['CH']=CH
        peaks['INT']=INT
        # print(peaks)
        for formula in formulas:
            try:
                b = formula.replace(')', ' ').replace('(', ' ').replace(
                    '/', ' ').replace('*', ' ').replace('-', ' ').replace('+', ' ').split()
                for q in b:
                    if not self.ui.checkBox_normalize.isChecked():
                        a = '''{}=peaks.loc[peaks['TP'] == '{}'].Intensity.sum()'''.format(
                            str(q), str(q))
                    else:
                        a = '''{}=peaks.loc[peaks['TP'] == '{}'].INT.sum()'''.format(
                            str(q), str(q))

                    exec(a)
                self.ui.plainTextEdit_ratios.insertPlainText(
                    str(eval(formula))+'\n')
            except:
                self.ui.plainTextEdit_ratios.insertPlainText('NO_VALUE'+'\n')
                return
    def _transferDB(self):
        '''transfer entries listed in plainTextEdit_search_result_ID from donor to recipient database'''
        DBs = self._show_DB(noshow=True)
        donor = str(self.ui.lineEdit_DB_donor.text()).strip().upper()
        if not donor in DBs:
            print("Database {} doesn't exist".format(donor))
            return
        recipient = str(self.ui.lineEdit_DB_recipient.text()).strip().upper()
        if not recipient in DBs:
            self._newDB(fname=recipient)
        conn = sqlite3.connect("DB/{}.db".format(donor))
        c = conn.cursor()
        conn2 = sqlite3.connect("DB/{}.db".format(recipient))
        c2 = conn2.cursor()
        id = str(self.ui.plainTextEdit_search_result_ID.toPlainText()).split(',')
        id1 = []
        for i in id:
            if not i == '':
                id1.append(int(i))
        c2.execute('SELECT max(rowid) FROM spectra')
        id2 = c2.fetchone()[0]
        if id2 == None:
            id2 = 0
        n = id2
        print('max id=', n)
        for ID in id1:
            with conn:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                ls = c.fetchall()
            filename = ls[0][1]
            project = ls[0][2]
            operator = ls[0][3]
            created_date = ls[0][4]
            type = ls[0][5]
            polarity = ls[0][6]
            formulas = ls[0][7]
            trap = ls[0][8]
            trans = ls[0][9]
            conditions = ls[0][10]
            peaks = ls[0][11]
            lig_name = ls[0][12]
            lig_mass = ls[0][13]
            comment = ls[0][14]
            spectrum = ls[0][15]
            ratios = ls[0][16]
            annotations = ls[0][17]
            spectrum1 = spectrum
            ratios1 = ratios

            with conn2:
                try:
                    c2.execute(
                        "SELECT * FROM spectra WHERE filename=:filename", {'filename': filename})
                    ls = c2.fetchall()
                    date = ls[0][4]
                    if created_date > date:
                        command = """UPDATE spectra SET filename='{}',project='{}',operator='{}',created_date='{}',type='{}',polarity='{}',formulas='{}',trap='{}',trans='{}',conditions='{}',peaks='{}',lig_name='{}',lig_mass='{}',comment='{}',annotations='{}'""".format(
                            filename, project, operator, created_date, type, polarity, formulas, trap, trans, conditions, peaks, lig_name, lig_mass, comment, annotations)
                        command = command+""" WHERE filename = '%s'""" % filename
                    else:
                        print("Newer item with file name {} already exists in the recipient database. No change needed. ".format(
                            filename))
                except:
                    n = n+1
                    c2.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                               'ID': n, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum1, 'ratios': ratios1, 'annotations': annotations})
    def _modify_field(self):  # update entry in current database
        try:
            IDs = str(
                self.ui.plainTextEdit_search_result_ID.toPlainText()).split(',')
            donor = str(self.ui.lineEdit_DB_donor.text())
            NEW_CONTENT = str(self.ui.plainTextEdit_new_content.toPlainText())
            fname = str(self.ui.lineEdit_DB_file.text()).upper()
            field = str(self.ui.comboBox_field2change.currentText()).strip()
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            for ID in IDs:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                command = """UPDATE spectra SET {} ='{}'  WHERE ID = '{}'""".format(
                    field, NEW_CONTENT, ID)
                with conn:
                    c.execute(command)
        except:
            QMessageBox.about(
                self, "warning", "Please choose field you wish to modify.")
    def _recalculate_formulas(self):
        self.ui.checkBox_cancel_messages.setChecked(True)
        IDs = str(self.ui.plainTextEdit_search_result_ID.toPlainText()).split(',')
        for ID in IDs:
            self.ui.lineEdit_ID.setText(ID)
            self._show_entry()
            self._annotate()
            self._calculate_ratios_from_formula()
            self._update(settings=False,nospectrum=True)
    def _areas(self):
        self.ui.checkBox_cancel_messages.setChecked(True)
        try:
            IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
            for ID in IDs:
                self.ui.lineEdit_ID.setText(ID)
                self._show_entry()
                spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())# spectrum is loaded as str
                spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=[
                                             'Mass', 'Intensity'])  # spectrum is Pandas pandas.DataFrame
                limits = str(self.ui.plainTextEdit_area.toPlainText()).split('\n')
                charges = str(self.ui.plainTextEdit_charge.toPlainText()).split('\n')
                rate = int(self.ui.lineEdit_rate_3.text())
                padding= int(self.ui.lineEdit_padding.text())
                centroid = ''
                area = ''
                Prod=0
                AR=0
                for f in enumerate(limits):
                    left = float(f[1].split()[0])
                    right = float(f[1].split()[1])
                    if self.ui.checkBox_chargeNormalize.isChecked():
                        ch=int(charges[f[0]])
                    else:
                        ch=1
                    new = swrm.resample_spectrum(spectrum, left, right, rate,padding)
                    A=new.Intensity.sum()/ch
                    area = area+str(round(A))+'\n'
                    AR=AR+A
                    COG = swrm.center_of_gravity(new, left, right,ch)
                    Prod=Prod+COG*A
                    
                    COG = round(COG, 3)
                    centroid = centroid+str(round(COG, 3))+'\n'

                self.ui.plainTextEdit_ratios.clear()
                self.ui.plainTextEdit_ratios.insertPlainText(area)
                self._update()      


        except Exception as e:
            QMessageBox.about(self, "warning", "Check ID entries in Manage Database tab. Check if the spectrum exist.Check ID entries in Manage Database tab. If you process high resolution spectrum increase sampling rate and padding ~10 fold (padding may require more than 10).")
            return
    def _report(self):  
        IDs = str(self.ui.plainTextEdit_search_result_ID.toPlainText()).split(',')
        fname = str(self.ui.lineEdit_DB_file.text()).upper()
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        DF = pandas.read_csv(StringIO('filename'+'\n'+'conditions'), delim_whitespace=True,names=['file name'])
        print(DF)
        for id in IDs:
            if not id == '':
                with conn:
                    c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': id})
                ls = c.fetchall()
                file = ls[0][1]
                ratios = ls[0][16]
                conditions = ls[0][10]
                ratios = cPickle.loads(zlib.decompress(ratios))
                line = file+'\n'+conditions+'\n'+ratios
                df = pandas.read_csv(StringIO(line),delim_whitespace=True, names=[file])
                DF = pandas.concat([DF, df], axis=1)
        try:
            DF.T.to_csv('results/report4database_{}.csv'.format(fname.upper()),header=False, index=False)
        except:
            fname, ok = QInputDialog.getText(self, 'Input Dialog', 'Cannot save to file report4database_{}.csv. \nCheck if the file is opened in other program. Close it or enter a new file name:'.format(fname.upper()))
            DF.T.to_csv('results/{}.csv'.format(fname.upper()),header=False,index=False)
    def _autoSWARM(self):
        self.ui.checkBox_cancel_messages.setChecked(True)
        IDs = str(self.ui.plainTextEdit_search_result_ID.toPlainText()).split(',')
        DBs = self._show_DB(noshow=True)
        donor = str(self.ui.lineEdit_DB_donor.text()).strip()
        if not donor in DBs:
            print("Database {} doesn't exist".format(donor))
            return
        recipient = str(self.ui.lineEdit_DB_recipient.text()).strip()
        if not recipient in DBs:
            self._newDB(fname=recipient)
            print("Database {} doesn't exist".format(recipient))
            return
        self.ui.checkBox_use_database.setChecked(1)
        for ID in IDs:
            self.ui.lineEdit_DB_file.setText(donor)
            self.ui.lineEdit_ID.setText(ID)
            self._show_entry()
            self._SWARM(True)
            self.ui.lineEdit_DB_file.setText(recipient)
            self._annotate()
            self._calculate_ratios_from_formula()
            sufx = str(self.ui.lineEdit_suffix.text()).strip()
            fi = str(self.ui.lineEdit_filename.text()).strip()+sufx
            self.ui.lineEdit_filename.setText(fi)
            self._input()
    def _plot_DB_spectrum(self):  # plot spectrum from plainTextEdit_spectrum field
        import matplotlib.pyplot as plt
        Spectrum = StringIO(str(self.ui.plainTextEdit_spectrum.toPlainText()))
        df = pandas.read_csv(Spectrum, delim_whitespace=True, names=[
                               'Mass', 'Intensity'])
        if self.ui.checkBox_replace.isChecked():
            plt.close('all')
        linewidth = float(self.ui.lineEdit_linewidth.text())
        fontsize = float(self.ui.lineEdit_fontsize.text())
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels

        offset = str(self.ui.lineEdit_offset.text()).replace(
            ',', ' ').replace('(', ' ').replace(')', ' ').split()
        fig = plt.figure()
        ax = fig.add_subplot(111)

        # if self.ui.checkBox_center_gravity.isChecked():
            # limits = str(self.ui.plainTextEdit_area.toPlainText()).split('\n')
            # rate = int(self.ui.lineEdit_rate.text())
            # padding= int(self.ui.lineEdit_padding.text())
            # centroid = ''
            # area = ''
            # for f in limits:
                # left = float(f.split()[0])
                # right = float(f.split()[1])
                # new = swrm.resample_spectrum(df, left, right, rate,padding)
                # area = area+str(round(new.Intensity.sum()))+'\n'
                # COG = swrm.center_of_gravity(new, left, right)
                # COG = round(COG, 2)
                # centroid = centroid+str(round(COG, 2))+'\n'
                # y = df.Intensity.max()
                # plt.bar(left, y, color='blue')
                # plt.bar(right, y, color='black')
                # plt.bar(COG, y, color='r',
                        # label='center of gravity is {} m/z'.format(COG))
            # self.ui.plainTextEdit_centroid.clear()
            # self.ui.plainTextEdit_centroid.insertPlainText(centroid)
            # self.ui.plainTextEdit_area_result.clear()
            # self.ui.plainTextEdit_area_result.insertPlainText(area)

        plt.plot(df.Mass, df.Intensity, color='blue',
                 linewidth=linewidth, label='spectrum')

        if self.ui.checkBox_show_legend.isChecked():
            plt.legend()
        plt.xlabel('m/z')
        plt.ylabel('Intensity')
        if self.ui.checkBox_annotate.isChecked():
            AN = StringIO(str(self.ui.plainTextEdit_annotations.toPlainText()))
            AN = pandas.read_csv(AN, delim_whitespace=True, names=[
                                   'Mass', 'Intensity', 'delta', 'Label'])
            AN.drop('delta', axis=1, inplace=True)
            AN = AN.set_index('Label')
            if self.ui.checkBox_vertical.isChecked():
                rotation = 90
            else:
                rotation = 0
            for k, v in AN.iterrows():
                ax.annotate(k, v,
                            xytext=(int(offset[0]), int(offset[1])), rotation=rotation, textcoords='offset points',
                            fontsize=fontsize-2, color='black')
        plt.show()
    def _clear_SWARM_form(self):
        # self.ui.lineEdit_ref_range.clear()
        self.ui.plainTextEdit_TMPL.clear()
        self.ui.plainTextEdit_foundPEAKS.clear()
        self.ui.plainTextEdit_add_PEAKS_0.clear()
        self.ui.plainTextEdit_original_spectrum.clear()
        self.ui.plainTextEdit_final_spectrum.clear()
    def _standardize(self):
        #reset  variables-DataFrames
        self.SWARM_DF=pandas.DataFrame()
        self.TEMPLATES=pandas.DataFrame()
        try:    # collect parameters
            lamO = float(self.ui.lineEdit_lambda_2.text())
            pO = float(self.ui.lineEdit_p_2.text())
            lamB = float(self.ui.lineEdit_lambda.text())
            pB = float(self.ui.lineEdit_p.text())
            lamE = float(self.ui.lineEdit_lambda_3.text())
            pE = float(self.ui.lineEdit_p_3.text())
            lamA = float(self.ui.lineEdit_lambda_4.text())
            pA = float(self.ui.lineEdit_p_4.text())
            iter = int(self.ui.lineEdit_iter.text())
            accuracy = float(self.ui.lineEdit_accuracy.text())
            sgwin = int(round(float(self.ui.lineEdit_sgwindow.text())))
            lineEdit_sgorder = int(self.ui.lineEdit_sgorder.text())
            each = 0
            if self.ui.checkBox_asym_bground_every.isChecked():
                each = 1
            try:
                low = int(self.ui.lineEdit_low.text())
            except:
                low = 0
            try:
                high = int(self.ui.lineEdit_high.text())
            except:
                high = 10000000
            try:
                rate = int(self.ui.lineEdit_rate.text())
                padding= int(self.ui.lineEdit_padding.text())
            except:
                rate = 25
                padding= 1
        except:
            if not self.ui.checkBox_cancel_messages.isChecked():
                QMessageBox.about(
                    self, "warning", "All parameters must have numeric values. Even if a parameter is not used put a placeholder value.")
            else:
                print(
                    "All parameters must have numeric values. Even if a parameter is not used put a placeholder value.")
            return

        if self.ui.checkBox_use_database_settings.isChecked():#apply settings from current database entry
            try:
                ID = str(self.ui.lineEdit_ID.text())
                fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
            except:
                QMessageBox.about(self, "warning", "Database and entry must be specified")
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                ls = c.fetchall()
                settings = ls[0][12].split('\n')
                # print(settings)
            for line in settings: 
                p = line.split('@')
                if p[0] in self.pars1:
                    S = "self.ui.%s.setText('%s')" % (p[0], str(p[1][:]))
                    a = eval(S)
                if p[0] in self.pars2:
                    S = "self.ui.%s.clear()" % (p[0])
                    a = eval(S)
                    SS = "self.ui.%s.insertPlainText('%s')" % (
                        p[0], str(p[1][:]).replace('$', '\\n'))
                    b = eval(SS)
                if p[0] in self.pars3:
                    if eval(str(p[1][:])) == True:
                        S = "self.ui.%s.setChecked(True)" % (p[0])
                        a = eval(S)
                    else:
                        S = "self.ui.%s.setChecked(False)" % (p[0])
                        a = eval(S)

        if not self.ui.checkBox_use_database.isChecked():
            spectrum = str(self.ui.plainTextEdit_original_spectrum.toPlainText())
            if spectrum == '':
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Spectrum is missing")
                else:
                    print("Spectrum is missing")
                return
        else:
            ID = str(self.ui.lineEdit_dirty_ID.text())
            self.ui.lineEdit_ID.clear()
            self.ui.lineEdit_ID.setText(ID)
            self._show_entry()
            # spectrum is a str variable
            spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
        spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, 
                    names=['Mass', 'Intensity'])  # now spectrum is a pandas.DataFrame
        # df is the main pandas.DataFrame, a container for original spectrum and all derived results
        df = pandas.DataFrame()
        if not self.ui.checkBox_resample.isChecked():
            df['Mass'] = spectrum.Mass.values 
            df['Original'] = spectrum.Intensity.values
            df['Original']=df['Original']/df['Original'].max()
            # assign all columns the same as value as in Original
            df['SG'] = df['Original'].values    # a placeholder for outline
            df['Before'] = df['Original'].values # a placeholder
            df['Final'] = df['Original'].values # a placeholder
            df['Base'] = df['Original'].values # a placeholder for baseline
        else:
            new = swrm.resample_spectrum(spectrum, low, high, rate, padding)
            if isinstance(new, pandas.DataFrame):
                df['Mass'] = new.Mass.values
                df['Original'] = new.Intensity.values
                df['Original']=df['Original']/df['Original'].max()
                df.dropna(inplace=True)
                df['SG'] = df['Original'].values
                df['Before'] = df['Original'].values
                df['Final'] = df['Original'].values
                df['Base'] = df['Original'].values

        if self.ui.checkBox_Savitzky.isChecked():
            try:
                if not sgwin % 2 == 0:
                    if not sgwin < lineEdit_sgorder:
                        df['SG'] = sg(df['Original'].values,
                                      sgwin, lineEdit_sgorder)
                        df['Before'] = df['SG'].values
                        df['Final'] = df['SG'].values
                    else:
                        if not self.ui.checkBox_cancel_messages.isChecked():
                            QMessageBox.about(
                                self, "warning", "Savitzky-Golay order must not be greater than window length")
                        else:
                            print(
                                "Savitzky-Golay order must not be greater than window length")

                else:
                    if not self.ui.checkBox_cancel_messages.isChecked():
                        QMessageBox.about(
                            self, "warning", "Savitzky-Golay window must be an odd number.")
                    else:
                        print("Savitzky-Golay window must be an odd number.")
            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "warning", "Savitzky-Golay failed. Either cannot find the spectrum or parameters are missing.")
                else:
                    print("Savitzky-Golay failed. Cannot find the spectrum.")
                return
        #####CREATE OUTLINE
        if self.ui.checkBox_make_outline.isChecked():
            
            try:
                outline = -1*swrm.baseline(-1*df['Original'],lamO,pO)
                df['SG'] = outline
                df['Before'] = df['SG'].values
                df['Final'] = df['SG'].values
 
            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(
                        self, "warning", "Outline cannot be generated. Cannot find the spectrum.")
                else:
                    print("Outline cannot be generated. Cannot find the spectrum.")
                return
        if self.ui.checkBox_asym_bground_Before.isChecked():
            try:
                bsl = swrm.baseline(df.Final.values, lam=lamB, p=pB, niter=iter)
                df.Before = df.Final-bsl
                df['Final'] = df['Before']
                df.Base = bsl

            except:
                if not self.ui.checkBox_cancel_messages.isChecked():
                    QMessageBox.about(self, "warning", "Baseline calculation BEFORE SWARM failed. This computer may have insufficient memory. Calculation of Asymmetric Least Square baseline requires large amount of RAM. RAM demands scale as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                else:
                    print("Baseline calculation BEFORE failed. This computer may have insufficient memory. Calculation of Asymmetric Least Square baseline requires large amount of RAM. RAM demands scale as square of the number of data points. Try to reduce spectrum range and/or reduce sampling rate.")
                return
        if not self.ui.checkBox_use_database_ann.isChecked():
            try:
                LB = str(self.ui.plainTextEdit_add_PEAKS_0.toPlainText())
            except:
                QMessageBox.about(self, "warning", "Annotations are required")
                return
        else:
            self.ui.plainTextEdit_add_PEAKS_0.clear()
            LB = str(self.ui.plainTextEdit_annotations_2.toPlainText())
            self.ui.plainTextEdit_add_PEAKS_0.insertPlainText(LB)
        labels = pandas.read_csv(
            StringIO(LB), delim_whitespace=True, names=['Mass', 'Label'])
        accuracy = float(self.ui.lineEdit_accuracy_2.text())
        Spectrum=pandas.DataFrame()
        Spectrum['Mass']=df.Mass
        Spectrum['Intensity']=df.Final
        S = swrm.annotate(Spectrum, labels, accuracy)
        labels = pandas.read_csv(StringIO(S), delim_whitespace=True, names=['Mass','Amplitude','sigma1','Label'])
        lbls = labels['Label']
        labels['sigma1']=1
        labels = labels.drop(['Label'], axis=1)
        labels['area']=0
        labels['Label']=lbls
        S=swrm.nice_table(labels,header=False)
        self.ui.plainTextEdit_found_parameters.clear()
        self.ui.plainTextEdit_found_parameters.insertPlainText(S)

        self.SWARM_DF = df.copy()
        try:
            self.SWARM_DF.to_csv("results/SWARM_DF.tsv",sep='\t',index=False)
            cPickle.dump( self.SWARM_DF, open( "results/SWARM_DF.pickle", "wb" ) )

        except:
            print('Cannot write to file. File SWARM_DF.tsv might be opened in Excel')
            return
    def _simulateGauss(self):
        accuracy = float(self.ui.lineEdit_accuracy_2.text())
        self.TEMPLATES = pandas.DataFrame()
        df=self.SWARM_DF.copy()
        LB = str(self.ui.plainTextEdit_found_parameters.toPlainText())
        labels = pandas.read_csv(StringIO(LB), delim_whitespace=True, names=['Mass','Amplitude','sigma1','area','Label'])
        lab=list(labels.Label)
        try:
            x=df.Mass
            y=df.Final
        except:
            QMessageBox.about(self, "warning", "Data not found. Must run Standardize Spectrum first.")
            return
        plt.plot(x, y, 'o',label='sum')
        
        # if self.ui.checkBox_sigma.isChecked():
            # labels.sigma1=1
        
        labels = labels.drop(['area','Label'], axis=1)
        p0=labels.values.flatten()
        BOUNDS=labels.copy()
        BOUNDS['1']=BOUNDS.Mass-accuracy
        BOUNDS['2']=0
        BOUNDS['3']=0
        BOUNDS['4']=BOUNDS.Mass+accuracy
        BOUNDS['5']=1
        BOUNDS['6']=np.inf
        bnds=(BOUNDS[['1','2','3']].values.flatten(),BOUNDS[['4','5','6']].values.flatten())
        
        from scipy.optimize import curve_fit
        import random
        try:
            if self.ui.radioButton_Gaussians.isChecked():
                coeff, var_matrix = curve_fit(swrm.sumgauss, x, y, p0=p0,bounds=bnds)
            if self.ui.radioButton_Lorentzians.isChecked():
                coeff, var_matrix = curve_fit(swrm.sumlorentz, x, y, p0=p0,bounds=bnds)
                
        except:
            QMessageBox.about(self, "warning", "Optimal parameters could not be found. Exceeded limit of iterations.")
            return
        mass=[]
        amp=[]
        sig1=[]
        area=[]
        scale=1
        for f in range(len(coeff)//3):
            mass.append(coeff[3*f])
            amp.append(coeff[3*f+1])
            sig1.append(coeff[3*f+2])
            if self.ui.radioButton_Gaussians.isChecked():
                area.append(coeff[3*f+1]*coeff[3*f+2]*np.sqrt(2*np.pi))
            if self.ui.radioButton_Lorentzians.isChecked():
                area.append(coeff[3*f+1]*coeff[3*f+2]*np.pi)
        labels.Mass=mass
        labels.Amplitude=amp
        labels.sigma1=sig1

        n=0
        for index, row in labels.iterrows():
            if self.ui.radioButton_Gaussians.isChecked():
                self.TEMPLATES[n]= swrm.gauss(x,*row)
            if self.ui.radioButton_Lorentzians.isChecked():
                self.TEMPLATES[n]= swrm.lorentzian(x,*row)
            n+=1
        if self.ui.radioButton_Gaussians.isChecked():
            yfit=swrm.sumgauss(x,*coeff)
        if self.ui.radioButton_Lorentzians.isChecked():
            yfit=swrm.sumlorentz(x,*coeff)
        self.TEMPLATES['yfit']=yfit 
        try:
            self.TEMPLATES.to_csv("results/TEMPLATES.tsv",sep='\t',index=False)
            cPickle.dump( self.TEMPLATES, open( "results/TEMPLATES.pickle", "wb" ) )
        except:
            print('Cannot write to file. File TEMPLATES.tsv might be opened in Excel')
            return
        labels['Label']=lab
        S=swrm.nice_table(labels,header=False)
        self.ui.plainTextEdit_foundPEAKS.clear()
        self.ui.plainTextEdit_foundPEAKS.insertPlainText(S)
        labels['area']=area
        labels = labels.drop(['Label'], axis=1)
        labels['Label']=lab
        S=swrm.nice_table(labels,header=False)

        self.ui.plainTextEdit_found_parameters.clear()
        self.ui.plainTextEdit_found_parameters.insertPlainText(S)
        plt.plot(x, yfit, '--',label='sum')
        #calculate coefficient of determination R2
        # residual sum of squares
        ss_res = ((y - yfit) ** 2).sum()

        # total sum of squares
        ss_tot = ((y - yfit.mean()) ** 2).sum()

        # calculate r-squared
        r2 = 1 - (ss_res / ss_tot)
        self.ui.lineEdit_R2.clear()
        self.ui.lineEdit_R2.setText(str(r2))
        plt.show()
    def _replot_Gaussian_from_parameters(self):

        LB = str(self.ui.plainTextEdit_found_parameters.toPlainText())
        labels = pandas.read_csv(StringIO(LB), delim_whitespace=True, names=['Mass','Amplitude','sigma1','area','Label'])
        lab=list(labels.Label)
        labels = labels.drop(['area','Label'], axis=1)
        
        self._standardize()
        self.TEMPLATES = pandas.DataFrame()
        df=self.SWARM_DF.copy() 
        try:
            x=df.Mass
            y=df.Final
        except:
            QMessageBox.about(self, "warning", "Data not found. Must run Standardize Spectrum first.")
            return
        plt.plot(x, y, 'o',label='sum')
       
        n=0
        for index, row in labels.iterrows():
            if self.ui.radioButton_Gaussians.isChecked():
                self.TEMPLATES[n]= swrm.gauss(x,*row)
            if self.ui.radioButton_Lorentzians.isChecked():
                self.TEMPLATES[n]= swrm.lorentzian(x,*row)
            n+=1
        yfit=self.TEMPLATES.sum(axis=1)
        self.TEMPLATES['yfit']=yfit 
        try:
            self.TEMPLATES.to_csv("results/TEMPLATES.tsv",sep='\t',index=False)
            cPickle.dump( self.TEMPLATES, open( "results/TEMPLATES.pickle", "wb" ) )
        except:
            print('Cannot write to file. File TEMPLATES.tsv might be opened in Excel')
            return
        self.ui.plainTextEdit_found_parameters.clear()
        self.ui.plainTextEdit_found_parameters.insertPlainText(LB)
        self.ui.plainTextEdit_found_parameters.toPlainText()

        plt.plot(x, yfit, '--',label='sum')
        plt.show()        
        
############# PLOT PRESENTATION
    def _load_TEMPLATES(self):
        try:
            fname = QFileDialog.getOpenFileName(self, 'Open file with pickled SWARM data', 'results')[0]
            self.SWARM_DF=cPickle.load( open( fname, "rb" ) )
        except:
            return
        try:
            fname = QFileDialog.getOpenFileName(self, 'Open file pickled with TEMPLATES', 'results')[0]
            self.TEMPLATES=cPickle.load( open( fname, "rb" ) )
        except:
            return
        return self.SWARM_DF,self.TEMPLATES
    def _paste_plotspectrum(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_plotspectrum.clear()
        self.ui.plainTextEdit_plotspectrum.insertPlainText(data)
    def _paste_plotspectrum_2(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_plotspectrum_2.clear()
        self.ui.plainTextEdit_plotspectrum_2.insertPlainText(data)
    def _paste_plotspectrum_3(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_plotspectrum_3.clear()
        self.ui.plainTextEdit_plotspectrum_3.insertPlainText(data)
    def _paste_plotspectrum_4(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_plotspectrum_4.clear()
        self.ui.plainTextEdit_plotspectrum_4.insertPlainText(data)
    def _paste_plotspectrum_5(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_plotspectrum_5.clear()
        self.ui.plainTextEdit_plotspectrum_5.insertPlainText(data)
    def _paste_plotspectrum_6(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_plotspectrum_6.clear()
        self.ui.plainTextEdit_plotspectrum_6.insertPlainText(data)
    def _plot_figure(self):
        if self.ui.clear_figs.isChecked():
            plt.close('all')
        try:
            low = float(self.ui.lineEdit_left.text())
            high = float(self.ui.lineEdit_right.text())
        except:
            QMessageBox.about(self, "warning", "margins are required")
            return
        try:
            linewidth = float(self.ui.lineEdit_linewidth_2.text())
        except:
            linewidth =1
        linecolor = str(self.ui.lineEdit_linecolor.text())
        if linecolor=='':
            linecolor=None
        try:
            axlinewidth = float(self.ui.lineEdit_linewidth_3.text())
        except:
            axlinewidth=1
        try:
            delta = float(self.ui.lineEdit_accuracy.text())
        except:
            delta=1
        # matplotlib.rc('lines', linewidth=linewidth, color='b')
        try:
            fontsize=int(self.ui.lineEdit_fontsize_2.text())
        except:
            fontsize=12
        font=str(self.ui.lineEdit_font.text())
        offset=str(self.ui.lineEdit_offset_2.text())
        try:
            rate=int(self.ui.lineEdit_resamplerate.text())
            padding= int(self.ui.lineEdit_padding.text())
        except:
            rate=25
            padding= 1
        try:    
            w=float(self.ui.figwidth.text())
            h=float(self.ui.fighight.text())
        except:
            w,h=(8,6)
        try:
            bottom=float(self.ui.lineEdit_y_starts_at.text())
        except:
            bottom=0
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels

        fig, ax = plt.subplots(figsize=(w,h))

        #from DB ###############################################
        SPECTRA=[]
        spectra=['plainTextEdit_plotspectrum','plainTextEdit_plotspectrum_2','plainTextEdit_plotspectrum_3','plainTextEdit_plotspectrum_4','plainTextEdit_plotspectrum_5','plainTextEdit_plotspectrum_6']
        if self.ui.plot_reverse.isChecked():
            spectra=spectra[::-1]
        if self.ui.plot_entries.isChecked():
            fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
            IDs = str(self.ui.plainTextEdit_search_result_ID_2.toPlainText()).split(',')
            if self.ui.plot_reverse.isChecked():
                IDs=IDs[::-1]
            print('IDs',IDs)
            DBs = self._show_DB(noshow=True)
            if not fname in DBs:
                QMessageBox.about(self, "warning", "Database {} doesn't exist".format(fname.upper()))
                return
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            for ID in IDs:
                with conn:
                    c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                    ls = c.fetchall()
                    spectrum = ls[0][15]
                    spectrum = cPickle.loads(zlib.decompress(spectrum))
                    SPECTRA.append(spectrum)
        else:
            for f in spectra:
                spectrum = eval('str(self.ui.{}.toPlainText())'.format(f)) # spectrum is loaded as str
                if not spectrum=='':
                    SPECTRA.append(spectrum)
        ########from textbox ####################################################
        
        try:
            spectrum = SPECTRA[0]# spectrum is loaded as str
            ref_spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=['Mass', 'Intensity']) 
            ref =swrm.resample_spectrum(ref_spectrum, low, high, rate,padding)
            ref.Intensity=ref.Intensity/ref.Intensity.max()
            off=1.05
            plt.plot(ref.Mass, ref.Intensity, linewidth=linewidth, color=linecolor, label='spectrum1')
            ref.to_csv('results/ref.tsv',sep='\t',index=False)
        except Exception as e:
            QMessageBox.about(self, "warning", "Spectrum #1 is required. Check if the spectrum exist. If you process high resolution spectrum increase sampling rate and padding ~10 fold (padding may require more than 10).")
            return

        if not offset=='':
            off=float(offset)
        n=2
        for tag_spectrum in SPECTRA[1:]:
            try:
                tag_spectrum = pandas.read_csv(StringIO(tag_spectrum), delim_whitespace=True, names=['Mass', 'Intensity'])
                df=swrm.difference(ref_spectrum, tag_spectrum, 2000,1,low, high,rate=rate,sgwin=41,sgorder=4,doSG=0,scale=1)
                df.tag=df.tag/df.tag.max()
                offf=1.05
                plt.plot(df.Mass, df.tag+off, linewidth=linewidth, color=linecolor,label='spectrum'+str(n))
            except:
                pass
            if not offset=='':
                off=off+float(offset)
            else:
                off=off+offf
            n=n+1
        if not self.ui.box.isChecked():
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
        if not self.ui.y_ax.isChecked():
            ax.spines['left'].set_visible(False)
            ax.yaxis.set_ticks_position('none')
            ax.ticklabel_format(style='plain')
            plt.tick_params(axis='y',  labelleft=False, labelright=False)
        if not self.ui.x_ticks_labels.isChecked():
            ax.tick_params(labelbottom=False)
        for tick in ax.get_xticklabels():
            tick.set_fontname(font)
        for tick in ax.get_yticklabels():
            tick.set_fontname(font)
        
        from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
        ax.tick_params(which='major',direction='out', width=axlinewidth)
        ax.tick_params(which='minor',  direction='out', width=axlinewidth)
        if self.ui.checkBox_y_starts_at.isChecked():
            ax.set_ylim(bottom=bottom)
        
        try:
            major=int(self.ui.majorticks.text())
            minor=int(self.ui.minorticks.text())
        except:
            major,minor=(1000,100)
        try:    
            majorLocator = MultipleLocator(major)
            majorFormatter = FormatStrFormatter('%d')
            minorLocator = MultipleLocator(minor)
            ax.xaxis.set_major_locator(majorLocator)
            ax.xaxis.set_major_formatter(majorFormatter)
            ax.xaxis.set_minor_locator(minorLocator)
            ax.spines['top'].set_linewidth(axlinewidth)
            ax.spines['bottom'].set_linewidth(axlinewidth)
            ax.spines['left'].set_linewidth(axlinewidth)
            ax.spines['right'].set_linewidth(axlinewidth)
            
        except:
            QMessageBox.about(self, "warning", "change parameters for ticks")
            return
        if self.ui.legend.isChecked():
            plt.legend()
            #plt.xlabel('m/z')
        try:
            plt.savefig('results/FIGURE.eps', dpi=200, orientation='portrait', format='eps', transparent=True, bbox_inches='tight')
            plt.savefig('results/FIGURE.png', dpi=200, format='png', transparent=True, bbox_inches='tight')
            plt.show()
        except:
            QMessageBox.about(self, "warning", "Cannot plot. Check spectrum margins.")
            return
    def _quick_clear(self):
        self.ui.plainTextEdit_plotspectrum.clear()
        self.ui.plainTextEdit_plotspectrum_2.clear()
        self.ui.plainTextEdit_plotspectrum_3.clear()
        self.ui.plainTextEdit_plotspectrum_4.clear()
        self.ui.plainTextEdit_plotspectrum_5.clear()
        self.ui.plainTextEdit_plotspectrum_6.clear()
    def _ttest(self):
        import scipy.stats as stats  
        self.ui.plainTextEdit_t_mean.clear()
        self.ui.plainTextEdit_t_std.clear()
        self.ui.plainTextEdit_Pvalue.clear()

        variance=str(self.ui.comboBox_variance.currentText())
        if variance=='different variances':
            VAR=False
        elif variance=='equal variance':
            VAR=True
        else:
            VAR=False       
        ref= StringIO(str(self.ui.lineEdit_refvalues.text()))
        val= StringIO(str(self.ui.plainTextEdit_target.toPlainText()))
        DF1=pandas.read_csv(ref,delim_whitespace=True,header=None)
        DF2=pandas.read_csv(val,delim_whitespace=True,header=None)
        DF=pandas.DataFrame(DF2.values.T)
        try:
            for f in range(DF.shape[1]):
                if self.ui.radioButton_Student.isChecked():
                    FF,PP=stats.ttest_ind(DF1.T[0],DF[f],equal_var=VAR)
                if self.ui.radioButton_Runksum.isChecked():
                    FF,PP=stats.ranksums(DF1.T[0],DF[f])
                self.ui.plainTextEdit_t_mean.insertPlainText('{}\n'.format(round(DF[f].mean(),8)))
                self.ui.plainTextEdit_t_std.insertPlainText('{}\n'.format(round(DF[f].std(),8)))
                self.ui.plainTextEdit_Pvalue.insertPlainText('{}\n'.format(PP))
        except: 
            QMessageBox.about(self, "warning", "The datasets must contain only numerical values")
            return
    def _ttest_col(self):
        import scipy.stats as stats  
        
        val1= StringIO(str(self.ui.plainTextEdit_refvalues_2.toPlainText()))
        val2= StringIO(str(self.ui.plainTextEdit_target_2.toPlainText()))
        DF1=pandas.read_csv(val1,delim_whitespace=True,names=['variables'])
        DF2=pandas.read_csv(val2,delim_whitespace=True,names=['variables'])
        variance=str(self.ui.comboBox_variance.currentText())
        if variance=='different variances':
            VAR=False
        elif variance=='equal variance':
            VAR=True
        else:
            VAR=False
        try:
            if self.ui.radioButton_Student.isChecked():
                F,P=stats.ttest_ind(DF1.variables,DF2.variables,equal_var=VAR)
            if self.ui.radioButton_Runksum.isChecked():
                F,P=stats.ranksums(DF1.variables,DF2.variables)
        except: 
            QMessageBox.about(self, "warning", "The datasets must contain only numerical values")
            return
        self.ui.mean_1.clear()
        self.ui.mean_1.setText(str(round(DF1.variables.mean(),8)))
        self.ui.mean_2.clear()
        self.ui.mean_2.setText(str(round(DF2.variables.mean(),8)))
        self.ui.std_1.clear()
        self.ui.std_1.setText(str(round(DF1.variables.std(),8)))
        self.ui.std_2.clear()
        self.ui.std_2.setText(str(round(DF2.variables.std(),8)))
        self.ui.tvalue.clear()
        self.ui.tvalue.setText(str(F))
        self.ui.pvalue.clear()
        self.ui.pvalue.setText(str(P))
        
    def _hist(self):
        try:
            # plt.close('all')
            val= StringIO(str(self.ui.plainTextEdit_observations.toPlainText()))
            DF=pandas.read_csv(val,delim_whitespace=True,names=['observations'])
            try:
                bins=int(self.ui.histbins.text())
            except:
                bins=10
            hist=DF.hist(bins=bins)
            plt.savefig('results/hist.png',dpi=200, format='png', transparent=True, bbox_inches='tight')
            plt.savefig('results/hist.eps',dpi=200, format='eps', transparent=True, bbox_inches='tight')
            print(hist)
            plt.show()
        except:
            QMessageBox.about(self, "warning", "Check obsevations. \nThe datasets must contain only numerical values")
            return
    def _QQplot(self):
        try:
            plt.close('all')
            line=str(self.ui.comboBox_qqline.currentText())
            val= StringIO(str(self.ui.plainTextEdit_observations.toPlainText()))
            DF=pandas.read_csv(val,delim_whitespace=True,names=['observations'])
            try:
                import statsmodels.api as sm
                sm.qqplot(DF.observations,fit=True,line=line)
            except:
                from scipy.stats import probplot
                QQ = probplot(DF.observations, dist="norm")
                plt.scatter(QQ[0][0],QQ[0][1])
            plt.savefig('results/qqplot.png',dpi=200, format='png', transparent=True, bbox_inches='tight')
            plt.savefig('results/qqplot.eps',dpi=200, format='eps', transparent=True, bbox_inches='tight')
            plt.show()
        except:
            QMessageBox.about(self, "warning", "Check obsevations. \nThe datasets must contain only numerical values")
            return
    def _paste_observations(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_observations.clear()
        self.ui.plainTextEdit_observations.insertPlainText(data)
    def _paste_observations_2(self):
        data = pyperclip.paste()
        self.ui.plainTextEdit_target.clear()
        self.ui.plainTextEdit_target.insertPlainText(data)
    def _transpose(self):
        val= StringIO(str(self.ui.plainTextEdit_target.toPlainText()))
        DF=pandas.read_csv(val,delim_whitespace=True,header=None)
        data=swrm.nice_table(DF.T,header=False)
        self.ui.plainTextEdit_target.clear()
        self.ui.plainTextEdit_target.insertPlainText(data)
        
    def _combine_monosaccharides(self):
        # folder=str(self.ui.lineEdit_folder.text())
        header= self.ui.checkBox_header.isChecked()
        # print(header)
        try:
            from pyteomics import mass
        except ImportError:
            print("This program requires `pyteomics`, install with `pip install pyteomics`")
            raise
        def combine_formulas(a,b):
            '''Function takes two chemical formulas and combines them elementwise: 'C2H4'+'HCl'='C2H5Cl'. 
            Returns string'''
            result={}
            S=''
            A=mass.Composition(formula=a)
            B=mass.Composition(formula=b)
            keys=set(list(A.keys())+list(B.keys()))
            for key in keys:
                if key in A:
                    aa=A[key]
                else:
                    aa=0
                if key in B:
                    bb=B[key]
                else:
                    bb=0
                    
                result[key]=aa+bb
                S=S+key+str(result[key])
            return S
        def sum_formulas(lst):
            '''Takes list of chemical formulas.
            Returns combined formula (as a string).'''
            A='H0'
            for f in range(len(lst)):
                A=combine_formulas(A,lst[f])
            return A
        try:
            try:
                targetmasslow=float(self.ui.targetmasslow.text())
            except:
                targetmasslow=0
            try:
                targetmasshigh=float(self.ui.targetmasshigh.text())
            except:
                targetmasshigh=10000000
                
                
            aglycone=str(self.ui.aglycone.text()).strip()
            
            fragment_1=str(self.ui.fragment_1.text()).strip()
            formula_1=[str(self.ui.form_1.text()).strip()]
            min1=int(self.ui.min1.text())
            max1=int(self.ui.max1.text())
            
            fragment_2=str(self.ui.fragment_2.text()).strip()
            formula_2=[str(self.ui.form_2.text()).strip()]
            min2=int(self.ui.min2.text())
            max2=int(self.ui.max2.text())
            
            fragment_3=str(self.ui.fragment_3.text()).strip()
            formula_3=[str(self.ui.form_3.text()).strip()]
            min3=int(self.ui.min3.text())
            max3=int(self.ui.max3.text())
            
            fragment_4=str(self.ui.fragment_4.text()).strip()
            formula_4=[str(self.ui.form_4.text()).strip()]
            min4=int(self.ui.min4.text())
            max4=int(self.ui.max4.text())
            
            fragment_5=str(self.ui.fragment_5.text()).strip()
            formula_5=[str(self.ui.form_5.text()).strip()]
            min5=int(self.ui.min5.text())
            max5=int(self.ui.max5.text())
            
            fragment_6=str(self.ui.fragment_6.text()).strip()
            formula_6=[str(self.ui.form_6.text()).strip()]
            min6=int(self.ui.min6.text())
            max6=int(self.ui.max6.text())
            
            fragment_7=str(self.ui.fragment_7.text()).strip()
            formula_7=[str(self.ui.form_7.text()).strip()]
            min7=int(self.ui.min7.text())
            max7=int(self.ui.max7.text())
            
            fragment_8=str(self.ui.fragment_8.text()).strip()
            formula_8=[str(self.ui.form_8.text()).strip()]
            min8=int(self.ui.min8.text())
            max8=int(self.ui.max8.text())
            
            fragment_9=str(self.ui.fragment_9.text()).strip()
            formula_9=[str(self.ui.form_9.text()).strip()]
            min9=int(self.ui.min9.text())
            max9=int(self.ui.max9.text())
            
            fragment_10=str(self.ui.fragment_10.text()).strip()
            formula_10=[str(self.ui.form_10.text()).strip()]
            min10=int(self.ui.min10.text())
            max10=int(self.ui.max10.text())
            

            
            G=[]
            # H='H0'
            # CMP=''
            composition=[]
            n=1
            for f1 in range(min1,max1+1):
                print('calculating loop #',n)
                n+=1
                V1=sum_formulas(formula_1*f1)
                if not f1==0:
                    Q1='{}:{},'.format(fragment_1,f1)
                else:
                    Q1=''
                for f2 in range(min2,max2+1):
                    V2=sum_formulas(formula_2*f2)
                    V1_V2=sum_formulas([V1,V2])
                    if not f2==0:
                        Q1_Q2=Q1+'{}:{},'.format(fragment_2,f2)
                    else:
                        Q1_Q2=Q1
                    for f3 in range(min3,max3+1):
                        V3=sum_formulas(formula_3*f3)
                        V1_V2_V3=sum_formulas([V1_V2,V3])
                        if not f3==0:
                            Q1_Q2_Q3=Q1_Q2+'{}:{},'.format(fragment_3,f3)
                        else:
                            Q1_Q2_Q3=Q1_Q2
                        for f4 in range(min4,max4+1):
                            V4=sum_formulas(formula_4*f4)
                            V1_V2_V3_V4=sum_formulas([V1_V2_V3,V4])
                            if not f4==0:
                                Q1_Q2_Q3_Q4=Q1_Q2_Q3+'{}:{},'.format(fragment_4,f4)
                            else:
                                Q1_Q2_Q3_Q4=Q1_Q2_Q3
                            for f5 in range(min5,max5+1):
                                V5=sum_formulas(formula_5*f5)
                                V1_V2_V3_V4_V5=sum_formulas([V1_V2_V3_V4,V5])
                                if not f5==0:
                                    Q1_Q2_Q3_Q4_Q5=Q1_Q2_Q3_Q4+'{}:{},'.format(fragment_5,f5)
                                else:
                                    Q1_Q2_Q3_Q4_Q5=Q1_Q2_Q3_Q4
                                for f6 in range(min6,max6+1):
                                    V6=sum_formulas(formula_6*f6)
                                    V1_V2_V3_V4_V5_V6=sum_formulas([V1_V2_V3_V4_V5,V6])
                                    if not f6==0:
                                        Q1_Q2_Q3_Q4_Q5_Q6=Q1_Q2_Q3_Q4_Q5+'{}:{},'.format(fragment_6,f6)
                                    else:
                                        Q1_Q2_Q3_Q4_Q5_Q6=Q1_Q2_Q3_Q4_Q5
                                    for f7 in range(min7,max7+1):
                                        V7=sum_formulas(formula_7*f7)
                                        V1_V2_V3_V4_V5_V6_V7=sum_formulas([V1_V2_V3_V4_V5_V6,V7])
                                        if not f7==0:
                                            Q1_Q2_Q3_Q4_Q5_Q6_Q7=Q1_Q2_Q3_Q4_Q5_Q6+'{}:{},'.format(fragment_7,f7)
                                        else:
                                            Q1_Q2_Q3_Q4_Q5_Q6_Q7=Q1_Q2_Q3_Q4_Q5_Q6
                                        for f8 in range(min8,max8+1):
                                            V8=sum_formulas(formula_8*f8)
                                            V1_V2_V3_V4_V5_V6_V7_V8=sum_formulas([V1_V2_V3_V4_V5_V6_V7,V8])
                                            if not f8==0:
                                                Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8=Q1_Q2_Q3_Q4_Q5_Q6_Q7+'{}:{},'.format(fragment_8,f8)
                                            else:
                                                Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8=Q1_Q2_Q3_Q4_Q5_Q6_Q7
                                                
                                            for f9 in range(min9,max9+1):
                                                V9=sum_formulas(formula_9*f9)
                                                V1_V2_V3_V4_V5_V6_V7_V8_V9=sum_formulas([V1_V2_V3_V4_V5_V6_V7_V8,V9])
                                                if not f9==0:
                                                    Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9=Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8+'{}:{},'.format(fragment_9,f9)
                                                else:
                                                    Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9=Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8
                                                for f10 in range(min10,max10+1):
                                                    V10=sum_formulas(formula_10*f10)
                                                    V1_V2_V3_V4_V5_V6_V7_V8_V9_V10=sum_formulas([V1_V2_V3_V4_V5_V6_V7_V8_V9,V10])
                                                    if not f10==0:
                                                        Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9_Q10=Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9+'{}:{},'.format(fragment_10,f10)
                                                    else:
                                                        Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9_Q10=Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9

                                                    V1_V2_V3_V4_V5_V6_V7_V8_V9_V10_A=sum_formulas([V1_V2_V3_V4_V5_V6_V7_V8_V9_V10,aglycone])  
                                                    Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9_Q10_A=Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9_Q10+aglycone
                                                    G.append(V1_V2_V3_V4_V5_V6_V7_V8_V9_V10_A)
                                                    composition.append(Q1_Q2_Q3_Q4_Q5_Q6_Q7_Q8_Q9_Q10_A)
            exact=[]
            # aver=[]
            for g in G:
                # C=mass.Composition(formula=f)
                monoisotopic=mass.calculate_mass(formula=g)
                exact.append(monoisotopic)
                a=mass.most_probable_isotopic_composition(g)
                # mostprob=mass.calculate_mass(composition=a[0])
                # aver.append(mostprob)
            # print(G,exact,aver)
            DF=pandas.DataFrame({'formula':G})
            DF['monoisotopic']=exact
            # DF['most_probable']=aver
            DF['composition']=composition
            DF.sort_values(by=['monoisotopic'],inplace=True)
            DF=DF.where(DF.monoisotopic>targetmasslow)
            DF.dropna(inplace=True)
            DF=DF.where(DF.monoisotopic<targetmasshigh)
            DF.dropna(inplace=True)
            res=DF.to_string(index=False,header=header)
            # with open(folder+'/G','wb') as q:
                # cPickle.dump(DF,q)

            self.ui.plainTextEdit_glycans_S_7.clear()
            self.ui.plainTextEdit_glycans_S_7.insertPlainText(res)
            global formula_iterator
            DF.to_csv('results/oligos_{}.csv'.format(formula_iterator), index=False)
            formula_iterator+=1
        except Exception as e:
            print(e)
            QMessageBox.about(self, "error", str(e))

    def _simulate_positive_fragments(self):
        try:
            line=str(self.ui.plainTextEdit_glycans_S_7.toPlainText())
            aglycone=str(self.ui.aglycone.text()).strip()
            emass=0.000548579909
            ObservedFragments=str(self.ui.plainTextEdit_observed_fragments.toPlainText()).split(',')
            ObservedFragments=[float(i) for i in ObservedFragments]
            delta=float(self.ui.delta.text())

            from itertools import combinations
            FormDict={'HEXOSE':'C6H10O5','HEXNAc':'C8H13NO5','Neu5Ac':'C11H17NO8'}
            def line_comprehension(line):
                line.split()[2].split(',')[0].split(':')
                sample_list=[]
                #print(line.split()[2].split(','))
                for f in line.split()[2].split(','):
                    try:
                        #print(f.split(':')[0],f.split(':')[1])
                        #print(int(f.split(':')[1]))
                        for q in range(int(f.split(':')[1])):
                            sample_list.append(f.split(':')[0])
                    except:
                        pass
                return sample_list
            sample_list=line_comprehension(line)
            #print(sample_list)
            def substract_formulas(a,b):
                from pyteomics import mass

                '''Function takes two chemical formulas and substracts them elementwise: 'C2H4'-'H4C'='C'. 
                Returns string'''
                result={}
                S=''
                A=mass.Composition(formula=a)
                B=mass.Composition(formula=b)
                keys=set(list(A.keys())+list(B.keys()))
                for key in keys:
                    if key in A:
                        aa=A[key]
                    else:
                        aa=0
                    if key in B:
                        bb=B[key]
                    else:
                        bb=0
                        
                    result[key]=aa-bb
                    S=S+key+str(result[key])
                return S     
            def makefragformdict(sample_list,additive,subtractive=''):
                from itertools import combinations
                list_combinations = []

                for n in range(len(sample_list)+1):
                    list_combinations += list(combinations(sample_list, n))
                    #print(n,list(combinations(sample_list, n)))
                list_combinations=set(list_combinations)
                formdict={}
                #print(list(combinations_with_replacement(sample_list, 2)))
                from pyteomics import mass

                for f in list_combinations:
                    L=additive
                    for q in f:
                       L=L+FormDict[q]
                    L=substract_formulas(L,subtractive)
                    monoisotopic=mass.calculate_mass(formula=L)

                    formdict[f]=[monoisotopic,L]
                    #print('H'.join(map(str, f)))
                return formdict
            def FragID(fragdf,foundfragments,fragtype,delta): 
                Dict={}
                for f in foundfragments:
                    try:
                        frag=(fragdf[(f-delta<fragdf.mass) & (fragdf.mass<f+delta)])
                        L=[frag.mass.values[0]]
                        d=float(frag.mass.values[0])-float(f)
                        L.append(d)
                        L.append(frag.composition.values[0])
                        L.append(frag.formula.values[0])
                        L.append(fragtype)  
                        Dict[f]=L
                    except:
                        pass
                return Dict
            DFlist=[]
            
            delta=0.1

            FragParams={'B':['H',''],'B+Na':['Na',''],'B+K':['K',''],'B-W':['H','H2O'],'B-W+Na':['Na','H2O'],'B-W+K':['K','H2O'],'C':['H3O',''],'C+Na':['H3ONa',''],'C+K':['H3OK',''],'C-W':['H3O','H2O'],'C-W+Na':['H3ONa','H2O'],'C-W+K':['H3OK','H2O'],'Y':[aglycone+'H',''],'Y+Na':[aglycone+'Na',''],'Y+K':[aglycone+'K',''],'Y-W':[aglycone+'H','H2O'],'Y+Na-CO2':[aglycone+'Na','CO2'],'Y+K-CO2':[aglycone+'K','CO2'],'Y-W+Na':[aglycone+'Na','H2O'],'Y-W+K':[aglycone+'K','H2O'],'Y+2Na':[aglycone+'Na2','H'],'Y+2K':[aglycone+'K2','H'],'Y+Na+K':['HONaK',''],'A24':['H3O','C6H11NO4'],'A24+Na':['H2ONa','C6H11NO4'],'A24+K':['H2OK','C6H11NO4'],'A02':['H3O','C4H7NO2'],'A02+Na':['H2ONa','C4H7NO2'],'A02+K':['H2OK','C4H7NO2']}

            
            DFlist=[]
            for f in FragParams.keys():
                try:
                    
                    formdict=makefragformdict(sample_list,FragParams[f][0],FragParams[f][1])
                    #print(formdict)
                    DF=pandas.DataFrame.from_dict(formdict, orient='index',columns=['mass','formula']).reset_index().rename(columns={"index": "composition"})
                    #print(DF.head(1))
                    #print(FragID(DF,ObservedFragments,f,delta))
                    df=pandas.DataFrame.from_dict(FragID(DF,ObservedFragments,f,delta), orient='index',columns=['calculated','delta','composition','formula', 'fragment_type']).reset_index().rename(columns={"index": "observed"})
                    DFlist.append(df)

                except:
                    pass

            Res=pandas.concat(DFlist, axis=0, ignore_index=False).sort_values(by=['calculated','delta'])
            COMP=[]
            for f in Res.composition.values:
                COMP.append('HEXOSE:{} HEXNAc:{} Neu5Ac:{}'.format(f.count('HEXOSE'),f.count('HEXNAc'),f.count('Neu5Ac')))
            Res['composition']=COMP
            Res.eval("delta = delta -"+ str(emass), inplace=True)
            Res.eval("calculated = calculated -"+ str(emass), inplace=True)
            print(Res)
            self.ui.plainTextEdit_glycans_S_7.clear()
            self.ui.plainTextEdit_glycans_S_7.insertPlainText(Res.to_string(index=False))

            fname=''
            for f in line.split()[2].split(','):
                try:
                    fname=fname+f.split(':')[0]+f.split(':')[1]+'_'
                except:
                    pass
            fname='results/'+fname[:-1]+'.csv'
            Res.to_csv(fname,index=False)
        except Exception as e:
            print(e)
            QMessageBox.about(self, "error", str(e))
    ##############################################################################
if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle(QStyleFactory.create("windows"))
    main = Main()
    main.show()
    sys.exit(app.exec_())
