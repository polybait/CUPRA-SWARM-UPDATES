import pandas
import numpy as np
from itertools import combinations_with_replacement


def enumerate_DETACHED(df,N): 
    """ function input id df with 2 columns: ligand 'label' and 'mass', and max number ligands in a combination
    return: DataFrame with list of combined labels and masses 
    """
    CC=[]
    for n in range(N):
        C=list(combinations_with_replacement(df.label, n+1))
        CC=CC+C
    # print(CC)
    
    lb=[];ms=[]
    for n in CC:
        s=''.join(n)
        mass=0
        for f in n:
            mass=mass+df.mass[df.label==f].values[0]
        lb.append(s)
        ms.append(mass)
            # print(s,mass)
    dict={'label':lb,'mass':ms}
    PN=pandas.DataFrame.from_dict(dict)
    return PN

def addDetached(dfP,dfD):
    """ function input: 2 DataFrames (P and PL) P contains 4 columns (label, mass, minimum(charge),maximum(charge))
    PL contains 2 columns(ligand 'label' and 'mass')
    return: DataFrame with list of combined labels and masses, min and max charges
    """
    
    lb=[];ms=[];mn=[];mx=[]
    for p in dfP.label:
        for k in dfD.label:
            # print(p,k)
            m=dfP.mass[dfP.label==p].values[0]
            lb.append(p+k)
            ms.append(m+dfD.mass[dfD.label==k].values[0])
            mn.append(dfP.minimum[dfP.label==p].values[0])
            mx.append(dfP.maximum[dfP.label==p].values[0])
    dict={'label':lb,'mass':ms,'minimum':mn,'maximum':mx}
    df=pandas.DataFrame.from_dict(dict)
    return df

def apply_charge_distribution(df,sign,decimals):
    """ function input: DataFrame contains 4 columns (label, mass, minimum(charge),maximum(charge))
    return: DataFrame with final list of combined masses and labels in format P_8+
    """
    lb=[];ms=[]
    for p in df.label:
        mn=df.minimum[df.label==p].values[0]
        mx=df.maximum[df.label==p].values[0]
        if mn==0 and mx==0:
            lb.append(p+'_'+'0'+sign)
            ms.append(round(((df[df.label==p].mass.values[0])),decimals))
        else:
            for m in range(mn,mx+1):
                lb.append(p+'_'+str(m)+sign)
                ms.append(round(((df[df.label==p].mass.values[0]+eval(sign+str(m)))/m),decimals))
    dict={'mass':ms,'label':lb}
    final=pandas.DataFrame.from_dict(dict)
    # final.sort_values(by=['mass'], inplace=True)
    final=final[['mass','label']]
    return final
    

#################################################################
def test():
    sign='-'
    decimals=2
    L=pandas.DataFrame()
    P=pandas.DataFrame()
    P['label']=['P1','P2']
    P['mass']=[15000,20000]
    P['minimum']=[7,9]
    P['maximum']=[9,11]
    L['label']=['L1','L2','L3']
    L['mass']=[110.0,220.0,330]
    Nnum=3
    PL=enumerate_DETACHED(L,Nnum) #enumerate detached adducts
    print(PL)
    ADD=addDetached(P,PL)
    print(ADD)
    FN=apply_charge_distribution(ADD,sign,decimals)
    print(FN)
if __name__ == '__main__':
    test()

