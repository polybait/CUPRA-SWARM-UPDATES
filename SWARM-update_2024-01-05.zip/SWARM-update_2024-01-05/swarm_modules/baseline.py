import pandas
import numpy as np
# from .decorators import timer
# @timer
def baseline(y, lam, p, niter=10):
    import numpy as np
    """this function is taken from https://stackoverflow.com/questions/29156532/python-baseline-correction-libraryhttps://stackoverflow.com/questions/29156532/python-baseline-correction-library https://zanran_storage.s3.amazonaws.com/www.science.uva.nl/ContentPages/443199618.pdf
    Input: time series y, return time series z: 
     """
    from scipy.sparse import diags,spdiags
    from scipy.sparse.linalg import spsolve
    L = len(y)
    D = diags([1,-2,1],[0,-1,-2], shape=(L,L-2))
    w = np.ones(L)
    for i in range(niter):
        W = spdiags(w, 0, L, L)
        Z = W + lam * D.dot(D.transpose())
        z = spsolve(Z, w*y)
        w = p * (y > z) + (1-p) * (y < z)
    return z

def test():
    import matplotlib.pyplot as plt
    df=pandas.read_table('test_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    x=df.Mass.values
    y=df.Intensity.values
    z=baseline(y, 10000, 0.01, 10)
    plt.plot(x,y)
    plt.plot(x,z)
    plt.show()
if __name__ == '__main__':
    test()
