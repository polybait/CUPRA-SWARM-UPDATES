import pandas
import numpy as np
try:
    from StringIO import StringIO # for Python 2.7
except ImportError:
    from io import StringIO # for Python 3.x
from annotate import annotate,PeakID
def swarm(df, LB, accuracy,refmz,window):
    """ 
    input: df contains 2 columns Mass and Intensisty, 
    LB is str containing 2 columns Mass ans Label
    
    """
    lbl=pandas.read_table(StringIO(LB),delim_whitespace=True,names=['Mass', 'Label'])
    df.columns=['Mass', 'Intensity']
    s=annotate(df.values,lbl,accuracy)
    Annt=pandas.read_table(StringIO(s),names=['Mass', 'Intensity','Delta','Label'])
    lb=[]
    for f in Annt.Label.tolist():
        f=f.split('_')
        l=f[0]
        lb.append(l)
    Annt['Label']=lb
    # print(Annt)
    Spectrum=df
    Annt=Annt.sort_values(by='Mass', ascending=True)
    # A=Annt.drop(['Label','Delta'], axis=1)
    refmz,x,y=PeakID(Spectrum,refmz,accuracy) # update refmz
    print(refmz)
    # MZ,x,y=PeakID(A,refmz,accuracy)
    # chars=set(Annt.Charge.tolist())
    # refcharge=int(Annt[Annt.Mass==MZ].Charge.values[0])
    ref=(Spectrum[(refmz<=Spectrum.Mass) & (Spectrum.Mass<=refmz+window)]) #cut a fragment containing FF linker peak
    print(ref)
    PEAKS=Annt.Mass[Annt.Charge==char].tolist()
    ref1=pandas.DataFrame()
    if not char=='0':
        ref1['Mass']=ref.Mass*refcharge/int(char)
        ref1['Intensity']=ref.Intensity
        ref1=sm.resample_spectrum(ref1,ref['Mass'].min(),ref['Mass'].min(),rate)
        W=window*refcharge/int(char)
    else:
        ref1['Mass']=ref.Mass
        ref1['Intensity']=ref.Intensity
        W=window
    Spectrum=sm.adducts_removal(Spectrum,PEAKS,ref1,ref1['Mass'].min(),ref1['Intensity'].max(),accuracy,W,each,lamE,pE,iter)
        
    df['Final']=Spectrum.Intensity
                        
def test():
    import matplotlib.pyplot as plt
    df=pandas.read_table('test_swarm.txt', index_col=False, header=None, names=['Mass','Intensity'])
    LB="""2042.250	P_8+	
    2082.0835	PL00_8+
    2084.4744	PL0_8+
    2103.250	PL1_8+	
    2108.375	PL2_8+	
    2117.125	PL3_8+	
    2121.375	PL4_8+	
    2124.125	PL5_8+	
    2128.625	PL6_8+	
    2130.625	PL7_8+	
    2137.375	PL8_8+	
    2142.500	PL9_8+	
    2147.625	PL10_8+	
    2154.000	PL11_8+	
    2167.000	PL12_8+	
    2169.125	PL13_8+	
    2174.250	PL14_8+	
    2176.375	PL15_8+	
    2185.375	PL16_8+	
    2203.375	PL17_8+	
    2212.875	PL18_8+	
    """
    swarm(df, LB, accuracy=1,refmz=2042.25,window=35)
    x=df.Mass.values
    y=df.Intensity.values
    z=baseline(y, 10000, 0.01, 10)
    plt.plot(x,y)
    plt.plot(x,z)
    plt.show()
if __name__ == '__main__':
    test()
