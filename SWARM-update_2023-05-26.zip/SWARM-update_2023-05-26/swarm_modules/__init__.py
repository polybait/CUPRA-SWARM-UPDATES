"""
copiright 2018 Pavel Kitov pkitov@ualberta.ca
"""
__version__ = '0.0.0'
# from .adducts_removal import adducts_removal
from .adducts_removal2 import adducts_removal2
from .baseline import baseline
from .center_of_gravity import center_of_gravity
from .detect_peaks import detect_peaks 
from .enumerate import enumerate_DETACHED,addDetached,apply_charge_distribution 
from .nice_table import nice_table
from .annotate import PeakID, annotate
from .resample_spectrum import resample_spectrum
# from .clipboard import copy_clip,paste_clip
from .difference import difference
from .decorators import ignore_warnings,exception,timer
from .fit_Gauss import gauss,sumgauss,lorentzian,sumlorentz

