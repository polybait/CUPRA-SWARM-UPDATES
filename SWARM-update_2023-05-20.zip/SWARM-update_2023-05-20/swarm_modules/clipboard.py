import win32clipboard

def paste_clip(): 
    """get clipboard data
        return: string
    """
    try: 
        win32clipboard.OpenClipboard()
        data = win32clipboard.GetClipboardData()
        win32clipboard.CloseClipboard()
        return data
    except:
        print("Could not paste clipboard data.")
        
def copy_clip(s): 
    """copy content to clipboard
        return: nothing
    """
    try:
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(s)
        win32clipboard.CloseClipboard()
    except:
        print("Could not copy clipboard data.") 
          
def test():
    s="test works."
    print('Try if clipboard ',s)
    copy_clip(s)
    S=paste_clip()
    print('Yes, clipboard ',S)
if __name__ == '__main__':
    test()