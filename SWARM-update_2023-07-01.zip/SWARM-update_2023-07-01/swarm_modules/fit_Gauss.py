import numpy as np
import pandas
from scipy.optimize import curve_fit

# Define model function to be used to fit to the data:
def gauss(x, *p):
    mean, amplitude,  sigma = p
    return amplitude*np.exp(-(x-mean)**2/(2.*sigma**2))
def bigauss(x, *p):
    mean, amplitude,  sigma, scale = p
    df=pandas.DataFrame()
    df['x']=x
    sigma1=sigma*scale
    df['y1']=amplitude*np.exp(-(df.x[df.x<=mean]-mean)**2/(2.*sigma**2))
    df['y2']=amplitude*np.exp(-(df.x[df.x>mean]-mean)**2/(2.*sigma1**2))
    df = df.fillna(0)
    df['y']=df.y1+df.y2
    return df.y
def lorentzian(x, *p):
    mean, amplitude,  sigma = p
    return amplitude*sigma**2/(sigma**2+(x-mean)**2)
    # return amplitude*sigma**2/np.pi/(sigma**2+(x-mean)**2)
def bilorentzian(x, *p):
    mean, amplitude,  sigma, scale = p
    df=pandas.DataFrame()
    df['x']=x
    sigma1=sigma*scale
    df['y1']=amplitude*sigma**2/(sigma**2+(df.x[df.x<=mean]-mean)**2)
    df['y2']=amplitude*sigma1**2/(sigma1**2+(df.x[df.x>mean]-mean)**2)
    df = df.fillna(0)
    df['y']=df.y1+df.y2
    return df.y
def GL(x, *p):
    mean, amplitude,  sigma, scale = p
    df=pandas.DataFrame()
    df['x']=x
    sigma1=sigma*scale
    df['y1']=amplitude*np.exp(-(df.x[df.x<=mean]-mean)**2/(2.*sigma**2))
    df['y2']=amplitude*sigma1**2/(sigma1**2+(df.x[df.x>mean]-mean)**2)
    df = df.fillna(0)
    df['y']=df.y1+df.y2
    return df.y
def LG(x, *p):
    mean, amplitude,  sigma, scale = p
    df=pandas.DataFrame()
    df['x']=x
    sigma1=sigma*scale
    df['y1']=amplitude*sigma**2/(sigma**2+(df.x[df.x<=mean]-mean)**2)
    df['y2']=amplitude*np.exp(-(df.x[df.x>mean]-mean)**2/(2.*sigma1**2))
    df = df.fillna(0)
    df['y']=df.y1+df.y2
    return df.y

def sumgauss(x,*PP):
    df=pandas.DataFrame(columns=['x','y'])
    df.x=x
    df = df.fillna(0)
    P=[]
    for p in PP:
        P.append(p)
    for f in range(len(P)//3):
        df.y+=gauss(x,*P[3*(f+1)-3:3*(f+1)])
    return df.y
def sumbigauss(x,*PP):
    df=pandas.DataFrame(columns=['x','y'])
    df.x=x
    df = df.fillna(0)
    P=[]
    for p in PP:
        P.append(p)
    for f in range(len(P)//3):
        df.y+=bigauss(x,*P[3*(f+1)-3:3*(f+1)])
    return df.y
def sumlorentz(x,*PP):
    df=pandas.DataFrame(columns=['x','y'])
    df.x=x
    df = df.fillna(0)
    P=[]
    for p in PP:
        P.append(p)
    for f in range(len(P)//3):
        df.y+=lorentzian(x,*P[3*(f+1)-3:3*(f+1)])
    return df.y

if __name__ == '__main__':
    import matplotlib.pyplot as plt
    x=np.linspace(-50, 100, 20000)
    P=(4., 4., 2.,14., 4., 3.,25., 5., 5.,55., 0.4, 5.)
    y= sumgauss(x,*P)
    plt.plot(x, y, 'o',label='sum')

    peaks=[4,10,23,50]
    sigma,amplitude=1,1
    p0=[]
    for f in peaks:
        p0.append(f)
        p0.append(amplitude)
        p0.append(sigma)

    coeff, var_matrix = curve_fit(sumgauss, x, y, p0=p0)
    # print(coeff)
    result=[]
    for f in range(len(coeff)//3):
        result.append(coeff[3*f])
    # print(result)
    yfit=sumgauss(x,*coeff)
    plt.plot(x, yfit, '--',label='sum')
    plt.show()