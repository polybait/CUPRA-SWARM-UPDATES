import pandas
import numpy as np
"""If performing test comment the following imports
""" 
from .resample_spectrum import resample_spectrum
from .baseline import baseline
from .annotate import PeakID
from .decorators import timer
@timer
def adducts_removal2(spectrum,PEAKS,refmz,accuracy,window,each,lamE,pE,iter):
    """ This function performs SWARM cleaning of spectrum given in pandas.DataFrame or np.ndarray 'df'
    df must contain 2 columns 'Mass' and 'Intensity' (not nesessary these titles); 
    ref is a DataFrame and must contain 2 columns 'Mass' and 'Intensity' (not nesessary these titles); 
    PEAKS is a list of m/z (can be as strings), refmz and window must be float
    return: new DataFrame with SWARM-ed spectrum
    USAGE: ref distribution must be not rescaled according to charge state prior to imput
    
    """
    if isinstance(spectrum, np.ndarray):
        spectrum=pandas.DataFrame(spectrum)
    spectrum.columns = ['Mass','Intensity']
    # spectrum.Intensity=spectrum.Intensity-spectrum.Intensity.min()
    refmz, refint,d = PeakID(spectrum, refmz, accuracy)  # update refmz
    template = (spectrum[(refmz <= spectrum.Mass) & (spectrum.Mass <= refmz+window)])
    template.Intensity=template.Intensity-template.Intensity.min()
    WIND=pandas.DataFrame()
    n=0
    for peak in PEAKS:
        n+=1
        df=spectrum.copy()
        ref=template.copy()
        peakmz,peakint,d = PeakID(df,float(peak),accuracy)# update peak
        F0=peakint/refint
        
        try:
            shift1=df[df.Mass>=peakmz].index[0]-ref.index[0]+1
        except:
            # QMessageBox.about(self, "warning","Operation failed. Try to adjust spectrum range") 
            print("shift should have positive value: tmpl-ref=",tmp1.index[0]-ref.index[0])
        df['tmp']=ref.Intensity 
        df.tmp=(df.tmp.shift(shift1)) #template positioned above the current peak
        
        df['tmp']=(df.tmp)*F0 # scaled template
        df['D']=df.Intensity-df.tmp
        # df.tmp=df.tmp+df.D
        D=(df.Intensity-df.tmp).min()
        # df.tmp=df.tmp+D

        # print('beforeMIN.D',df.Intensity.min(),D)
        if not D<=0:
            df['tmp'].fillna(0, inplace=True)
            df['Intensity']=df.Intensity-df.tmp
            
        else:
            H1=df['tmp'].max()
            H2=df['tmp'].max()+D
            # print("H2/H1",H2/H1)
            # df['tmp']=df['tmp']*H2/H1
            # df['tmp']=df['tmp']-df['tmp'].min()
            df['tmp'].fillna(0, inplace=True)
            # print(df['tmp'])
            df['Intensity']=df.Intensity-df.tmp
        # COR=df['Intensity'].min()
        spectrum['Intensity']=df.Intensity
        # spectrum[str(n)]=df.tmp

        # print('MIN',df.Intensity.min())
        if each==1:
            bsl=baseline(df.Intensity.values, lam=lamE, p=pE, niter=iter)
            spectrum.Intensity=df.Intensity-bsl
        WIND[str(n)]=df.tmp
        # print(TMPL)
        
    return spectrum,WIND

def test():
    # refmz=2041.250
    # window=35
    # accuracy=1
    # each=1
    refmz=29581.5 #test for unidec
    window=210#test for unidec
    accuracy=1#test for unidec
    each=0
    # df=pandas.read_csv('test_swarm_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    df=pandas.read_csv('test_unidec_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    df=resample_spectrum(df,df['Mass'].min(),df['Mass'].max(),25)
    df['Intensity']=sg(df['Intensity'].values,41,4)
    bsl=baseline(df.Intensity.values, lam=100000000, p=0.001, niter=10)
    df.Intensity=df.Intensity-bsl
    MZ,INT,d=PeakID(df,float(refmz),accuracy)
    ref=(df[(MZ<=df.Mass) & (df.Mass<=MZ+window)]) #cut a fragment containing FF linker peak
    # PEAKS=pandas.read_csv('test_peaks.txt', index_col=False, header=None, names=['Mass','Intensity','a','b']).Mass.tolist()
    PEAKS=pandas.read_csv('test_unidec_peaks.txt', index_col=False, header=None, names=['Mass','Intensity','a','b']).Mass.tolist()
    # print(ref)
    # print(df)
    #test for function adducts_removal 
    Spectrum=adducts_removal2(df,PEAKS,MZ,accuracy=accuracy,window=window,each=each,lamE=1000000,pE=0.01,iter=10) 
    # window is not scaled since ref has the same charge as the peaks to be cleaned 
    # print(Spectrum) 
    x=Spectrum.Mass.values
    y=Spectrum.Intensity.values
    plt.plot(x,y,color='b')
    plt.show()
if __name__ == '__main__':
    from resample_spectrum import resample_spectrum
    from baseline import baseline
    from annotate import PeakID
    from scipy.signal import savgol_filter as sg
    import matplotlib.pyplot as plt

    test()

