import pandas
import numpy as np
def PeakID(Spectrum,C,delta): 
    """ Function finds peak in dataframe Spectrum closest to C within delta distance
    Input: Spectrum is "np.array" or "pandas.DataFrame" containing 2 columns (m/z and intensity), C is m/z to be found,
    delta is max distance from C.
    Return: 3 values for the found peak: Mass, Intensity and actual distance from C (rounded to 2 decimal places) 
    """
    # print('Spectrum,C,delta',Spectrum,C,delta)
    if isinstance(Spectrum, np.ndarray):
        Spectrum=pandas.DataFrame(Spectrum)
    Spectrum.columns = ['Mass','Intensity']
    # print(Spectrum)
    try:
        Spectrum=(Spectrum[(C-delta<Spectrum.Mass) & (Spectrum.Mass<C+delta)])
        # print('Spectrum,C,delta',Spectrum,C,delta)
        Spectrum=Spectrum[Spectrum.Intensity==Spectrum.Intensity.max()] 
        return Spectrum.Mass.values[0], Spectrum.Intensity.values[0], round(Spectrum.Mass.values[0]-C,2)
    except:
        print('error in function PeakID. peak at {} not found'.format(str(C)))
        return 0.0,0.0,0.0
def annotate(data,lbl,delta): 
    """ this function takes te list of labels and find actual m/z values in the spectrum 
    inputs: data is "np.array" or "pandas.DataFrame" or "pandas.Series", 'lbl' is pandas.DataFrame, 'delta' is float 
    return: string of m/z
    """
    if isinstance(data, np.ndarray):
        peaks=pandas.DataFrame(data)
    if isinstance(data, pandas.DataFrame):
        peaks=data
    peaks.columns = ['Mass','Intensity']
    s=''
    for f in range(len(lbl)):
        mass=lbl.Mass.tolist()[f]
        name=lbl.Label.tolist()[f]
        MZ,INT,d=PeakID(peaks,mass,delta)

        if MZ>1:
            s=s+str(round(MZ,2))+'\t'+str(round(INT,2))+'\t'+str(d)+'\t'+name+'\n'
    return s

def test():
    import matplotlib.pyplot as plt
    df=pandas.read_table('test_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    MZ,INT,d=PeakID(df,2803,1)
    plt.plot(df.Mass,df.Intensity,color='b')
    plt.bar(MZ,INT,color='r')
    MZ,INT,d=PeakID(df,2783,1)
    plt.bar(MZ,INT,color='g')
    plt.show()
    lbl=pandas.DataFrame({'Mass':[2783,2803],'Label':['First','Second']})
    # print(lbl)
    s=annotate(df,lbl,1)
    print('from DataFrame:',s)
    s=annotate(df.values,lbl,1)
    print('from numpy.ndarray:',s)
if __name__ == '__main__':
    test()